"""Publish the initial clean matrix and separate force attribution without parity claims."""
import hashlib
import json
from pathlib import Path
import zipfile
root=Path('.artifacts/issue308-matched')
out=Path('benchmarks/results/issue206-device-diis-baseline');out.mkdir(parents=True,exist_ok=True)
sha=lambda x:hashlib.sha256(x).hexdigest()
manifest=json.loads((root/'initial-clean/manifest.json').read_text());assert manifest['status']=='completed'
files={};rows=[]
for folder in ('initial-clean','force-profile'):
    for p in (root/folder).iterdir():
        if p.is_file():files[folder+'/'+p.name]=p.read_bytes()
for name in ('run-matrix.py','qualify-inputs.py','profile-force.py','retain-baseline.py','matrix.log','force-profile.log'):
    files['reproduction/'+name]=(root/name).read_bytes()
for p in sorted((root/'initial-clean').glob('*ao-b*-*.json')):
    r=json.loads(p.read_text());v=r['vibeqc'];g=r['gpu4pyscf']
    paired=r['accuracy']['paired_warm_repeats'];force=paired[0]['maximum_force_error_hartree_per_bohr'] is not None
    rows.append({'file':p.name,'vibeqc_warm_median_seconds':v['warm_median_seconds'],'gpu4pyscf_warm_median_seconds':g['warm_median_seconds'],'vibeqc_cold_seconds':v['cold_seconds'],'gpu4pyscf_cold_seconds':g['cold_seconds'],'unmatched_vibeqc_over_gpu4pyscf':v['warm_median_seconds']/g['warm_median_seconds'],'shared_iteration_branch':all(x['iteration_branches_match'] for x in paired),'maximum_energy_error':max(x['maximum_energy_error_hartree'] for x in paired),'maximum_force_error':max(x['maximum_force_error_hartree_per_bohr'] for x in paired) if force else None,'vibeqc_iterations':[[c['iterations'] for c in sample['convergence']] for sample in v['warm_samples']],'gpu4pyscf_iterations':[[c['iterations'] for c in sample['convergence']] for sample in g['warm_samples']]})
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:assert all(z.read(name)==data for name,data in files.items())
s={'scope':'Initial clean energy/full-force matrix with five interleaved repeats per engine and independent actual-rank qualification. All SCF branches differ; no iteration-matched parity claim. 192-AO performance acceptance remains unmet. Separate intrusive profiles identify host response-weight cost.','source_head':manifest['git_head'],'library_sha256':manifest['library_sha256'],'slurm_jobs':{'clean':manifest['slurm_job'],'profile':json.loads((root/'force-profile/summary.json').read_text())['slurm_job']},'versions':manifest['versions'],'rows':rows,'force_profile':json.loads((root/'force-profile/summary.json').read_text()),'acceptance':{'all_repeat_energy_at_1e_9_and_forces_at_1e_8':True,'iteration_matched_comparison':False,'issue206_performance_gate':'unmet; 192-AO unmatched force ratios exceed nine, and no shared iteration branch was demonstrated','direct_regression_gate':'not rerun by this artifact','changed_geometry_and_384_ao':'remaining integration work'},'archive':{'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'restoration':'Every member restored and compared byte-for-byte.'},'files':[{'path':name,'sha256':sha(data),'bytes':len(data)} for name,data in sorted(files.items())]}
# Complete profiles remain archived; keep the human-facing JSON focused.
s['force_profile']=[{'aos':r['aos'],'budget':r['budget'],'stage':r['stage'],'seconds':r['seconds'],'phases':r['progress']['phases']} for r in s['force_profile']['results']]
(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
policy=Path('benchmarks/evidence-policy.json');p=json.loads(policy.read_text())
p['exceptions'][str(archive)]={'owner':'issue206-device-diis-baseline','reason':'Clean 96/192-AO energy/full-force batch-1/4 samples, actual external factor ranks, exact basis stack, unmatched branches and separately traced host-response bottleneck.','sha256':s['archive']['sha256']}
policy.write_text(json.dumps(p,indent=2,sort_keys=True)+'\n')
print(s['archive'])

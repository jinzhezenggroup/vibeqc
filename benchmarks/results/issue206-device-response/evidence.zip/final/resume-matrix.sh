#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/.artifacts/issue206-frozen-response-final/libvibeqc.so
export LD_LIBRARY_PATH=$PWD/.artifacts/issue206-frozen-response-final:/group/software/cuda-12.9.1/lib64:/tmp/vibeqc-308-gpu4pyscf-env/lib/python3.13/site-packages/cutensor/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export VIBEQC_DF_VALUE_MAPPING=primitive VIBEQC_DF_HOST_RESPONSE_WEIGHTS=0
/tmp/vibeqc-308-gpu4pyscf-env/bin/python .artifacts/issue206-device-response-final/resume-matrix.py

#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/.artifacts/issue206-frozen-response-final/libvibeqc.so
export LD_LIBRARY_PATH=$PWD/.artifacts/issue206-frozen-response-final:/group/software/cuda-12.9.1/lib64:/tmp/vibeqc-308-gpu4pyscf-env/lib/python3.13/site-packages/cutensor/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
sha256sum "$VIBEQC_LIBRARY"
nvidia-smi --query-gpu=name,driver_version,pstate,clocks.sm,clocks.mem,power.limit --format=csv
direct_status=0
/tmp/vibeqc-308-gpu4pyscf-env/bin/python benchmarks/real_molecule_gate.py --density-fitting none --repeats 5 --output-directory .artifacts/issue206-device-response-final/direct-gate || direct_status=$?
# Retain component evidence even if a preceding matrix/gate exhausts its window.
if [[ ! -e .artifacts/issue206-device-response-final/force-profile ]]; then
  /tmp/vibeqc-pr-review-env/bin/python .artifacts/issue206-device-response-final/profile-force.py
fi
exit "$direct_status"

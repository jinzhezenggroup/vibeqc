"""Stop only after the last short case has written all completed measurements."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import time

root=Path('.artifacts/issue206-device-response-final')
target=root/'clean/384ao-b4-energy-device.json'
pid=1666712
assert b'issue206-device-response-final/run-matrix.py' in Path(f'/proc/{pid}/cmdline').read_bytes()
libc=ctypes.CDLL(None,use_errno=True)
fd=libc.inotify_init1(os.O_CLOEXEC)
assert fd>=0
assert libc.inotify_add_watch(fd,os.fsencode(target.parent),0x8)>=0  # IN_CLOSE_WRITE
# No profiler or sampling runs during the endpoint. The filesystem event is
# emitted only after its complete result, including all timing samples, closes.
while not target.exists():
    ready,_,_=select.select([fd],[],[],50)
    if ready: os.read(fd,65536)
# write_result closes the file at once; retry only if a create raced its close.
while True:
    try:
        raw=target.read_bytes();data=json.loads(raw);assert len(data['accuracy']['paired_warm_repeats'])==5
        break
    except (json.JSONDecodeError,AssertionError):
        select.select([fd],[],[],1);os.read(fd,65536)
os.close(fd)
(root/'cutover.json').write_text(json.dumps({'reason':'Move final 384-AO batch-four force endpoint to a fresh finite allocation; extension of job 9571 denied','parent_pid':pid,'completed_result':str(target),'result_sha256':hashlib.sha256(raw).hexdigest(),'time_unix':time.time(),'signal':'SIGTERM to outer runner after completed energy result'},indent=2)+'\n')
os.kill(pid,signal.SIGTERM)
print('Stopped outer runner after complete batch-four energy measurements',flush=True)

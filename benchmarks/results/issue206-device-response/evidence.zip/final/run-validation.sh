#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/.artifacts/issue206-frozen-response-final/libvibeqc.so
export LD_LIBRARY_PATH=$PWD/.artifacts/issue206-frozen-response-final${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export VIBEQC_RESOURCE_CUDA_TEST=1 VIBEQC_DF_VALUE_MAPPING=primitive
runner=/tmp/vibeqc-pr-review-env/bin/python
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
sha256sum "$VIBEQC_LIBRARY"
"$runner" -m pytest -q -rs --basetemp=.artifacts/issue206-device-response-final/pytest-data2 tests/python/test_hf_resources_cuda.py tests/python/test_df_response_weights_cuda.py tests/python/test_df_force_state_export_cuda.py
.artifacts/issue206-frozen-response-final/vibeqc_density_fitting_tests
VIBEQC_ONE_ELECTRON_DERIVATIVES=generated .artifacts/issue206-frozen-response-final/vibeqc_density_fitting_tests
.artifacts/issue206-frozen-response-final/vibeqc_df_capture_recovery_tests
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --target-processes all --error-exitcode 86 --log-file "$PWD/.artifacts/issue206-device-response-final/sanitizer-%p.log" "$runner" -m pytest -q -rs tests/python/test_df_device_diis_cuda.py -k occupied-4-spherical-uhf

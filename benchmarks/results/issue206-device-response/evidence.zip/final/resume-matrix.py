"""Finish the sole long endpoint in a fresh finite allocation, retaining cutover."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
assert os.environ.get('SLURM_JOB_ID') and os.environ.get('CUDA_VISIBLE_DEVICES')
root=Path('.artifacts/issue206-device-response-final')
out=root/'clean-continuation';out.mkdir(exist_ok=False)
m=json.loads((root/'clean/manifest.json').read_text())
assert hashlib.sha256(Path(os.environ['VIBEQC_LIBRARY']).read_bytes()).hexdigest()==m['library_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==m['git_head']
cut=json.loads((root/'cutover.json').read_text())
energy=Path(cut['completed_result']);assert hashlib.sha256(energy.read_bytes()).hexdigest()==cut['result_sha256']
def all_accuracy(result,forces):
    pairs=result['accuracy']['paired_warm_repeats']
    return len(pairs)==5 and all(r['maximum_energy_error_hartree']<=1e-9 and (not forces or r['maximum_force_error_hartree_per_bohr']<=1e-8) for r in pairs)
for row in m['attempts']:
    if row['aos']==384 and row['batch']==4 and not row['forces']:
        row.update(status='completed',all_repeat_accuracy_passed=all_accuracy(json.loads(energy.read_text()),False),result_sha256=cut['result_sha256'],process_exit_observed=False,recovered_complete_result_after_cutover=True)
# The interrupted runner may have entered the next command just before SIGTERM.
# Retain that incomplete attempt explicitly; no samples from it are reused.
m['cutover_incomplete_attempts']=[r for r in m['attempts'] if r['status']=='running']
m['attempts']=[r for r in m['attempts'] if r['status']!='running']
m['cutover']=cut
m['continuation_slurm_job']=os.environ['SLURM_JOB_ID']
m['continuation_runner_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
m['continuation_gpu_before']=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,pstate,clocks.sm,clocks.mem,power.limit','--format=csv'],text=True)
result=out/'384ao-b4-forces-device.json'
command=[sys.executable,'benchmarks/compare_gpu4pyscf_batch.py','--case','water-hexadecamer-2s4-def2-svp-spherical','--batch','4','--repeats','5','--density-fitting','cuda','--density-fitting-memory-budget-bytes','0','--maximum-energy-error','1e-9','--maximum-force-error','1e-8','--max-iterations','100','--energy-tolerance','1e-12','--density-tolerance','1e-10','--reference-gradient-tolerance','1e-10','--output',str(result)]
row={'case':'water-hexadecamer-2s4-def2-svp-spherical','aos':384,'batch':4,'forces':True,'host_weights':False,'command':command,'status':'running','result':str(result)}
m['attempts'].append(row)
def save():
    p=root/'clean-combined-manifest.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(m,indent=2)+'\n');tmp.replace(p)
save();start=time.monotonic()
with (out/'384ao-b4-forces-device.log').open('w') as log:
    try:
        run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=2100,check=False)
        row['returncode']=run.returncode;row['status']='completed' if run.returncode==0 else 'failed'
    except subprocess.TimeoutExpired:
        row['status']='timeout'
row['seconds']=time.monotonic()-start
if result.exists():
    row['result_sha256']=hashlib.sha256(result.read_bytes()).hexdigest();row['all_repeat_accuracy_passed']=all_accuracy(json.loads(result.read_text()),True)
    if not row['all_repeat_accuracy_passed']:row['status']='failed_all_repeat_accuracy'
m['continuation_gpu_after']=subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,pstate,clocks.sm,clocks.mem,power.limit','--format=csv'],text=True)
m['status']='completed' if len(m['attempts'])==20 and all(r['status']=='completed' for r in m['attempts']) else 'failed'
save();print(row['status'],flush=True)
raise SystemExit(0 if m['status']=='completed' else 1)

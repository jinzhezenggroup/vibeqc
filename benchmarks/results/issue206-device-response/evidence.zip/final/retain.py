"""Retain repeated response placement evidence, exact inputs, and failed attempts.

The ordinary GPU4PySCF ratios are not promoted to iteration-matched claims.
Native plan/scratch inventory is distinct from whole-process memory acceptance.
"""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np

root = Path('.artifacts/issue206-device-response-final')
prior = Path('.artifacts/issue206-device-response-attempt1')
out = Path('benchmarks/results/issue206-device-response')
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((root/'clean-combined-manifest.json').read_text())
assert manifest['status'] == 'completed', manifest['status']
assert all(r['all_repeat_accuracy_passed'] for r in manifest['attempts'])
identity = json.loads(Path('.artifacts/issue206-frozen-response-final/native-identity.json').read_text())
assert manifest['library_sha256'] == identity['library_sha256']
rows = []
for p in sorted(list((root/'clean').glob('*ao-b*-*.json')) + list((root/'clean-continuation').glob('*ao-b*-*.json'))):
    r = json.loads(p.read_text())
    assert r['gate']['passed'], (p, r['gate'])
    v, g, pairs = r['vibeqc'], r['gpu4pyscf'], r['accuracy']['paired_warm_repeats']
    force = pairs[0]['maximum_force_error_hartree_per_bohr'] is not None
    rows.append({
        'file':p.name, 'aos':r['workload']['ao_count'], 'batch':r['workload']['batch_size'],
        'method':r['workload']['method'], 'forces':force, 'host_weights':p.stem.endswith('-host'),
        'vibeqc_warm_median_seconds':v['warm_median_seconds'],
        'gpu4pyscf_warm_median_seconds':g['warm_median_seconds'],
        'vibeqc_cold_seconds':v['cold_seconds'], 'gpu4pyscf_cold_seconds':g['cold_seconds'],
        'ordinary_vibeqc_over_gpu4pyscf':v['warm_median_seconds']/g['warm_median_seconds'],
        'shared_iteration_branch':all(x['iteration_branches_match'] for x in pairs),
        'maximum_energy_error':max(x['maximum_energy_error_hartree'] for x in pairs),
        'maximum_force_error':max(x['maximum_force_error_hartree_per_bohr'] for x in pairs) if force else None,
        'maximum_force_rms_error':max(float(np.sqrt(np.mean((np.array(vs['forces_hartree_per_bohr'])-np.array(gs['forces_hartree_per_bohr']))**2))) for vs,gs in zip(v['warm_samples'],g['warm_samples'],strict=True)) if force else None,
        'maximum_net_force':max(float(np.max(np.abs(np.array(vs['forces_hartree_per_bohr']).sum(axis=1)))) for vs in v['warm_samples']) if force else None,
        'vibeqc_iterations':[[c['iterations'] for c in x['convergence']] for x in v['warm_samples']],
        'gpu4pyscf_iterations':[[c['iterations'] for c in x['convergence']] for x in g['warm_samples']],
        'metric_diagnostics':r['settings']['density_fitting_metric_diagnostics'],
    })
ablations = []
for row in rows:
    if row['host_weights']:
        device = next(r for r in rows if (r['aos'],r['batch'],r['forces'],r['host_weights']) == (row['aos'],row['batch'],True,False))
        ablations.append({'aos':row['aos'],'batch':row['batch'],'host_seconds':row['vibeqc_warm_median_seconds'],'device_seconds':device['vibeqc_warm_median_seconds'],'host_over_device':row['vibeqc_warm_median_seconds']/device['vibeqc_warm_median_seconds'],'identical_vibeqc_iteration_rows':row['vibeqc_iterations']==device['vibeqc_iterations']})
profiles = json.loads((root/'force-profile/summary.json').read_text())
assert profiles['library_sha256'] == identity['library_sha256']
large_profiles = json.loads((root/'large-force-profile/summary.json').read_text())
assert large_profiles['library_sha256'] == identity['library_sha256']
direct = json.loads((root/'direct-gate/summary.json').read_text())
files = {}
for label, directory in [('final',root),('prior-attempt',prior)]:
    for p in directory.rglob('*'):
        if p.is_file() and p.suffix in ('.py','.sh','.json','.jsonl','.txt','.bin','.npz','.log'):
            files[label+'/'+str(p.relative_to(directory))] = p.read_bytes()
for name in ('final','attempt1'):
    d = Path('.artifacts/issue206-frozen-response-'+name)
    for p in d.iterdir():
        if p.is_file() and p.suffix in ('.json','.patch'):
            files['frozen-'+name+'/'+p.name] = p.read_bytes()
    lib = d/'libvibeqc.so'
    files['frozen-'+name+'/library.json'] = json.dumps({'path':str(lib),'bytes':lib.stat().st_size,'sha256':sha(lib.read_bytes())},indent=2).encode()
for p in [Path('/tmp/vibeqc-206-device-response-final-hooks.log'),Path('/tmp/vibeqc-206-device-response-build3.log'),Path('build/cuda/CMakeCache.txt')]:
    files['build/'+p.name] = p.read_bytes()
out.mkdir(parents=True,exist_ok=True)
archive = out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert all(z.read(name)==data for name,data in files.items())
def compact_profile(row):
    """Keep useful totals here; full observations/samples remain in the archive."""
    result = {k:row[k] for k in ('aos','budget','stage','host_weights','seconds','energy','iterations','metric','cuda','host')}
    result['progress_phases'] = row['progress']['phases']
    result['pending_progress_scopes'] = row['progress']['pending']
    if 'memory_samples' in row:
        gpu = [int(line.split(',')[1]) for sample in row['memory_samples'] for line in sample.get('gpu_process_rows',[]) if line.split(',')[1].strip().isdigit()]
        host = [int(line.split()[1])*1024 for sample in row['memory_samples'] for line in sample.get('host_status',[]) if line.startswith('VmHWM:')]
        result['sampled_gpu_process_peak_mib'] = max(gpu,default=None)
        result['sampled_host_high_water_bytes'] = max(host,default=None)
        result['memory_sample_count'] = len(row['memory_samples'])
        result['independent_reference_errors'] = row['independent_reference_errors']
    return result

summary = {
    'schema':'vibeqc.issue206.device-response.v1',
    'scope':'Five interleaved warm repeats per engine, cold endpoints, same-library host ablation, RHF at 96/192/384 AOs and UHF at 19 AOs, batch one/four. Ordinary ratios remain distinct from iteration-matched performance.',
    'identity':identity,'versions':manifest['versions'],'clean_slurm_jobs':[manifest['slurm_job'],manifest['continuation_slurm_job']],
    'profile_slurm_job':profiles['slurm_job'],'rows':rows,'ablations':ablations,
    'profiles':[compact_profile(r) for r in profiles['results']],
    'large_profiles':{'slurm_job':large_profiles['slurm_job'],'results':[compact_profile(r) for r in large_profiles['results']]},
    'direct_regression_gate':direct,
    'prechange_direct_control':json.loads((root/'direct-control/summary.json').read_text()),
    'direct_native_control':json.loads((root/'direct-native-control.json').read_text()),
    'validation':{'host_checks':71,'primary_gpu_run':{'passed':105,'failed':2,'failure':'exact metric ownership byte expectations; corrected'},'complementary_gpu_checks':34,'native_df_default_and_generated':True,'capture_recovery':True,'occupied_uhf_batch4_memcheck_errors':0,'frozen_loader_attempt':'eight probe load failures retained; SONAME symlink fixed before successful complementary validation'},
    'acceptance':{'all_repeat_energy_1e_9_and_forces_1e_8':True,'issue206_performance_gate':'unmet; 192-AO force endpoint remains slower, and shared SCF branches are not established','global_resource_qualification':'unchanged: <=16 orbital and <=128 auxiliary AOs','whole_process_memory_and_changed_geometry_budget_matrix':'remaining integration work; metric diagnostics are plan estimates, not a whole-process bound','trackers':'#206/#308/#309/#310/#311 remain open'},
    'archive':{'path':'evidence.zip','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'restoration':'Every archive member restored and compared byte-for-byte.'},
    'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())],
}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
policy = Path('benchmarks/evidence-policy.json');p = json.loads(policy.read_text())
p['exceptions'][str(archive)] = {'owner':'issue206-device-response','reason':'Repeated device/host response-placement ablations and GPU4PySCF RHF/UHF 96/192/384-AO matrices, complete raw results/ranks/traces, direct gate, validation/failures, reconstruction and measured identities.','sha256':summary['archive']['sha256']}
policy.write_text(json.dumps(p,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary['archive']))

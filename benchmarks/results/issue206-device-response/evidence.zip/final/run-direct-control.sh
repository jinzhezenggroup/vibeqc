#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/.artifacts/issue308-frozen-device-diis-final/libvibeqc.so
export LD_LIBRARY_PATH=/group/software/cuda-12.9.1/lib64:/tmp/vibeqc-308-gpu4pyscf-env/lib/python3.13/site-packages/cutensor/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
sha256sum "$VIBEQC_LIBRARY"
control_status=0
/tmp/vibeqc-308-gpu4pyscf-env/bin/python benchmarks/real_molecule_gate.py --density-fitting none --size 96 --repeats 5 --output-directory .artifacts/issue206-device-response-final/direct-control || control_status=$?
export VIBEQC_LIBRARY=$PWD/.artifacts/issue206-frozen-response-final/libvibeqc.so
/tmp/vibeqc-pr-review-env/bin/python .artifacts/issue206-device-response-final/profile-force384.py
exit "$control_status"

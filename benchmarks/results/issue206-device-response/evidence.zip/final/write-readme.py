"""Render the retained evidence without upgrading ordinary ratios to parity."""
import json
from pathlib import Path
out=Path('benchmarks/results/issue206-device-response')
s=json.loads((out/'summary.json').read_text())
large=next(r for r in s['large_profiles']['results'] if r['stage']=='warm')
response=next(g for g in large['cuda']['groups'] if g['operation']=='force_response')
large_note=(f"The instrumented 384-AO warm call uses {response['counter_sums']['response_auxiliary_blocks']} response panels and uploads {response['counter_sums']['raw_value_upload_bytes']:,} raw bytes with {response['counter_maxima']['response_scratch_bytes']:,} device scratch bytes. Its exchange-weight/metric region takes {response['gpu_exclusive_ms']['exchange_response_weights_and_metric']/1000:.3f} s; raw uploads occupy {response['host_exclusive_ms']['raw_value_slice_upload']/1000:.3f} s of host time. Host and device intervals overlap and must not be added. The maximum sampled process GPU usage is {max(r['sampled_gpu_process_peak_mib'] for r in s['large_profiles']['results'])} MiB; the maximum observed host high-water value is {max(r['sampled_host_high_water_bytes'] for r in s['large_profiles']['results']):,} bytes.")
lines=['# Device response weights for retained DF values (#206)', '',
'The default retained-value plan now reuses its forward device metric factors and the existing CUDA force-response contraction. Raw auxiliary slices are uploaded into bounded scratch. The full one-electron/Pulay, three-center, auxiliary, metric/subspace and nuclear response is retained. `VIBEQC_DF_HOST_RESPONSE_WEIGHTS=1` selects the former host-weight adapter under the same conservative resource reservation.', '',
'Five interleaved warm repeats per engine cover RHF at 96/192/384 AOs and UHF at 19 AOs, each at batch one/four, for energy and complete forces. The external basis data, actual factor ranks, software stack and all raw results are retained. Ordinary timing ratios remain distinct from a demonstrated common SCF iteration branch.', '',
'| AOs / batch | VibeQC energy | GPU4 energy | VibeQC forces | GPU4 forces |',
'| --- | ---: | ---: | ---: | ---: |']
for aos in (19,96,192,384):
 for batch in (1,4):
  rows=[r for r in s['rows'] if r['aos']==aos and r['batch']==batch and not r['host_weights']]
  e=next(r for r in rows if not r['forces']);f=next(r for r in rows if r['forces'])
  lines.append(f"| {aos} / {batch} | {e['vibeqc_warm_median_seconds']:.6f} s | {e['gpu4pyscf_warm_median_seconds']:.6f} s | {f['vibeqc_warm_median_seconds']:.6f} s | {f['gpu4pyscf_warm_median_seconds']:.6f} s |")
lines += ['', 'The 192-AO performance gate remains unmet. All repeated energy errors are below 1e-9 Ha and all force-component errors below 1e-8 Ha/Bohr. The maximum observed paired errors are '+f"{max(r['maximum_energy_error'] for r in s['rows']):.6e} Ha and {max(r['maximum_force_error'] or 0 for r in s['rows']):.6e} Ha/Bohr."+' RMS errors, net forces, per-item convergence and metric diagnostics are also retained.', '',
'| Same-library force ablation | Host weights | Device weights | Host / device |',
'| --- | ---: | ---: | ---: |']
for r in s['ablations']:
 lines.append(f"| {r['aos']} AOs / batch {r['batch']} | {r['host_seconds']:.6f} s | {r['device_seconds']:.6f} s | {r['host_over_device']:.3f} |")
assert all(r['identical_vibeqc_iteration_rows'] for r in s['ablations'])
lines += ['', 'Each host/device ablation has identical VibeQC iteration rows. The external engine retains its own fixed post-cold density policy, and its branch differences remain explicit. No native compilation, profiling, memory sampler or reference preflight overlaps the clean endpoints.', '',
'The separate 96/192-AO profiles expose raw upload bytes, device response scratch, scalar-density transfers and final-output transfers. A 384-AO cold/warm profile additionally retains sampled GPU process memory and cumulative host high-water measurements. These are observations for the recorded calls, not whole-process budget qualification. Native metric byte diagnostics describe plan estimates; global qualification remains ≤16 orbital /128 auxiliary AOs.', '',
large_note, '',
'Validation covers 71 host checks, 105 passing GPU checks in the first run plus two corrected exact-byte expectations verified in a 34-check complementary run, native DF with default/generated one-electron response, capture recovery, and occupied UHF batch-four memcheck with zero errors. Actual W/full-force exports, retained/discarded metric subspaces, invalid-value transactions, warm reuse and route/transfer counters are tested. The initial resource-expectation failures and frozen-library loader failure are retained.', '',
'The unchanged direct-SCF matrix was also rerun. Its outcome and the frozen pre-change 96-AO control are reported below; tolerances were not changed.', '',
'| Direct gate | Candidate | Pre-change control |', '| --- | --- | --- |']
control={(p['ao_count'],p['batch_size']):p['passed'] for p in s['prechange_direct_control']['points']}
for p in s['direct_regression_gate']['points']:
 key=(p['ao_count'],p['batch_size']);c=control.get(key)
 lines.append(f"| {key[0]} AOs / batch {key[1]} | {'pass' if p['passed'] else 'fail'} | {'not repeated' if c is None else 'pass' if c else 'fail'} |")
lines += ['', 'The candidate and pre-change native force arrays differ by at most '+f"{max(r['maximum_native_force_change'] for r in s['direct_native_control']['rows']):.6e}"+' Ha/Bohr, with identical native iteration rows. The direct failures remain acceptance failures even if reproduced on the pre-change control. This slice does not close #206, #308, #309, #310 or #311. The complete changed-geometry/budget/ablation integration matrix and final acceptance audit remain open.', '',
'The initial 30-minute allocation was stopped only after all batch-four energy samples had been written, because the remaining 384-AO force case could not fit its remaining window and Slurm rejected an extension. That completed result and the cutover journal are preserved. The sole remaining force case ran in a fresh finite allocation; no partial force timings were reused.', '',
'Qualified source: `'+s['identity']['qualified_source_commit']+'`. Native source identity: `'+s['identity']['native_source_identity']+'`. Frozen library SHA-256: `'+s['identity']['library_sha256']+'`.', '',
'`evidence.zip` contains exact runners, raw samples, input qualification, traces, state exports, failed attempts, build/validation logs and reconstruction. Every member was restored and compared byte-for-byte. Archive SHA-256: `'+s['archive']['sha256']+'`.', '']
(out/'README.md').write_text('\n'.join(lines))

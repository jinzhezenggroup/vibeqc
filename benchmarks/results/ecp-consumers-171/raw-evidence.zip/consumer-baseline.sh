#!/usr/bin/env bash
set -euo pipefail
root=/inspire/qb-ilm/project/chemicalreaction/diwenxi-CZXS25120072/vibeqc-workspace
cd "$root"
source activate-311.sh
task="$root/build-171/consumer-20260916"
evidence="$task/evidence"
trap 'echo $? > "$evidence/baseline.exit"' EXIT
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$task/source"
export PYTHONPATH="$PWD/python"
cmake -S . -B "$task/cuda" -G 'Unix Makefiles' -DCMAKE_BUILD_TYPE=Release \
  -DVIBEQC_ENABLE_CUDA=ON -DVIBEQC_ENABLE_AOT_SHELLS=OFF \
  -DCMAKE_CUDA_ARCHITECTURES=89 -DPython3_EXECUTABLE="$(command -v python)" \
  > "$evidence/baseline-configure.log" 2>&1
cmake --build "$task/cuda" --target vibeqc --parallel 6 > "$evidence/baseline-build.log" 2>&1
export VIBEQC_LIBRARY="$task/cuda/libvibeqc.so"
cp "$VIBEQC_LIBRARY" "$task/baseline-libvibeqc.so"
cp "$task/cuda/generated/generated_ecp_ao.cuh" "$evidence/baseline-generated.cuh"
cuobjdump --dump-resource-usage "$task/cuda/CMakeFiles/vibeqc.dir/src/integrals/ecp_cuda.cu.o" > "$evidence/baseline-resources.txt"
python tools/benchmark_ecp.py --device cuda --repeats 3 --output "$evidence/baseline-benchmark.json" > "$evidence/baseline-benchmark.log" 2>&1

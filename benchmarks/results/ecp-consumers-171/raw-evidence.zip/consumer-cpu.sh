#!/usr/bin/env bash
set -euo pipefail
root=/inspire/qb-ilm/project/chemicalreaction/diwenxi-CZXS25120072/vibeqc-workspace
cd "$root"
source activate-311.sh
task="$root/build-171/consumer-20260916"
evidence="$task/evidence"
trap 'echo $? > "$evidence/cpu.exit"' EXIT
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$task/candidate"
export PYTHONPATH="$PWD/python"
cmake -S . -B "$task/cpu" -G 'Unix Makefiles' -DCMAKE_BUILD_TYPE=Release \
  -DVIBEQC_ENABLE_CUDA=OFF -DPython3_EXECUTABLE="$(command -v python)" \
  > "$evidence/cpu-configure.log" 2>&1
cmake --build "$task/cpu" --parallel 2 > "$evidence/cpu-build.log" 2>&1
export VIBEQC_LIBRARY="$task/cpu/libvibeqc.so"
ctest --test-dir "$task/cpu" --output-on-failure --parallel 2 > "$evidence/cpu-ctest.log" 2>&1
python -m pytest tests/python/test_ecp.py tests/python/test_ecp_ir.py tests/python/test_ecp_validation.py -q > "$evidence/cpu-python.log" 2>&1

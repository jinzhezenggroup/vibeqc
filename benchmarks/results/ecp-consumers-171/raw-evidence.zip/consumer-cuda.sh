#!/usr/bin/env bash
set -euo pipefail
root=/inspire/qb-ilm/project/chemicalreaction/diwenxi-CZXS25120072/vibeqc-workspace
cd "$root"
source activate-311.sh
task="$root/build-171/consumer-20260916"
evidence="$task/evidence"
trap 'echo $? > "$evidence/cuda.exit"' EXIT
test "$(cat "$evidence/baseline.exit")" = 0
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
# Keep the existing isolated build path and replace only the three changed files.
tar -xzf evidence-171/consumer-formatted.tar.gz -C "$task/source"
cd "$task/source"
export PYTHONPATH="$PWD/python"
# Archive mtimes predate the baseline build. Regenerate explicitly and mark
# native inputs fresh so a reused build cannot qualify stale objects.
python -I -S tools/generate_ecp_kernels.py --output "$task/cuda/generated/generated_ecp_ao.cuh"
touch src/integrals/ecp_cuda.cu tests/native/test_ecp_projector.cpp
cmake --build "$task/cuda" --target vibeqc vibeqc_ecp_projector_tests vibeqc_ecp_cuda_error_tests --parallel 4 > "$evidence/cuda-build.log" 2>&1
export VIBEQC_LIBRARY="$task/cuda/libvibeqc.so" VIBEQC_ECP_CUDA_TEST=1
ctest --test-dir "$task/cuda" -R 'vibeqc_ecp_' --output-on-failure > "$evidence/cuda-ctest.log" 2>&1
python -m pytest tests/python/test_ecp.py tests/python/test_ecp_ir.py tests/python/test_ecp_validation.py -q > "$evidence/cuda-python.log" 2>&1
python tools/benchmark_ecp.py --device cuda --repeats 3 --output "$evidence/candidate-benchmark.json" > "$evidence/candidate-benchmark.log" 2>&1
/usr/local/cuda-12.8/bin/compute-sanitizer --tool memcheck --error-exitcode 99 "$task/cuda/vibeqc_ecp_cuda_error_tests" > "$evidence/cuda-memcheck.log" 2>&1
cp "$task/cuda/generated/generated_ecp_ao.cuh" "$evidence/candidate-generated.cuh"
cuobjdump --dump-resource-usage "$task/cuda/CMakeFiles/vibeqc.dir/src/integrals/ecp_cuda.cu.o" > "$evidence/candidate-resources.txt"

#!/usr/bin/env bash
set -euo pipefail
root=/inspire/qb-ilm/project/chemicalreaction/diwenxi-CZXS25120072/vibeqc-workspace
cd "$root"
source activate-311.sh
task="$root/build-171/consumer-20260916"
mkdir "$task"
mkdir "$task/source" "$task/candidate" "$task/evidence"
tar -xzf evidence-171/consumer-baseline.tar.gz -C "$task/source"
tar -xzf evidence-171/consumer-baseline.tar.gz -C "$task/candidate"
tar -xzf evidence-171/consumer-changes.tar.gz -C "$task/candidate"
cd "$task/candidate"
ruff check python/vibeqc_compiler/integral/ecp_projector.py
ruff format python/vibeqc_compiler/integral/ecp_projector.py
clang-format -i src/integrals/ecp_cuda.cu tests/native/test_ecp_projector.cpp
python -I -S tools/generate_ecp_kernels.py --output "$task/generated_ecp_ao.cuh"
c++ -std=c++20 -O2 -Wall -Wextra -Werror -I "$task" tests/native/test_ecp_projector.cpp -o "$task/consumer-test"
"$task/consumer-test"
tar -czf "$root/evidence-171/consumer-formatted.tar.gz" python/vibeqc_compiler/integral/ecp_projector.py src/integrals/ecp_cuda.cu tests/native/test_ecp_projector.cpp

"""Verify the frozen library embeds the current native source content hash."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
from vibeqc.autotune import source_identity

assert os.environ.get('SLURM_JOB_ID') and os.environ.get('CUDA_VISIBLE_DEVICES')
path=Path(os.environ['VIBEQC_LIBRARY']).resolve()
native=ctypes.CDLL(str(path))
native.vibeqc_get_source_identity.restype=ctypes.c_char_p
identity=native.vibeqc_get_source_identity().decode()
assert identity==source_identity(Path.cwd())
record={
    'native_source_identity':identity,
    'library_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
    'library_bytes':path.stat().st_size,
    'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    'patch_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--binary'])).hexdigest(),
    'slurm_job':os.environ['SLURM_JOB_ID'],
}
(path.parent/'native-identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)

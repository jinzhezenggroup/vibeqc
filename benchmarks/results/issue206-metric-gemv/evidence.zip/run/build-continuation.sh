#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-206-response-metric-gemv
printf 'CPU continuation Slurm job: %s\n' "$SLURM_JOB_ID"
if [[ -f .artifacts/issue206-metric-gemv/build-success.sha256 ]]; then
  sha256sum --check .artifacts/issue206-metric-gemv/build-success.sha256
  exit 0
fi
bash .artifacts/issue206-metric-gemv/build-after-timings.sh

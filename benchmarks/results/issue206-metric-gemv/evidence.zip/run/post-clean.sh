#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-206-response-metric-gemv
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
printf 'Post-clean Slurm job: %s\n' "$SLURM_JOB_ID"
test -f .artifacts/issue206-metric-gemv/validation-success.json
status=0
bash .artifacts/issue206-metric-gemv/run-direct-gate.sh || status=$?
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/.artifacts/issue206-metric-gemv/frozen-attempt1/libvibeqc.so
export LD_LIBRARY_PATH=$PWD/.artifacts/issue206-metric-gemv/frozen-attempt1:/group/software/cuda-12.9.1/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export VIBEQC_DF_VALUE_MAPPING=primitive
/tmp/vibeqc-pr-review-env/bin/python .artifacts/issue206-metric-gemv/profile-force384.py
printf 'Direct gate exit: %s\n' "$status"
exit "$status"

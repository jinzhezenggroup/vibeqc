#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-206-response-metric-gemv
printf 'CPU build Slurm job: %s\n' "$SLURM_JOB_ID"
cmake -S . -B build/cuda -G Ninja -DCMAKE_BUILD_TYPE=Release -DVIBEQC_ENABLE_CUDA=ON -DCMAKE_CUDA_COMPILER=/group/software/cuda-12.9.1/bin/nvcc -DVIBEQC_CUDA_COMPILE_ARCHITECTURES=120 -DVIBEQC_CUDA_COMPILE_JOBS=2 -DVIBEQC_CUDA_FAST_COMPILE=OFF -DVIBEQC_CUDA_SPLIT_COMPILE_THREADS=1 -DVIBEQC_AOT_PROFILE=auto
cmake --build build/cuda -j 6
export PYTHONPATH=python:. VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_resources.py tests/python/test_df_preparation_budget.py tests/python/test_hf_resources.py tests/python/test_cuda_ownership.py tests/python/test_df_streamed_k_policy.py tests/python/test_df_component_ledger.py tests/python/test_df_progress_trace.py
sha256sum build/cuda/libvibeqc.so > .artifacts/issue206-metric-gemv/build-success.sha256

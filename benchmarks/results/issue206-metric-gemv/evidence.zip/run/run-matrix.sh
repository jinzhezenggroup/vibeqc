#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-206-response-metric-gemv
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/.artifacts/issue206-metric-gemv/frozen-attempt1/libvibeqc.so
export LD_LIBRARY_PATH=$PWD/.artifacts/issue206-metric-gemv/frozen-attempt1:/group/software/cuda-12.9.1/lib64:/tmp/vibeqc-308-gpu4pyscf-env/lib/python3.13/site-packages/cutensor/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export VIBEQC_DF_VALUE_MAPPING=primitive
sha256sum --check .artifacts/issue206-metric-gemv/build-success.sha256
test -f .artifacts/issue206-metric-gemv/validation-success.json
/tmp/vibeqc-308-gpu4pyscf-env/bin/python .artifacts/issue206-metric-gemv/run-matrix.py

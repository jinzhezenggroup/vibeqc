"""Render endpoint evidence while keeping outstanding acceptance explicit."""
import json
from pathlib import Path
out=Path('benchmarks/results/issue206-metric-gemv')
s=json.loads((out/'summary.json').read_text())
lines=['# FP64 cuBLAS metric response dots (#206)','',
'The exchange metric response now contracts the existing bounded raw panel with `cublasDgemv` on the plan-owned handle and stream. Strided accumulation preserves Coulomb and both spin contributions. The spectral/auxiliary response and FP64 model are unchanged. `VIBEQC_DF_SERIAL_RESPONSE_DOT=1` selects the former serial AO-pair dot with the same explicit scratch bound; provider failures propagate through cleanup.', '',
'Five interleaved warm repeats per engine cover RHF at 96/192/384 AOs and UHF at 19 AOs, batch one/four, energy and complete forces. Exact orbital/auxiliary bases and actual external factor ranks were independently checked for every geometry before timing. External SCF branch differences remain explicit; these ordinary ratios do not establish iteration-matched parity.', '',
'| AOs / batch | VibeQC energy | GPU4 energy | VibeQC forces | GPU4 forces |','| --- | ---: | ---: | ---: | ---: |']
for aos in (19,96,192,384):
 for batch in (1,4):
  rows=[r for r in s['rows'] if r['aos']==aos and r['batch']==batch and not r['serial_metric_dot']]
  e=next(r for r in rows if not r['forces']);f=next(r for r in rows if r['forces'])
  lines.append(f"| {aos} / {batch} | {e['vibeqc_warm_median_seconds']:.6f} s | {e['gpu4pyscf_warm_median_seconds']:.6f} s | {f['vibeqc_warm_median_seconds']:.6f} s | {f['gpu4pyscf_warm_median_seconds']:.6f} s |")
lines+=['',f"All 100 paired comparisons pass 1e-9 Ha /1e-8 Ha/Bohr. Maximum paired errors are {max(r['maximum_energy_error'] for r in s['rows']):.6e} Ha and {max(r['maximum_force_error'] or 0 for r in s['rows']):.6e} Ha/Bohr. RMS errors, net forces, raw per-item convergence, metric diagnostics and all samples are retained. The 192-AO performance target remains unmet.",'',
'| Same-library force ablation | Serial dot | GEMV dot | Serial / GEMV |','| --- | ---: | ---: | ---: |']
for r in s['ablations']:
 assert r['identical_vibeqc_iteration_rows']
 lines.append(f"| {r['aos']} AOs / batch {r['batch']} | {r['serial_seconds']:.6f} s | {r['blas_seconds']:.6f} s | {r['serial_over_blas']:.3f} |")
lines+=['','Each serial/GEMV ablation has identical native iteration rows. No native compilation, profiling, reference preflight or memory sampling overlaps clean endpoint measurements. Separate 96/192-AO cold/warm profiles retain actual dot counters and unchanged scratch/transfer accounting.','']
large=next(r for r in s['large_profiles']['results'] if r['stage']=='warm')
g=next(g for g in large['cuda']['groups'] if g['operation']=='force_response')
lines+=[f"The instrumented 384-AO warm call uses {g['counter_sums']['response_auxiliary_blocks']} panels, uploads {g['counter_sums']['raw_value_upload_bytes']:,} raw bytes, and reports {g['counter_maxima']['response_scratch_bytes']:,} bytes of response device scratch. The metric-dot device interval is {g['gpu_exclusive_ms']['exchange_response_metric_dot']/1000:.3f} s, three-center derivative contraction {g['gpu_exclusive_ms']['three_center_derivative_contraction']/1000:.3f} s, and raw-upload host time {g['host_exclusive_ms']['raw_value_slice_upload']/1000:.3f} s. These host/device intervals overlap and must not be added. Upload host intervals may include waits for preceding stream work; a separate charge-dot ablation is needed before inferring CPU packing cost.",'',
f"The maximum sampled GPU process usage is {max(r['sampled_gpu_process_peak_mib'] for r in s['large_profiles']['results'])} MiB; the maximum observed cumulative host high-water value is {max(r['sampled_host_high_water_bytes'] for r in s['large_profiles']['results']):,} bytes. Every large-profile force component passes against the retained external reference. Samples and native plan estimates do not extend whole-process qualification: the global qualified range remains ≤16 orbital /128 auxiliary AOs.",'',
'Validation: 71 host checks, 115 GPU checks, native DF with default/generated/serial-dot variants, capture recovery, and occupied UHF batch-four memcheck with zero errors. The frozen library embeds the independently checked source hash. The first compile hit its finite 20-minute limit; its log is retained, and the exact incremental build completed in another finite allocation before any GPU qualification.','',
'The existing direct-SCF acceptance matrix was rerun without changing its tolerances. Historical pre-change control arrays from #343 are retained for the 96-AO comparison; no new control timing is claimed.','',
'| Direct gate | Candidate | Historical pre-change control |','| --- | --- | --- |']
controls={r['batch']:r for r in s['direct_native_control']['rows']}
for p in s['direct_regression_gate']['points']:
 old=controls.get(p['batch_size']) if p['ao_count']==96 else None
 lines.append(f"| {p['ao_count']} AOs / batch {p['batch_size']} | {'pass' if p['passed'] else 'fail'} | {'not repeated' if old is None else 'pass' if old['prechange_gate']['passed'] else 'fail'} |")
for r in controls.values():assert r['candidate_iterations']==r['prechange_iterations']
lines+=['',f"The candidate and historical pre-change native forces differ by at most {max(r['maximum_native_force_change'] for r in controls.values()):.6e} Ha/Bohr, with identical native iteration rows. Strict direct acceptance failures remain open. This slice does not close #206, #308, #309, #310 or #311; complete changed-geometry/budget/ablation integration and final acceptance remain outstanding.",'',
'Qualified source: `'+s['rebase_identity']['rebased_head']+'`. Native source identity: `'+s['identity']['native_source_identity']+'`. Frozen library SHA-256: `'+s['identity']['library_sha256']+'`. The exact measured patch and rebase identity record are archived.','',
'`evidence.zip` retains raw results, exact runners and finite Slurm provenance, independent basis/factor qualification, state exports, profiles/memory samples, direct controls and build/validation logs. Every member was restored and compared byte-for-byte. Archive SHA-256: `'+s['archive']['sha256']+'`.','']
(out/'README.md').write_text('\n'.join(lines))

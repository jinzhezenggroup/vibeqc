"""Retain complete GEMV qualification with raw samples and explicit open gates."""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np

root=Path('.artifacts/issue206-metric-gemv')
out=Path('benchmarks/results/issue206-metric-gemv')
prior=Path('/home/jzzeng/codes/vibeqc-issue-308-followup/.artifacts/issue206-device-response-final')
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((root/'clean/manifest.json').read_text())
assert manifest['status']=='completed' and len(manifest['attempts'])==20
assert all(r['all_repeat_accuracy_passed'] for r in manifest['attempts'])
identity=json.loads((root/'frozen-attempt1/native-identity.json').read_text())
assert manifest['library_sha256']==identity['library_sha256']
assert sha((root/'frozen-attempt1/source.patch').read_bytes())==identity['patch_sha256']
rows=[]
for p in sorted((root/'clean').glob('*ao-b*-*.json')):
 r=json.loads(p.read_text());assert r['gate']['passed']
 v,g,pairs=r['vibeqc'],r['gpu4pyscf'],r['accuracy']['paired_warm_repeats']
 assert len(pairs)==5
 forces=pairs[0]['maximum_force_error_hartree_per_bohr'] is not None
 rows.append({
  'file':p.name,'aos':r['workload']['ao_count'],'batch':r['workload']['batch_size'],'method':r['workload']['method'],'forces':forces,'serial_metric_dot':p.stem.endswith('-serial'),
  'vibeqc_warm_median_seconds':v['warm_median_seconds'],'gpu4pyscf_warm_median_seconds':g['warm_median_seconds'],
  'vibeqc_cold_seconds':v['cold_seconds'],'gpu4pyscf_cold_seconds':g['cold_seconds'],
  'ordinary_vibeqc_over_gpu4pyscf':v['warm_median_seconds']/g['warm_median_seconds'],
  'shared_iteration_branch':all(x['iteration_branches_match'] for x in pairs),
  'maximum_energy_error':max(x['maximum_energy_error_hartree'] for x in pairs),
  'maximum_force_error':max(x['maximum_force_error_hartree_per_bohr'] for x in pairs) if forces else None,
  'maximum_force_rms_error':max(float(np.sqrt(np.mean((np.array(vs['forces_hartree_per_bohr'])-np.array(gs['forces_hartree_per_bohr']))**2))) for vs,gs in zip(v['warm_samples'],g['warm_samples'],strict=True)) if forces else None,
  'maximum_net_force':max(float(np.max(np.abs(np.array(vs['forces_hartree_per_bohr']).sum(axis=1)))) for vs in v['warm_samples']) if forces else None,
  'vibeqc_iterations':[[c['iterations'] for c in x['convergence']] for x in v['warm_samples']],
  'gpu4pyscf_iterations':[[c['iterations'] for c in x['convergence']] for x in g['warm_samples']],
  'metric_diagnostics':r['settings']['density_fitting_metric_diagnostics'],
 })
ablations=[]
for row in rows:
 if row['serial_metric_dot']:
  blas=next(r for r in rows if (r['aos'],r['batch'],r['forces'],r['serial_metric_dot'])==(row['aos'],row['batch'],True,False))
  assert row['vibeqc_iterations']==blas['vibeqc_iterations']
  ablations.append({'aos':row['aos'],'batch':row['batch'],'serial_seconds':row['vibeqc_warm_median_seconds'],'blas_seconds':blas['vibeqc_warm_median_seconds'],'serial_over_blas':row['vibeqc_warm_median_seconds']/blas['vibeqc_warm_median_seconds'],'identical_vibeqc_iteration_rows':True})
profiles=json.loads((root/'force-profile/summary.json').read_text())
large=json.loads((root/'large-force-profile/summary.json').read_text())
assert profiles['library_sha256']==large['library_sha256']==identity['library_sha256']
direct=json.loads((root/'direct-gate/summary.json').read_text())
# Reuse the already retained pre-change controls; these are historical native
# array comparisons, explicitly distinct from a newly rerun control timing.
controls=[]
for batch in (1,4):
 name=f'water-tetramer-def2-svp-spherical-b{batch}-none.json'
 candidate=json.loads((root/'direct-gate'/name).read_text())
 old=json.loads((prior/'direct-control'/name).read_text())
 c,p=candidate['vibeqc']['warm_samples'],old['vibeqc']['warm_samples']
 controls.append({'batch':batch,'candidate_gate':candidate['gate'],'prechange_gate':old['gate'],
 'maximum_native_energy_change':max(float(np.max(np.abs(np.array(x['energies_hartree'])-np.array(y['energies_hartree'])))) for x,y in zip(c,p,strict=True)),
 'maximum_native_force_change':max(float(np.max(np.abs(np.array(x['forces_hartree_per_bohr'])-np.array(y['forces_hartree_per_bohr'])))) for x,y in zip(c,p,strict=True)),
 'candidate_iterations':[[i['iterations'] for i in x['convergence']] for x in c],
 'prechange_iterations':[[i['iterations'] for i in x['convergence']] for x in p]})
(root/'direct-native-control.json').write_text(json.dumps({'scope':'Candidate native arrays compared with the already retained PR #343 pre-change control arrays; no new control timing is claimed. Original strict direct gates remain unchanged.','candidate_library_sha256':identity['library_sha256'],'prechange_library_sha256':'44c140b4d46b69ea7846d8aa2d9aa8cc3bec8c198908fd9e830e9981f78d4bc7','rows':controls},indent=2)+'\n')

def compact(row):
 result={k:row[k] for k in ('aos','budget','stage','serial_metric_dot','seconds','energy','iterations','metric','cuda','host')}
 result['progress_phases']=row['progress']['phases'];result['pending_progress_scopes']=row['progress']['pending']
 if 'memory_samples' in row:
  gpu=[int(line.split(',')[1]) for sample in row['memory_samples'] for line in sample.get('gpu_process_rows',[]) if line.split(',')[1].strip().isdigit()]
  host=[int(line.split()[1])*1024 for sample in row['memory_samples'] for line in sample.get('host_status',[]) if line.startswith('VmHWM:')]
  result.update(sampled_gpu_process_peak_mib=max(gpu,default=None),sampled_host_high_water_bytes=max(host,default=None),memory_sample_count=len(row['memory_samples']),independent_reference_errors=row['independent_reference_errors'])
 return result

files={}
for p in root.rglob('*'):
 if p.name=='evidence-hooks.log':continue
 if p.is_file() and not p.is_symlink() and p.suffix in ('.py','.sh','.json','.jsonl','.txt','.bin','.npz','.log','.patch'):
  files['run/'+str(p.relative_to(root))]=p.read_bytes()
for p in (prior/'direct-control').glob('*.json'):files['historical-prechange-direct/'+p.name]=p.read_bytes()
files['build/CMakeCache.txt']=Path('build/cuda/CMakeCache.txt').read_bytes()
files['run/frozen-attempt1/library.json']=json.dumps({'bytes':identity['library_bytes'],'sha256':identity['library_sha256']},indent=2).encode()
out.mkdir(parents=True,exist_ok=True)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert all(z.read(name)==data for name,data in files.items())
summary={
 'schema':'vibeqc.issue206.metric-gemv.v1','scope':'Five interleaved warm repeats per engine and same-library serial-dot ablations, with all raw results retained. External iteration branches are explicit.',
 'identity':identity,'rebase_identity':json.loads((root/'rebase-identity.json').read_text()),'versions':manifest['versions'],'clean_slurm_job':manifest['slurm_job'],
 'rows':rows,'ablations':ablations,'profiles':{'slurm_job':profiles['slurm_job'],'results':[compact(r) for r in profiles['results']]},'large_profiles':{'slurm_job':large['slurm_job'],'results':[compact(r) for r in large['results']]},
 'direct_regression_gate':direct,'direct_native_control':json.loads((root/'direct-native-control.json').read_text()),
 'validation':{'host_checks':71,'gpu_checks':115,'native_df_default_generated_serial':True,'capture_recovery':True,'occupied_uhf_batch4_memcheck_errors':0,'build_timeout':'Initial 20-minute compile stopped by Slurm; exact incremental build completed in a fresh finite allocation before GPU work.'},
 'acceptance':{'all_repeat_energy_1e_9_and_forces_1e_8':True,'global_resource_qualification':'unchanged: <=16 orbital and <=128 auxiliary AOs','whole_process_memory_and_changed_geometry_budget_matrix':'remaining integration work; sampled process memory and native plan estimates are not a whole-process bound','trackers':'#206/#308/#309/#310/#311 remain open'},
 'archive':{'path':'evidence.zip','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'restoration':'Every archive member restored and compared byte-for-byte.'},
 'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())],
}
required=[r for r in rows if r['aos']==192 and r['forces'] and not r['serial_metric_dot']]
summary['acceptance']['ordinary_192ao_timing_ratios_at_most_one']=all(r['ordinary_vibeqc_over_gpu4pyscf']<=1 for r in required)
summary['acceptance']['shared_192ao_scf_iteration_branches']=all(r['shared_iteration_branch'] for r in required)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
policy=Path('benchmarks/evidence-policy.json');p=json.loads(policy.read_text())
p['exceptions'][str(archive)]={'owner':'issue206-metric-gemv','reason':'Complete repeated FP64 GEMV/serial-dot ablations, RHF/UHF external comparisons, basis/factor qualification, direct gates and retained controls, component/memory profiles, source reconstruction, validation and build timeout evidence.','sha256':summary['archive']['sha256']}
policy.write_text(json.dumps(p,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary['archive']))

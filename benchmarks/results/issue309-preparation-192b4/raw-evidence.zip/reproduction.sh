#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-pr355-n3
export PYTHONPATH=python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
PY=/home/jzzeng/miniconda3/bin/python3
LIB=build/n3-pr355/libvibeqc.so
for slice in lazy-core overlap-cache combined; do
  for kind in profiled energy force; do
    out="/tmp/vibeqc-309-closure-192b4-${slice}-${kind}"
    trace="/tmp/vibeqc-309-closure-192b4-${slice}-traces"
    opts=()
    if [[ "$kind" != force ]]; then opts+=(--energy-only); fi
    if [[ "$kind" == profiled ]]; then opts+=(--host-trace-dir "$trace"); fi
    "$PY" benchmarks/issue206_df_matrix.py --run --host-workloads \
      --preparation-ablation "$slice" \
      --case water-octamer-s4-def2-svp-spherical --batch 4 \
      --library "$LIB" --memory-budget-bytes 1073741824 --repeats 5 \
      "${opts[@]}" --output-dir "$out"
  done
done

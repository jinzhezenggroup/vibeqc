#!/usr/bin/env bash
set -euo pipefail
root=/inspire/qb-ilm/project/chemicalreaction/diwenxi-CZXS25120072/vibeqc-workspace
source "$root/activate-311.sh"
task="$root/build-171/grid-20260917"
evidence="$task/evidence"
trap 'echo $? > "$evidence/performance.exit"' EXIT
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$task/source"
export PYTHONPATH="$PWD/python"
# Retain the initial outlier sample; collect a predefined ABBA follow-up rather
# than selectively replacing measurements that did not support the hypothesis.
for label in baseline-a candidate-a candidate-b baseline-b; do
  if [[ "$label" == baseline-* ]]; then
    export VIBEQC_LIBRARY="$task/baseline-libvibeqc.so"
  else
    export VIBEQC_LIBRARY="$task/cuda/libvibeqc.so"
  fi
  nvidia-smi --query-gpu=name,temperature.gpu,clocks.sm,clocks.mem,power.draw,utilization.gpu --format=csv > "$evidence/performance-$label-gpu.csv"
  python tools/benchmark_ecp.py --device cuda --repeats 5 --output "$evidence/performance-$label.json" > "$evidence/performance-$label.log" 2>&1
done

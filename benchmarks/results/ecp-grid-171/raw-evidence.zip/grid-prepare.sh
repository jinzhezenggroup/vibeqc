#!/usr/bin/env bash
set -euo pipefail
root=/inspire/qb-ilm/project/chemicalreaction/diwenxi-CZXS25120072/vibeqc-workspace
cd "$root"
source activate-311.sh
task="$root/build-171/grid-20260917"
mkdir "$task"
mkdir "$task/source" "$task/candidate" "$task/evidence"
tar -xzf evidence-171/grid-baseline.tar.gz -C "$task/source"
tar -xzf evidence-171/grid-baseline.tar.gz -C "$task/candidate"
tar -xzf evidence-171/grid-changes.tar.gz -C "$task/candidate"
cd "$task/candidate"
ruff check tests/python/test_ecp_ir.py python/vibeqc_compiler/integral/ecp_grid.py python/vibeqc_compiler/integral/ecp_projector.py
ruff format tests/python/test_ecp_ir.py python/vibeqc_compiler/integral/ecp_grid.py python/vibeqc_compiler/integral/ecp_projector.py
clang-format -i src/integrals/ecp.cpp src/integrals/ecp_cuda.cu tests/native/test_ecp_projector.cpp
python -I -S tools/generate_ecp_kernels.py --output "$task/generated_ecp_ao.cuh"
c++ -std=c++20 -O2 -Wall -Wextra -Werror -I "$task" tests/native/test_ecp_projector.cpp -o "$task/grid-test"
"$task/grid-test"
tar -czf "$root/evidence-171/grid-formatted.tar.gz" python/vibeqc_compiler/integral/ecp_grid.py python/vibeqc_compiler/integral/ecp_projector.py src/integrals/ecp.cpp src/integrals/ecp_cuda.cu tests/native/test_ecp_projector.cpp tests/python/test_ecp_ir.py

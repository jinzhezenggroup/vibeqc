"""Retain measured ECP host-grid qualification and exact source identities."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path('/inspire/qb-ilm/project/chemicalreaction/diwenxi-CZXS25120072/vibeqc-workspace')
TASK = ROOT / 'build-171/grid-20260917'
evidence = TASK / 'evidence'
for kind in ('baseline', 'cpu', 'cuda', 'performance'):
    assert (evidence / (kind + '.exit')).read_text().strip() == '0', kind
for name in ('prepare.sh', 'run.sh', 'provenance.py', 'collect.py', 'performance.sh'):
    shutil.copyfile(ROOT / 'evidence-171' / ('grid-' + name), evidence / ('grid-' + name))
shutil.copyfile(ROOT / 'evidence-171/grid-formatted.tar.gz', evidence / 'source-overlay.tar.gz')
for label, build in [('candidate', 'cuda'), ('cpu', 'cpu')]:
    shutil.copyfile(TASK / build / 'CMakeCache.txt', evidence / (label + '-CMakeCache.txt'))
baseline = json.loads((evidence / 'baseline-benchmark.json').read_text())
candidate = json.loads((evidence / 'candidate-benchmark.json').read_text())
summary = {'baseline': baseline, 'candidate': candidate, 'provenance': {}}
summary['performance_followup'] = {
    'reason': 'Initial candidate UHF warm samples showed a large spread; retain them and collect predefined ABBA comparisons.',
    'order': ['baseline-a', 'candidate-a', 'candidate-b', 'baseline-b'],
    'runs': {},
}
for label in summary['performance_followup']['order']:
    record = json.loads((evidence / ('performance-' + label + '.json')).read_text())
    expected = baseline if label.startswith('baseline-') else candidate
    assert record['library_sha256'] == expected['library_sha256'], label
    summary['performance_followup']['runs'][label] = record
for label in ('baseline', 'candidate', 'cpu'):
    record = json.loads((evidence / (label + '-provenance.json')).read_text())
    record.pop('source_files')
    summary['provenance'][label] = record
assert summary['provenance']['candidate']['source_manifest_sha256'] == summary['provenance']['cpu']['source_manifest_sha256']
assert (evidence / 'baseline-resources.txt').read_bytes() == (evidence / 'candidate-resources.txt').read_bytes(), 'kernel resources changed; inspect before making an unchanged-resource claim'
out = ROOT / 'evidence-171/grid-results'
out.mkdir(exist_ok=True)
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
records = []
with zipfile.ZipFile(out / 'raw-evidence.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(evidence.iterdir()):
        if not path.is_file():
            continue
        data = path.read_bytes()
        records.append({'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        archive.writestr(path.name, data)
raw = (out / 'raw-evidence.zip').read_bytes()
(out / 'raw-evidence.manifest.json').write_text(json.dumps({
    'schema': 'vibeqc.evidence-archive.v1', 'archive_bytes': len(raw),
    'archive_sha256': hashlib.sha256(raw).hexdigest(), 'files': records,
}, indent=2) + '\n')
print('Archived', len(records), 'files;', len(raw), 'bytes')

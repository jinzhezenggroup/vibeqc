#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. VIBEQC_LIBRARY="$PWD/build/cuda/libvibeqc.so"
export VIBEQC_RESOURCE_CUDA_TEST=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
printf 'Slurm-job:%s\n' "$SLURM_JOB_ID"
sha256sum build/cuda/libvibeqc.so.0.1.0
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_preparation_cuda.py tests/python/test_df_property_budget_cuda.py tests/python/test_hf_resources_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_df_retry_eigen_cuda.py
for mode in energy tensor generated; do
  forces=0
  generated=0
  if [[ "$mode" != energy ]]; then forces=1; fi
  if [[ "$mode" == generated ]]; then generated=1; fi
  /usr/bin/time -v .artifacts/issue308-budgets/prepare-large .artifacts/issue308-stage/input-768/input.txt "$forces" "$generated" ".artifacts/issue308-budgets/$mode-overlap.bin" > ".artifacts/issue308-budgets/$mode-768.json" 2> ".artifacts/issue308-budgets/$mode-768.time"
done

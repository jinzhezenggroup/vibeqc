"""Publish bounded preparation results; preserve the rejected cache-policy attempt."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,zipfile
root=Path(__file__).resolve().parent
out=Path('benchmarks/results/issue308-property-budgets');out.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
files={}
rows=[]
for mode in ['energy','tensor','generated']:
 r=json.loads((root/f'{mode}-768.json').read_text())
 if (root/f'{mode}-validated.json').exists():r.update(json.loads((root/f'{mode}-validated.json').read_text()))
 r['host_process_peak_rss_bytes']=1024*int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',(root/f'{mode}-768.time').read_text())[1])
 rows.append({'mode':mode,**r})
 files[f'{mode}-768.json']=(root/f'{mode}-768.json').read_bytes()
files['reproduction/prepare-large.cpp']=(root/'prepare-large.cpp').read_bytes()
files['reproduction/run-validation.sh']=(root/'run-validation.sh').read_bytes()
files['reproduction/input.json']=Path('.artifacts/issue308-stage/input-768/input.json').read_bytes()
files['reproduction/source.patch']=subprocess.check_output(['git','diff','HEAD','--','src','include'])
files['reproduction/CMakeCache.txt']=Path('build/cuda/CMakeCache.txt').read_bytes()
files['reproduction/retain.py']=Path(__file__).read_bytes()
for name in ['rhf.cpp','df_preparation_budget.hpp']:
 files['rejected-initial-budget/'+name]=Path('.artifacts/issue308-frozen-budget-initial',name).read_bytes()
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out/'evidence.zip') as z:
 assert all(z.read(name)==data for name,data in files.items())
lib=Path('build/cuda/libvibeqc.so.0.1.0');frozen=Path('.artifacts/issue308-frozen-budget-final/libvibeqc.so.0.1.0');frozen.parent.mkdir(exist_ok=True)
if not frozen.exists():shutil.copy2(lib,frozen)
assert sha(lib.read_bytes())==sha(frozen.read_bytes())
result={
 'schema':'vibeqc.issue308.property-budget-evidence.v1',
 'scope':'Native preparation isolation with a 1 GiB DF subbudget; this is not SCF, full 768-AO force execution, global-resource acceptance or clean performance.',
 'slurm_job':'9548','hardware':'Slurm main gpu:5090:1 on node3; preserved CUDA_VISIBLE_DEVICES. No new driver or GPU-memory query was recorded in this job.',
 'source':{'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'dirty':True,'patch':'reproduction/source.patch','native_source_identity':rows[0]['source_identity'],'library':str(lib.resolve()),'library_sha256':sha(lib.read_bytes()),'frozen_library':str(frozen.resolve()),'probe_sha256':sha((root/'prepare-large').read_bytes())},
 'request':{'case':'water-32mer-4s4-def2-svp-spherical','nbf':768,'cartesian_nbf':800,'atoms':96,'df_subbudget_bytes':1<<30,'metric_relative_threshold':1e-10,'input_sha256':sha(Path('.artifacts/issue308-stage/input-768/input.txt').read_bytes()),'independent_reference':'PySCF 2.14.0 fixture from ../issue308-stage-ledger; overlap gate 1e-10, full-matrix comparison.'},
 'runs':rows,
 'validation':{'gpu_tests':96,'gpu_test_seconds':118.97,'gpu_files':['test_df_preparation_cuda.py','test_df_property_budget_cuda.py','test_hf_resources_cuda.py','test_df_final_state_cuda.py','test_df_retry_eigen_cuda.py'],'gpu_log_sha256':sha(Path('/tmp/vibeqc-308-budgets-gpu-3.log').read_bytes()),'small_full_force_case':'96-AO tetramer E→force→E at 64 MiB; energy resident, force streamed; both tensor/generated one-electron providers pass complete PySCF forces at 1e-8 absolute and energy at 1e-9. These are regression gates, not a repeated #206 timing matrix.','cpu_checks':'23 shape/resource tests, CPU syntax-only compilation, 95 structure/preparation tests, all pre-commit checks; overlapping counts not summed.'},
 'rejected_initial_candidate':{'slurm_job':'9547','library_sha256':'0ac376a56a942f172f1edc00dbf4f3171fa14fe634d52f1d08a305a7290df74a','disposition':'Rejected: E→force replay kept the larger energy CUDA plan because positive-budget fleets retain no host data cache. Fixed by recording value allowance in the device plan and invalidating it before replacement preparation. Other four failures were a test attempting to compare omitted None forces; assertions now respect requested properties.','source_reconstruction':'Base commit plus the two complete native source overrides in rejected-initial-budget/. The frozen measured library remains in .artifacts/issue308-frozen-budget-initial/.','log_sha256':sha(Path('/tmp/vibeqc-308-budgets-gpu-2.log').read_bytes())},
 'archive':{'path':'evidence.zip','bytes':(out/'evidence.zip').stat().st_size,'sha256':sha((out/'evidence.zip').read_bytes()),'restoration':'All selected members byte-restored.'},
 'files':[{'path':n,'bytes':len(d),'sha256':sha(d)} for n,d in sorted(files.items())],
}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
policy=Path('benchmarks/evidence-policy.json');m=json.loads(policy.read_text());m['exceptions'][str(out/'evidence.zip')]={'owner':'issue308-property-budgets','reason':'Bounded native preparation outputs, exact accepted/initial-rejected native source reconstruction, input identity and reproduction commands; excludes binaries, routine logs and full transient matrices. Every member byte-restored.','sha256':result['archive']['sha256']};policy.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
print(result['archive'])

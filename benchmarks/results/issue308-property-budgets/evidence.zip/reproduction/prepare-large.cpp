#include "molecule/basis.hpp"
#include "scf/density_fitting.hpp"
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
namespace vibeqc::scf {
std::vector<std::optional<DensityFittingScfData>> prepare_cuda_density_fitting_batch(
    const std::vector<core::System>&, const std::optional<core::System>&,
    double, std::size_t, int, std::vector<vibeqc_status>&, bool);
}
int main(int argc,char**argv) {
  using namespace vibeqc;
  if(argc!=5 || !std::getenv("SLURM_JOB_ID"))return 1;
  std::ifstream input(argv[1]);std::string magic;std::size_t atoms,shells,rank;int repr;
  input>>magic>>atoms>>shells>>repr>>rank;
  core::System system;system.basis_representation=static_cast<vibeqc_basis_representation>(repr);
  system.atoms.resize(atoms);system.shells.resize(shells);
  for(auto&atom:system.atoms)input>>atom.atomic_number>>atom.position[0]>>atom.position[1]>>atom.position[2];
  for(auto&shell:system.shells){std::size_t n;input>>shell.atom_index>>shell.angular_momentum>>n;shell.primitives.resize(n);for(auto&p:shell.primitives)input>>p.exponent>>p.coefficient;}
  std::string detail;if(!input||magic!="vibeqc-stage-v1"||molecule::validate_and_normalize(system,detail)!=VIBEQC_STATUS_SUCCESS)return 2;
  const bool forces=std::stoi(argv[2]);const bool generated=std::stoi(argv[3]);
  setenv("VIBEQC_ONE_ELECTRON_DERIVATIVES",generated?"generated":"tensor",1);
  std::vector<vibeqc_status> statuses;const auto begin=std::chrono::steady_clock::now();
  const auto result=scf::prepare_cuda_density_fitting_batch({system},std::nullopt,1e-10,std::size_t{1}<<30,0,statuses,forces);
  const auto seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count();
  std::cout<<std::setprecision(17)<<"{\"source_identity\":"<<std::quoted(vibeqc_get_source_identity())<<",\"seconds\":"<<seconds<<",\"forces\":"<<forces<<",\"generated\":"<<generated<<",\"accepted\":"<<bool(result[0])<<",\"failure_status\":"<<(result[0]?0:statuses[0]);
  if(result[0]){const auto&d=result[0]->one_electron;std::cout<<",\"nbf\":"<<d.nbf<<",\"derivative_values\":"<<(d.overlap_derivative.size()+d.hcore_derivative.size())<<",\"nuclear_values\":"<<d.nuclear_repulsion_derivative.size();
  std::ofstream arrays(argv[4],std::ios::binary);arrays.write(reinterpret_cast<const char*>(d.overlap.data()),d.overlap.size()*sizeof(double));}
  std::cout<<"}\n";
  return result[0] || (forces&&!generated&&statuses[0]==VIBEQC_STATUS_OUT_OF_MEMORY)?0:3;
}

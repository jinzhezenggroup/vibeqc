"""Run bounded review validation inside a Slurm allocation and bind its sources."""
import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path(sys.argv[1]).resolve()
out=pathlib.Path(sys.argv[2]).resolve(); out.mkdir(parents=True,exist_ok=True)
mode=sys.argv[3]
assert os.environ.get('SLURM_JOB_ID'), 'GPU validation requires Slurm'
def run(args, name, env):
 start=time.monotonic()
 with (out/name).open('w') as f:
  result=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True)
 return {'command':list(map(str,args)),'log':name,'exit_code':result.returncode,'seconds':time.monotonic()-start}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True)
# Only CMake outputs under this explicit build directory are excluded. All
# tracked changes and any other untracked paths make the source dirty.
source_status=[x for x in status.splitlines() if not x.startswith('?? build-review/')]
manifest={'schema':'vibeqc.pr-review-native-validation.v1','source':{'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'dirty':bool(source_status),'status':source_status,'excluded_build_directory':'build-review/'},'slurm_job_id':os.environ['SLURM_JOB_ID'],'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],text=True).strip(),'nvcc_version':subprocess.check_output(['/group/software/cuda-12.9.1/bin/nvcc','--version'],text=True).strip(),'library_sha256':digest(root/'build-review/libvibeqc.so'),'cmake_cache_sha256':digest(root/'build-review/CMakeCache.txt'),'checks':[]}
assert not source_status,source_status
tracked=subprocess.check_output(['git','ls-files','src','include','python','tools','CMakeLists.txt','cmake','tests'],cwd=root,text=True).splitlines()
manifest['source_files']={name:digest(root/name) for name in tracked if (root/name).is_file()}
env=os.environ.copy(); env.update(PYTHONPATH=str(root/'python')+':'+str(root),VIBEQC_LIBRARY=str(root/'build-review/libvibeqc.so'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VIBEQC_RESOURCE_CUDA_TEST='1',VIBEQC_ECP_CUDA_TEST='1')
python='/tmp/vibeqc-open-pr-review-20260915/venv/bin/python'
if mode=='ks':
 manifest['checks'].append(run(['ctest','--test-dir','build-review','--output-on-failure','-R','vibeqc_(ks|final_state|eigen_frame|dft|uks).*tests'], 'native.log',env))
 manifest['checks'].append(run([python,'-m','pytest','tests/python/test_ks_diagnostics.py','tests/python/test_ks_resources.py','tests/python/test_ks_options.py','-q'], 'python.log',env))
 manifest['checks'].append(run(['/group/software/cuda-12.9.1/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','99',str(root/'build-review/vibeqc_ks_cuda_tests')], 'sanitizer.log',env))
elif mode=='ecp':
 manifest['checks'].append(run(['ctest','--test-dir','build-review','--output-on-failure','-R','vibeqc_ecp_'], 'native.log',env))
 manifest['checks'].append(run([python,'-m','pytest','tests/python/test_ecp.py','tests/python/test_ecp_ir.py','tests/python/test_ecp_validation.py','-q'], 'python.log',env))
 manifest['checks'].append(run(['/group/software/cuda-12.9.1/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','99',str(root/'build-review/vibeqc_ecp_cuda_error_tests')], 'sanitizer.log',env))
if mode in ('ecp','ecp-baseline'):
 manifest['checks'].append(run([python,'tools/benchmark_ecp.py','--device','cuda','--repeats','3','--output',str(out/'benchmark.json')], 'benchmark.log',env))
 (out/'generated-header.cuh').write_bytes((root/'build-review/generated/generated_ecp_ao.cuh').read_bytes())
 (out/'resources.txt').write_text(subprocess.check_output(['/group/software/cuda-12.9.1/bin/cuobjdump','--dump-resource-usage',str(root/'build-review/libvibeqc.so')],text=True))
manifest['passed']=all(x['exit_code']==0 for x in manifest['checks'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
sys.exit(0 if manifest['passed'] else 1)

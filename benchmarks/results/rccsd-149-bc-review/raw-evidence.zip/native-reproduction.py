"""Exercise native RHF/integral preparation followed by the GPU energy facade."""
import hashlib,json,os,subprocess
from pathlib import Path
import numpy as np
from tools.cc_endpoint_fixtures import load,source_arguments
from tools.vibeqc_cc import SolverOptions,energy,batch_energy
from tools.vibeqc_posthf.export import export_rhf
from tools.vibeqc_posthf.providers import ConventionalProvider
from tools.vibeqc_posthf.sources import NativeSource
from vibeqc_compiler.common.cuda_adapter import CudaCompilerAdapter
from vibeqc_compiler.common.cuda_target import cuda_target_info
compiler=CudaCompilerAdapter(Path('/group/software/cuda-12.9.1/bin/nvcc'),cuda_target_info('sm_120'))
report={'source':{'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'dirty':bool(subprocess.check_output(['git','status','--porcelain']))},'slurm_job_id':os.environ['SLURM_JOB_ID'],'native_library_sha256':hashlib.sha256(Path(os.environ['VIBEQC_LIBRARY']).read_bytes()).hexdigest(),'cases':[]}
for name in ('h2','he','h2o','nh3','ch4'):
 meta,a=load(name)
 with NativeSource(**source_arguments(meta['inputs'])) as source:
  snapshot,_=export_rhf(source,tolerance=1e-12,max_iterations=150)
  with ConventionalProvider(snapshot,source) as provider:
   result=energy(snapshot,provider,backend='cuda',compiler=compiler,cache=Path('../cc-cache'),options=SolverOptions(residual_tolerance=1e-10,energy_tolerance=1e-12))
   error=abs(result.total_energy-meta['total_energy'])
   assert result.converged and error<=1e-8,(name,result.reason,error)
   report['cases'].append({'name':name,'energy_error':error,'iterations':result.iterations,'r1':result.final_r1_max,'r2':result.final_r2_max,'passed':True})
   print(name,error,flush=True)
   if name=='h2':
    batch=batch_energy([(snapshot,provider),(snapshot,object()),(snapshot,provider)],backend='cuda',compiler=compiler,cache=Path('../cc-cache'))
    assert [item.status for item in batch.items]==['converged','error','converged']
    report['batch_statuses']=[item.status for item in batch.items]
report['passed']=True
Path('../cc-validation/native-endpoints.json').write_text(json.dumps(report,indent=2)+'\n')

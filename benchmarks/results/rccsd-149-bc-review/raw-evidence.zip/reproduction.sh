#!/usr/bin/env bash
set -euo pipefail
# Run from the source revision recorded in manifest.json inside a finite Slurm
# allocation. NVCC, native library, Python environment and cache are explicit.
: "${SLURM_JOB_ID:?Run through srun on main with --gres=gpu:5090:1}"
: "${VIBEQC_NVCC:?Set NVCC path}"
: "${VIBEQC_LIBRARY:?Set matching native library path}"
export PYTHONPATH=.:python OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VIBEQC_CC_CUDA_TEST=1 VIBEQC_TENSOR_ARCH=sm_120
python -m pytest tests/python/test_cc*.py -q
python -m tools.validate_cc_gpu_solver --output .artifacts/cc-review \
  --cache .cache/tensor --nvcc "$VIBEQC_NVCC" --architecture sm_120

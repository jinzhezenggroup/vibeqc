#ifndef VIBEQC_BUILD_IDENTITY_HPP
#define VIBEQC_BUILD_IDENTITY_HPP

// The CMake input inventory includes native code and codegen/runtime policy.
inline constexpr const char* kVibeqcSourceIdentity = "2edd5723c767c4006e2d743cf9b0ba09744685efd7038db89c367669297f14d2";
#define VIBEQC_CUDA_FAST_COMPILE 0
#define VIBEQC_TUNING_RELEASE_BUILD 1

#endif

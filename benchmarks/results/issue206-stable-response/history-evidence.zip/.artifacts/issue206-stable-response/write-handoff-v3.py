"""Advance completed evidence to v7 while preserving prior handoffs and failures."""
import json
from datetime import datetime, timezone
from pathlib import Path

worktree = Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root = worktree / '.artifacts/issue206-stable-response'
current = root / 'current-handoff.json'
prior = root / 'handoff-before-v3.json'
if not prior.exists():
    prior.write_bytes(current.read_bytes())
latest = json.loads(current.read_text())
latest['observed_at_utc'] = datetime.now(timezone.utc).isoformat()
latest['latest_frozen_candidate'] = json.loads((root / 'candidate-v7/manifest.json').read_text())
latest['previous_candidates']['v6'] = json.loads((root / 'candidate-v6/manifest.json').read_text())['library_sha256']
latest['pending_jobs_at_update'] = {}
for name in ('budget-boundaries-v2', 'streamed-memcheck-v1', 'larger-batch-v1', 'qualification-v7', 'packed-bounded-v1', 'resource-contract-v1', 'resource-contract-v2'):
    report = json.loads((root / name / 'report.json').read_text())
    latest['reports'][name] = {k: report[k] for k in ('status', 'slurm_job_id', 'rows') if k in report}
latest['completed_evidence_audit'] = str(root / 'completed-checkpoint-v2.json')
latest['v6_budget_result'] = 'Slurm9928: 12 completed endpoints pass (E<=2.388e-12,F<=9.004e-13); dense80/packed160MiB cold OOM retained. Dense96MiB: one tensor, one raw pass, 50,280,768 response bytes.'
latest['targeted_memcheck_result'] = 'Slurm9929 native one-tensor regression and 4 streamed-J/K probes: zero errors; Slurm9931 native including three-Q packed overlap: zero errors. Slurm9926 full-force timeout remains not passed.'
latest['larger_batch_job']['status'] = 'completed, four configurations /24 item endpoints pass'
latest['larger_batch_result'] = 'Slurm9930 v6: 24 endpoints, E<=5.685e-12,F<=1.515e-12; full metric ranks928/464. Both octamer configs actually use bounded resident C, not occupied; tetramerB2 packed admits rank20 occupied, dense uses full tensor. v7 larger packed route not covered by this job.'
latest['v7_extension'] = 'Packed bounded response projects each whole panel by one GEMM, stages packed slices in spare AO scratch, then unpacks ascending Q with proven non-overlap. Counts staging bytes/copies.'
latest['v7_qualification'] = 'Slurm9931: native and native memcheck pass; 41 Python regressions pass; 8 dense/packed private16MiB endpoints pass. Packed per endpoint:64 fitted GEMMs instead of3712 GEMVs, same16,660,800 owned bytes, no raw reads,3712 staging copies/138,264,576 bytes. No latency admission.'
latest['test_contract_split'] = 'Current Python source separates 13 numerical-success cases from3 explicit lower-bound resource rejections. Slurm9932 OH packed passes, all3 rejection statuses correct but fail an incorrect empty-diagnostics assertion. Slurm9933 fixes the assertion to the existing NotImplementedError contract;3 pass. Both test-source snapshots/logs retained; v7 native library unchanged.'
latest['remaining_boundaries'] = ['Response without resident C and without space for one complete fitted tensor still uses the old general route and is unqualified.', 'Streamed Coulomb with scratch shorter than Naux retains the old inverse-root route.', 'Host-streamed compatibility whitening remains unchanged.', 'Original1e-10 first-changed force remains failed; no clean performance or stock GPU4PySCF acceptance.']
latest['next'] = ['Decouple generation-validated canonical-factor borrowing from complete raw/J/K tensor borrowing for genuinely streamed bounded response; preserve exact density/token checks and source work.', 'Qualify larger packed v7 only if that changed route is in the proposed scope.', 'Prepare a reviewable numerical change only after its bounded fallback scope is explicit and independently validated; no numerical PR yet.', 'Keep #415 switch, #206 open, #427 draft; no benchmark admission from these diagnostics.']
latest['evidence_manifest'] = str(root / 'evidence-manifest-v2.json')
current.write_text(json.dumps(latest, indent=2) + '\n')
for work, artifact in [('issue206-auxiliary','issue206-auxiliary'), ('issue206-response-diagnosis','issue206-response-diagnosis'), ('issue206-post418','issue206-post418'), ('issue418-cooperative-rys','issue418'), ('issue206-direct-fix','issue206'), ('issue409-packed','issue409')]:
    path = Path('/home/jzzeng/codes') / ('vibeqc-' + work) / '.artifacts' / artifact / 'current-handoff.json'
    data = json.loads(path.read_text())
    data['latest_stable_response_update'] = {k: v for k, v in latest.items() if k not in ('latest_frozen_candidate', 'reports')}
    data['latest_stable_response_update']['authoritative_handoff'] = str(current)
    path.write_text(json.dumps(data, indent=2) + '\n')
print('Updated v7 and all six historical pointers. Previous handoff saved separately.')

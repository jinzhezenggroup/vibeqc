"""Freeze the completed source/build/library identity before numerical checks."""
import hashlib
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

root = Path('.artifacts/issue206-stable-response')
out = root/'candidate-v5'
out.mkdir(exist_ok=False)

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

patch = subprocess.check_output(['git','diff','--binary','HEAD'])
(out/'source.patch').write_bytes(patch)
changed = subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines()
changed += ['tests/python/test_df_practical_response_cuda.py',
            '.agents/notes/proposed/2026-09-17-full-rank-response-candidate.md']
for name in changed:
    target = out/'source'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(name,target)
for source in (Path('build/cuda/libvibeqc.so'), Path('build/cuda/generated/build_identity.hpp'),
               Path('build/cuda/CMakeCache.txt'), root/'configure-v1.txt', root/'build-v1.txt',
               root/'incremental-build-v5.txt', root/'qualify-candidate-controls-v5.py',
               root/'run-qualification-v5.py', Path(__file__)):
    shutil.copy2(source,out/source.name)
identity = re.search(r'kVibeqcSourceIdentity = "([0-9a-f]+)"',
                     (out/'build_identity.hpp').read_text()).group(1)
manifest = {'scope': 'Uncommitted changed numerical candidate, not performance-qualified',
            'created_at_utc': datetime.now(timezone.utc).isoformat(),
            'git_head': subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            'git_branch': subprocess.check_output(['git','branch','--show-current'],text=True).strip(),
            'native_source_identity': identity,
            'library_sha256': digest(out/'libvibeqc.so'),
            'library_bytes': (out/'libvibeqc.so').stat().st_size,
            'records': {str(p.relative_to(out)):digest(p) for p in sorted(out.rglob('*')) if p.is_file()}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for path in out.rglob('*'):
    if path.is_file():
        path.chmod(0o444)
print(json.dumps({k:v for k,v in manifest.items() if k != 'records'},indent=2))

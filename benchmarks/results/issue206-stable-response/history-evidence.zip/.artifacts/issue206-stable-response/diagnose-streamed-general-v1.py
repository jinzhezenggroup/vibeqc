"""Predeclared untimed v12 general/canonical streamed full-force boundary.

Octamer cc-pVDZ/JKFIT,384MiB total and192MiB private response. Preserve the failed
v10 cold endpoint. Every new phase must pass energy/force3e-11 at density1e-12
and select a stable general fitted-factor or exact canonical occupied route.
No old raw-Gram fallback, gate relaxation or timing admission is accepted.
"""
import hashlib
import importlib.util
import json
import os
import traceback
from pathlib import Path
from types import SimpleNamespace

assert os.environ.get('SLURM_JOB_ID')
root = Path('.artifacts/issue206-stable-response')
out = root / 'streamed-general-v1'
out.mkdir(exist_ok=False)
lib = (root / 'candidate-v12/libvibeqc.so').resolve()
frozen = json.loads((root / 'candidate-v12/manifest.json').read_text())
with lib.open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest() == frozen['library_sha256']
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str(lib), VIBEQC_RESOURCE_CUDA_TEST='1',
                  OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
import pytest
source = Path('tests/python/test_df_practical_response_cuda.py')
assert source.read_bytes() == (root/'candidate-v12/source'/source).read_bytes()
(out/'test-source.py').write_bytes(source.read_bytes())
spec = importlib.util.spec_from_file_location('practical_response_test', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
settings = [('octamer-total384', 'dense', 384 << 20, 192 << 20)]
report = {'scope': __doc__, 'status':'running', 'slurm_job_id':os.environ['SLURM_JOB_ID'],
          'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'), 'frozen':frozen,
          'predeclared_settings':settings, 'rows':[]}
def save():
    (out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
save()
try:
    import numpy as np
    cached_path=root/'larger-reference-v1/report.json'
    cached=json.loads(cached_path.read_text())
    assert cached['status']=='completed'
    report['cpu_reference_verified_inputs']={}
    for path,digest in cached['input_sha256'].items():
        # Verify the actual historical reference generator, not today's test.
        original=(root/'candidate-v6/source'/path) if path.startswith('tests/') else Path(path)
        assert hashlib.sha256(original.read_bytes()).hexdigest()==digest
        report['cpu_reference_verified_inputs'][str(original)]=digest
    key='water-octamer-s4-def2-svp-spherical'
    saved=cached['cases'][key]
    case,orbital,auxiliary,_,_=module._practical_model(key)
    assert [(s,list(x)) for s,x in case.atoms]==[(s,list(x)) for s,x in saved['original_geometry']]
    moved=[(s,np.array(x)) for s,x in saved['changed_geometry']]
    oracle=[(row['energy'],np.array(row['forces'])) for row in saved['references']]
    reference=(case,orbital,auxiliary,moved,oracle)
    report['cpu_reference_report_sha256']=hashlib.sha256(cached_path.read_bytes()).hexdigest()
    report['references'] = [{'energy':e, 'forces':f.tolist()} for e,f in reference[-1]]
    save()
    for name, values, budget, response_budget in settings:
        directory=out/name
        directory.mkdir()
        row={'name':name,'status':'running'}
        report['rows'].append(row)
        save()
        try:
            with pytest.MonkeyPatch.context() as mp:
                # Public budget partitions both owners; the private override is forbidden here.
                mp.setenv('VIBEQC_DF_PROGRESS_TRACE',str(directory/'progress.jsonl'))
                mp.setenv('VIBEQC_DF_RESIDENT_EXCHANGE','auto')
                module.test_practical_full_force_cold_warm_and_changed_geometry(
                    mp, directory, reference, values, 'panel', 'occupied', 'blas', budget)
            identity=json.loads((directory/'identity.json').read_text())['native_build']
            assert identity['library_sha256']==frozen['library_sha256']
            assert identity['probe']['source_identity']==frozen['native_source_identity']
            row['phase_work']={}
            # Numerical success alone does not establish coverage of the route.
            for phase in ('cold','warm','changed','changed_warm'):
                events=[json.loads(line) for line in (directory/(phase+'.jsonl')).read_text().splitlines()]
                occupied=[event for event in events if event.get('operation')=='ri_k_occupied'
                          and event.get('counters',{}).get('occupied_rank',0)>0]
                assert occupied, phase
                for event in occupied:
                    counts=event['counters']
                    assert event['valid'] and event['source_backed'] and event['streamed']
                    assert counts['streamed_occupied_source_first']==1
                    assert counts['occupied_rank']==40
                    assert counts['streamed_occupied_row_blocks']==9
                    assert counts['streamed_occupied_raw_generation_rows']==984
                    assert counts['raw_panel_source_auxiliary_evaluations']==984*192*928
                    assert counts['streamed_occupied_scratch_capacity_bytes']==4*829440*8
                row['phase_work'][phase]={'occupied_K_records':len(occupied),
                    'raw_generation_rows_per_K':984,'equivalent_raw_passes_per_K':984/192,
                    'four_existing_buffer_bytes':4*829440*8}
                responses=[event for event in events if event.get('operation')=='force_response']
                assert len(responses)==1
                counters=responses[0]['counters']
                assert responses[0]['valid']
                general=counters.get('response_streamed_general_factor_first')==1
                canonical=counters.get('response_streamed_occupied_factor_first')==1
                assert general != canonical, counters
                if general:
                    assert counters['response_full_rank_bounded_factor_first']==1
                    assert counters['response_streamed_fitting_raw_passes']==16
                    assert counters['raw_tile_productions']==640
                    assert counters['raw_value_bytes']==16*192*192*928*8
                    assert not counters.get('response_borrowed_occupied_factor_bytes',0)
                else:
                    assert counters['response_streamed_occupied_raw_passes']==1
                    assert counters['raw_tile_productions']==928
                    assert counters['raw_value_bytes']==192*192*928*8
                    assert counters['response_borrowed_occupied_factor_bytes']==192*40*8
                row['phase_work'][phase]['response_route']='general' if general else 'canonical'
                row['phase_work'][phase]['K_trace_execution_kinds']=[e['execution'] for e in occupied]
                row['phase_work'][phase]['response_counters']={k:v for k,v in counters.items() if not k.startswith('shell_')}
                assert counters.get('response_scratch_bytes')<=response_budget
                assert not counters.get('response_borrowed_whitened_bytes',0)
                assert not counters.get('response_borrowed_jk_bytes',0)
            row['status']='passed' 
        except (Exception, pytest.fail.Exception):
            row.update(status='failed', exception=traceback.format_exc())
        save()
        print(name,row['status'],flush=True)
    report['status']='passed' if all(r['status']=='passed' for r in report['rows']) else 'failed; all settings retained'
finally:
    save()

if report['status'] != 'passed':
    raise SystemExit(1)

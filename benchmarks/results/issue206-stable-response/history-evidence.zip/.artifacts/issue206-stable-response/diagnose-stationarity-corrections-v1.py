"""CPU-only fixed-density correction study of the preserved v2 failure.

Five predeclared densities (saved density plus four physical-Fock corrections)
separate stationarity from lagged Pulay weights. This does not qualify v12,
change production tolerances, or replace any retained failed native endpoint.
"""
import hashlib
import json
import os
import traceback
from pathlib import Path

import numpy as np
import pyscf
from pyscf import gto, scf

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis

root = Path('.artifacts/issue206-stable-response')
out = root / 'stationarity-corrections-v1'
out.mkdir(exist_ok=False)
old = json.loads((root / 'changed-density-v1/report.json').read_text())
case = benchmark_cases()['water-tetramer-def2-svp-spherical']
basis_root = Path('benchmarks/results/issue206-practical-auxiliary/identity')
_, orbital = load_comparison_basis(basis_root / 'cc-pvdz.json', case, role='orbital', compute_forces=True)
_, auxiliary = load_comparison_basis(basis_root / 'cc-pvdz-jkfit.json', case, role='auxiliary', compute_forces=True)
report = {
    'scope': __doc__, 'status': 'running', 'pyscf_version': pyscf.__version__,
    'numpy_version': np.__version__, 'maximum_corrections': 4,
    'force_gate_for_diagnosis': 3e-11,
    'threads': {k: os.environ.get(k) for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')},
    'input_sha256': {}, 'rows': [],
}
for p in (root / 'changed-density-v1/report.json', basis_root / 'cc-pvdz.json',
          basis_root / 'cc-pvdz-jkfit.json', Path(__file__)):
    report['input_sha256'][str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()


def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def maximum(value):
    return float(np.max(np.abs(value)))


save()
try:
    for phase, changed in (('cold', False), ('changed', True)):
        geometry = [(s, np.array(r, dtype=float)) for s, r in case.atoms]
        if changed:
            geometry[1][1][0] += 0.001
        mol = gto.M(atom=geometry, unit='Bohr', basis=orbital, verbose=0)
        mf = scf.RHF(mol).density_fit(auxbasis=auxiliary)
        mf.direct_scf_tol = 1e-14
        source = next(r for r in old['rows'] if r['phase'] == phase)
        path = root / 'changed-density-v1' / (phase + '-density.npy')
        actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual_hash == source['density_sha256']
        report['input_sha256'][str(path)] = actual_hash
        density = np.load(path, allow_pickle=False)
        h, overlap = mf.get_hcore(), mf.get_ovlp()
        reference = old['references'][int(changed)]
        reference_force = np.array(reference['force'])
        lagged = None
        for correction in range(5):
            fock = h + mf.get_veff(mol, density)
            energy = float(np.einsum('ij,ji', density, h + fock) / 2 + mol.energy_nuc())
            eps, c = mf.eig(fock, overlap)
            occupations = np.zeros_like(eps)
            occupations[:mol.nelectron // 2] = 2
            next_density = (c * occupations) @ c.T
            mf.make_rdm1 = lambda *a, d=density, **kw: d
            gradient = mf.nuc_grad_method()
            gradient.auxbasis_response = True
            gradient._tag_rdm1 = lambda dm, *a, **kw: np.asarray(dm)
            row = {
                'phase': phase, 'corrections': correction,
                'energy_error': abs(energy - reference['energy']),
                'commutator_maximum': maximum(fock @ density @ overlap - overlap @ density @ fock),
                'fixed_point_density_maximum': maximum(next_density - density),
                'fixed_point_density_rms': float(np.sqrt(np.mean((next_density - density) ** 2))),
                'weights': {},
            }
            weights = [('consistent', density @ fock @ density / 2)]
            if lagged is not None:
                weights.append(('lagged', lagged))
            arrays = {'density': density, 'physical_fock': fock}
            for label, weight in weights:
                gradient.make_rdm1e = lambda *a, w=weight, **kw: w
                force = -gradient.kernel(mo_energy=eps, mo_coeff=c, mo_occ=occupations)
                error = maximum(force - reference_force)
                row['weights'][label] = {'force_error': error, 'within_gate': error <= 3e-11}
                arrays[label + '_weight'] = weight
                arrays[label + '_force'] = force
            np.savez(out / f'{phase}-correction{correction}.npz', **arrays)
            report['rows'].append(row)
            save()
            print(row, flush=True)
            lagged = (c * (occupations * eps)) @ c.T
            density = next_density
    report['status'] = 'completed diagnosis; original native failures unchanged'
except Exception:
    report.update(status='failed diagnosis', exception=traceback.format_exc())
    raise
finally:
    save()

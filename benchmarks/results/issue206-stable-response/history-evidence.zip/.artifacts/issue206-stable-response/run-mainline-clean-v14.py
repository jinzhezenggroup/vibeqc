"""Changed-v14 mainline stock comparison at original scientific requests.

Per user steering, the independent1e-12 residual discrepancy remains a recorded
separate follow-up and does not block original1e-10 measurements. Preserve all
original paired E/F gates and failures. Seven interleaved clean repeats cover
96/192 B1/B4,384/768 energy/force, UHF/non-water and explicit cc-pVDZ/JKFIT.
No cold/changed-repeat, direct-path, constrained-memory or universal superiority
claim follows from this warm campaign. Stability and win criteria are declared
before launch: each relative MAD<=3%, reduction>=2%, paired bootstrap95% lower
bound>2%,10000 resamples/default_rng(206). Normal convergence branches remain.
"""

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

assert os.environ.get("SLURM_JOB_ID"), "Run through finite Slurm allocation"
root = Path.cwd()
artifacts = root / ".artifacts/issue206-stable-response"
out = artifacts / "mainline-clean-v14"
out.mkdir(exist_ok=False)
environment = {
    k: v for k, v in os.environ.items()
    if not k.startswith("VIBEQC_") and k != "CONTRACT_ENGINE"
}
environment.update(
    PYTHONPATH="python:.", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
    LD_LIBRARY_PATH="/tmp/vibeqc-308-gpu4pyscf-env/lib/python3.13/site-packages/cutensor/lib:/group/software/cuda-12.9.1/lib64:" + environment.get("LD_LIBRARY_PATH", ""),
    VIBEQC_LIBRARY=str(artifacts / "candidate-v14/libvibeqc.so"),
    VIBEQC_DF_VALUE_STORAGE="dense", VIBEQC_DF_REFERENCE_FINAL_VALIDATION="0",
    VIBEQC_DF_FINAL_PROJECTION="auto", VIBEQC_DF_FORCE_SCREEN_ABS="off",
    VIBEQC_DF_EXCHANGE="auto", VIBEQC_DF_SEED_EXCHANGE="auto",
    VIBEQC_DF_FINAL_EXCHANGE="auto", VIBEQC_DF_RESIDENT_EXCHANGE="auto",
    VIBEQC_DF_SHELL_POLICY="auto",
)
python = "/tmp/vibeqc-308-gpu4pyscf-env/bin/python"
# This controller imports only case data and never creates a GPU context.
sys.path[:0] = [str(root / "python"), str(root)]
from benchmarks._cases import density_fitting_gate_points

points = [
    (p.case, p.batch_size, p.maximum_energy_error, p.maximum_force_error,
     p.reference_gradient_tolerance, forces, "equal")
    for forces in (False, True)
    for p in density_fitting_gate_points() if p.expected_ao_count <= 192
]
for case in ("water-hexadecamer-2s4-def2-svp-spherical", "water-32mer-4s4-def2-svp-spherical"):
    for forces in (False, True):
        points.append((case, 1, 1e-9, 1e-8, 1e-10, forces, "equal"))
for case in ("oh-def2-svp-spherical-uhf", "ammonia-def2-svp-spherical"):
    points.append((case, 1, 1e-9, 1e-8, 1e-10, True, "equal"))

for case, batch in [("water-tetramer-def2-svp-spherical",1),
                    ("water-tetramer-def2-svp-spherical",4),
                    ("water-octamer-s4-def2-svp-spherical",1),
                    ("water-octamer-s4-def2-svp-spherical",4),
                    ("oh-def2-svp-spherical-uhf",1)]:
    points.append((case,batch,3e-11,3e-11,1e-10,True,"practical"))
basis_root = root / "benchmarks/results/issue206-practical-auxiliary/identity"

build = json.loads((artifacts / "candidate-v14/manifest.json").read_text())
assert hashlib.sha256(Path(environment["VIBEQC_LIBRARY"]).read_bytes()).hexdigest() == build["library_sha256"]
manifest = {
    "scope": __doc__, "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "slurm_job_id": os.environ["SLURM_JOB_ID"],
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "build": build, "repeats_per_engine": 7,
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "comparator_sha256": hashlib.sha256((root / "benchmarks/compare_gpu4pyscf_batch.py").read_bytes()).hexdigest(),
    "qualifier_sha256": {name: hashlib.sha256((artifacts/name).read_bytes()).hexdigest()
                         for name in ("qualify-stock-equal-v14.py","qualify-stock-practical-v14.py")},
    "basis_hashes": {name: hashlib.sha256((basis_root/name).read_bytes()).hexdigest()
                     for name in ("cc-pvdz.json","cc-pvdz-jkfit.json")},
    "predeclared_statistics": {"repeats":7,"maximum_relative_mad":0.03,"minimum_reduction":0.02,
                              "bootstrap_pairs":10000,"seed":206,"confidence":0.95},
    "controls": {k: v for k, v in environment.items() if k.startswith("VIBEQC_")},
    "points": points, "checks": [],
    "prior_failures": "Retained #421 DF96-b4/changed192 failures and #427 final direct9890 failures are not waived or overwritten by this new campaign.",
}


def save():
    """Persist each attempted stage before starting another independent point."""
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def clean_processes():
    """Reject active builds/profilers; preserve known orphan control-agent facts."""
    names = {"nvcc", "cicc", "ptxas", "nsys", "ncu", "compute-sanitizer", "cmake", "ninja", "make", "cc1plus", "clang", "clang++", "gcc", "g++", "cc1", "ccache"}
    rows = []
    for line in subprocess.check_output(["ps", "-eo", "pid=,ppid=,etimes=,comm=,args="], text=True).splitlines():
        pid, parent, age, name, arguments = line.split(None, 4)
        if name in names:
            rows.append({"pid": int(pid), "parent": int(parent), "age_seconds": int(age), "name": name, "arguments": arguments, "orphan_control_agent": name == "nsys" and "--start-agent" in arguments and parent == "1" and int(age) > 86400})
    return rows


for name, expected in build['records'].items():
    if name.startswith('source/src/'):
        assert hashlib.sha256((root/name.removeprefix('source/')).read_bytes()).hexdigest()==expected,name
manifest["preflight_processes"] = clean_processes()
save()
assert not any(not r["orphan_control_agent"] for r in manifest["preflight_processes"]), "Active build/profiler blocks clean timing"
qualifications = {}
for case, batch, energy_gate, force_gate, gradient_tolerance, forces, domain in points:
    basis_arguments = (["--orbital-basis-file",str(basis_root/"cc-pvdz.json"),
                        "--auxiliary-basis-file",str(basis_root/"cc-pvdz-jkfit.json")]
                       if domain == "practical" else [])
    if (case, batch, domain) not in qualifications:
        name = f"{domain}-{case}-b{batch}-qualification"
        command = [python, str(artifacts / f"qualify-stock-{domain}-v14.py"), "--case", case, "--batch", str(batch), "--output", str(out / f"{name}.json")] + basis_arguments
        row = {"name": name, "scope": "separate stock provider/rank audit", "command": command, "status": "running"}
        manifest["checks"].append(row)
        save()
        with (out / f"{name}.txt").open("x") as stream:
            result = subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        row.update(exit_code=result.returncode, status="passed" if result.returncode == 0 else "failed")
        qualifications[case, batch, domain] = result.returncode == 0
        save()
    name = f"{domain}-{case}-b{batch}-" + ("forces" if forces else "energy")
    if not qualifications[case, batch, domain]:
        manifest["checks"].append({"name": name, "status": "not_run_provider_qualification_failed", "numerically_qualified": False})
        save()
        continue
    path = out / f"{name}.json"
    command = [
        python, "benchmarks/compare_gpu4pyscf_batch.py", "--case", case, "--batch", str(batch),
        "--repeats", "7", "--density-fitting", "cuda", "--max-iterations", "100",
        "--energy-tolerance", "1e-12", "--density-tolerance", "1e-10",
        "--reference-gradient-tolerance", str(gradient_tolerance), "--screening-tolerance", "1e-14",
        "--maximum-energy-error", str(energy_gate), "--output", str(path),
        "--progress-output", str(out / f"{name}.progress.jsonl"),
    ]
    command += basis_arguments
    command += ["--maximum-force-error", str(force_gate)] if forces else ["--energy-only"]
    row = {"name": name, "scope": "clean external endpoint", "command": command, "status": "running"}
    manifest["checks"].append(row)
    save()
    print("starting", name, flush=True)
    with (out / f"{name}.txt").open("x") as stream:
        result = subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    row["exit_code"] = result.returncode
    processes = clean_processes()
    row["post_cell_processes"] = processes
    row["clean_process_gate"] = not any(not r["orphan_control_agent"] for r in processes)
    if path.exists():
        data = json.loads(path.read_text())
        pairs = data["accuracy"]["paired_warm_repeats"]
        row["all_repeat_accuracy_passed"] = len(pairs) == 7 and all(
            p["maximum_energy_error_hartree"] <= energy_gate and
            (not forces or p["maximum_force_error_hartree_per_bohr"] <= force_gate)
            for p in pairs
        )
        row.update(timing=data["timing_summary"], accuracy=data["accuracy"], result_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    row["numerically_qualified"] = result.returncode == 0 and row.get("all_repeat_accuracy_passed", False)
    row["timing_eligible"] = row["numerically_qualified"] and row["clean_process_gate"]
    row["status"] = "passed" if row["numerically_qualified"] else "failed"
    save()
    print(name, row["status"], row.get("timing"), flush=True)
manifest["status"] = "passed declared warm numeric cells" if all(r["status"]=="passed" for r in manifest["checks"]) else "completed; failed cells retained"
save()
raise SystemExit(1 if any(r["status"] != "passed" for r in manifest["checks"]) else 0)

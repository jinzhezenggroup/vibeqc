"""Untimed changed-library diagnostics; preserve the original Slurm9904 failure.

Retain cold, priming, and every selected response result, including exceptions.
Only the library frozen in candidate-v5 is admitted. No timing is collected.
"""

import hashlib
import json
import os
import traceback
from pathlib import Path

import numpy as np

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import native_build_metadata
from vibeqc import Calculator, load_basis


def digest(path):
    """Hash large generated libraries without loading a binary-sized buffer."""
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            value.update(chunk)
    return value.hexdigest()


assert os.environ.get("SLURM_JOB_ID"), "GPU diagnostics require finite Slurm"
root = Path(
    "/home/jzzeng/codes/vibeqc-issue206-auxiliary/.artifacts/issue206-auxiliary"
)
local = Path(".artifacts/issue206-stable-response")
out = local / "candidate-controls-v5"
out.mkdir(exist_ok=False)
frozen = json.loads((local / "candidate-v5/manifest.json").read_text())
library = (local / "candidate-v5/libvibeqc.so").resolve()
campaign = json.loads((root / "practical-warm-v1/manifest.json").read_text())
for key in list(os.environ):
    if key.startswith("VIBEQC_"):
        del os.environ[key]
os.environ.update(campaign["controls"])
os.environ["VIBEQC_LIBRARY"] = str(library)
controls = {
    "auto": {},
    "host_final": {"VIBEQC_DF_REFERENCE_FINAL_VALIDATION": "1"},
    "shell": {"VIBEQC_DF_WEIGHTED_EXECUTION": "shell"},
    "blas": {"VIBEQC_DF_RESPONSE_ALGEBRA": "blas"},
    "shell_blas": {
        "VIBEQC_DF_WEIGHTED_EXECUTION": "shell",
        "VIBEQC_DF_RESPONSE_ALGEBRA": "blas",
    },
    "occupied": {"VIBEQC_DF_RESPONSE_SPACE": "occupied"},
    "auto_return": {},
}
keys = {key for selected in controls.values() for key in selected}
baseline = {key: os.environ.get(key) for key in keys}
oracle = json.loads((root / "cpu-diagnosis-v1.json").read_text())
report = {
    "scope": __doc__,
    "status": "running",
    "frozen": frozen,
    "slurm_job_id": os.environ["SLURM_JOB_ID"],
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    "controls": controls,
    "rows": [],
    "loaded_libraries": [],
    "inputs": {
        str(path): digest(path)
        for path in (
            Path(__file__),
            root / "cc-pvdz.json",
            root / "cc-pvdz-jkfit.json",
            root / "cpu-diagnosis-v1.json",
            root / "practical-warm-v1/manifest.json",
        )
    },
    "environment": {
        key: value for key, value in os.environ.items() if key.startswith("VIBEQC_")
    },
}


def save():
    """Persist before each native operation so a pre-loop failure is retained."""
    (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")


def reset_controls():
    for key, value in baseline.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


def execute(batch, reference, selection):
    """Keep each full endpoint result or traceback before advancing controls."""
    trace = out / (reference["case"] + "-" + selection + ".jsonl")
    os.environ["VIBEQC_DF_TRACE"] = str(trace)
    row = {"case": reference["case"], "selection": selection, "status": "running"}
    report["rows"].append(row)
    save()
    try:
        item = batch.execute(strict=True).items[0]
        force_error = float(
            np.max(
                np.abs(np.asarray(item.forces) - reference["forces_hartree_per_bohr"])
            )
        )
        row.update(
            status="completed",
            energy=item.energy,
            forces=np.asarray(item.forces).tolist(),
            iterations=item.iterations,
            density_rms=item.density_rms,
            energy_change=item.energy_change,
            converged=item.converged,
            energy_error_vs_cpu=abs(item.energy - reference["energy_hartree"]),
            force_error_vs_cpu=force_error,
            force_gate_pass=force_error <= 3e-11,
        )
    except Exception:
        row.update(status="failed", exception=traceback.format_exc())
    finally:
        save()
    print(
        row["case"],
        selection,
        row.get("force_error_vs_cpu"),
        row.get("exception", ""),
        flush=True,
    )
    return row["status"] == "completed"


save()
try:
    assert digest(library) == frozen["library_sha256"]
    orbital, auxiliary = (
        load_basis(root / name) for name in ("cc-pvdz.json", "cc-pvdz-jkfit.json")
    )
    for reference in oracle["rows"]:
        case = benchmark_cases()[reference["case"]]
        reset_controls()
        os.environ["VIBEQC_DF_TRACE"] = str(
            out / (reference["case"] + "-prepare.jsonl")
        )
        try:
            calculator = Calculator(
                method=case.method,
                basis=orbital,
                auxiliary_basis=auxiliary,
                basis_representation="spherical",
                device="cuda",
                density_fitting="cuda",
                max_iterations=100,
                energy_tolerance=1e-12,
                density_tolerance=1e-10,
                screening_tolerance=1e-14,
            )
            loaded = native_build_metadata(calculator)
            report["loaded_libraries"].append({"case": reference["case"], **loaded})
            save()
            assert Path(loaded["library_path"]) == library
            assert loaded["library_sha256"] == frozen["library_sha256"]
            with calculator.prepare_batch(
                [case.atoms],
                charges=[case.charge],
                multiplicities=[case.multiplicity],
                warm_start=True,
            ) as batch:
                if not execute(batch, reference, "cold"):
                    continue
                batch.set_warm_start_updates(False)
                if not execute(batch, reference, "prime"):
                    continue
                for selection, selected in controls.items():
                    reset_controls()
                    os.environ.update(selected)
                    execute(batch, reference, selection)
        except Exception:
            report["rows"].append(
                {
                    "case": reference["case"],
                    "selection": "prepare_or_cleanup",
                    "status": "failed",
                    "exception": traceback.format_exc(),
                }
            )
            save()
    assert len(report["rows"]) == 18, (
        "candidate diagnostics did not complete every phase"
    )
    assert all(row.get("force_gate_pass") for row in report["rows"]), (
        "candidate strict force accuracy failed; all rows retained"
    )
    report["status"] = (
        "passed untimed controls; streaming and performance remain unqualified"
    )
except Exception:
    report["status"] = "failed diagnostic"
    report["exception"] = traceback.format_exc()
    raise
finally:
    os.environ.pop("VIBEQC_DF_TRACE", None)
    save()

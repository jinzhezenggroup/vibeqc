"""Checkpoint qualified v10, formatting-equivalent v11 and running octamer diagnostic."""
import json
from datetime import datetime, timezone
from pathlib import Path
worktree=Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root=worktree/'.artifacts/issue206-stable-response'
p=root/'current-handoff.json'
with (root/'handoff-before-v6.json').open('xb') as stream:stream.write(p.read_bytes())
latest=json.loads(p.read_text())
latest['observed_at_utc']=datetime.now(timezone.utc).isoformat()
for version in ('v9','v10'):
 latest['previous_candidates'][version]=json.loads((root/('candidate-'+version)/'manifest.json').read_text())['library_sha256']
latest['latest_frozen_candidate']=json.loads((root/'candidate-v11/manifest.json').read_text())
for name in ('qualification-v10','streamed-occupied-v4','streamed-occupied-job-v4'):
 data=json.loads((root/name/'report.json').read_text())
 latest['reports'][name]={k:data[k] for k in ('status','slurm_job_id','rows') if k in data}
latest['pending_jobs_at_update']={'streamed-occupied-v4':{'slurm_job_id':'9939','session':40497,'time_limit':'00:20:00','frozen_candidate':'v10','status':'running'}}
latest['completed_evidence_audit']=str(root/'completed-checkpoint-v4.json')
latest['v10_extension']='Project source-generated streamed AO rows into all-Q occupied factors before whitening; use four existing buffers, no allocation. Select only full-rank plans with fitting rows and strictly smaller logical source work; preserve truncated/insufficient-capacity fallback. Octamer384MiB predicts984 generated rows=5.125 passes instead of42.'
latest['v10_qualification']='Slurm9938: native physical/capture tests and native memcheck pass, zero errors;8 streamed J/K and38 occupied/practical/resource tests pass.52 molecular endpoints pass(E<=2.388e-12,F<=4.312e-13) at density1e-12. Loaded source/library identities verified. Original1e-10 failure remains failed.'
latest['v11_extension']='Only clang-format lambda wrapping and generated build identity differ from v10. Native executable sections match; all library sections except build-id and source identity match, including CUDA fatbins. Numerical evidence remains attributed to actual frozen v10 runs; no new numerical algorithm or performance result.'
latest['format_equivalence_records']=[str(root/'v10-v11-format-equivalence.json'),str(root/'v10-v11-all-section-equivalence.json'),str(root/'post-v10-format-only.patch')]
latest['build_status']='Completed v11; no active build. Initial v10 compile failure and corrected build retained.'
latest['next']=['Finish Slurm9939 single384MiB octamer diagnostic and audit every phase, actual K/response routes, loaded identity and work/capacities. Preserve incomplete Slurm9936.','Keep original1e-10 stationarity failure and remaining strict fallbacks explicit; no clean benchmark, commits, pushes, PRs or comments in this continuation.','Keep #415 switch; #206 open, #427 draft; #409 capacity/crossover separate.']
p.write_text(json.dumps(latest,indent=2)+'\n')
for work,artifact in [('issue206-auxiliary','issue206-auxiliary'),('issue206-response-diagnosis','issue206-response-diagnosis'),('issue206-post418','issue206-post418'),('issue418-cooperative-rys','issue418'),('issue206-direct-fix','issue206'),('issue409-packed','issue409')]:
 path=Path('/home/jzzeng/codes')/('vibeqc-'+work)/'.artifacts'/artifact/'current-handoff.json'
 data=json.loads(path.read_text())
 data['latest_stable_response_update']={k:v for k,v in latest.items() if k not in ('latest_frozen_candidate','reports')}
 data['latest_stable_response_update']['authoritative_handoff']=str(p)
 path.write_text(json.dumps(data,indent=2)+'\n')
print('Recorded qualified v10, equivalent v11 and running Slurm9939; six prior pointers updated.')

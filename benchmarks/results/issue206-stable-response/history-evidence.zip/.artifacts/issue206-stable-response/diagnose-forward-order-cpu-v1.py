"""CPU-only whitening-order probe using the exact saved native eigensystems.

Separate native eigensystem error from explicit-X construction/application.
No GPU, SCF, new factorization or clean timing is run.
"""
import hashlib
import json
from pathlib import Path

import numpy as np

root=Path('.artifacts/issue206-stable-response')
out=root/'forward-order-cpu-v1'
out.mkdir(exist_ok=False)
forward=json.loads((root/'forward-energy-v1/report.json').read_text())
report={'scope':__doc__,'inputs':{str(Path(__file__)):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},'rows':[]}
def energy(d,b):
    c=np.einsum('ij,ijp->p',d,b)
    db=np.einsum('ij,jkp->ikp',d,b,optimize=True)
    return .5*float(c@c)-.25*float(np.einsum('ijp,jip',db,db))
for row in forward['rows']:
    phase=row['phase']
    path=root/'forward-energy-v1'/(phase+'-native.npz')
    report['inputs'][str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    f=np.load(path,allow_pickle=False)
    d,a,q,l=(f[name] for name in ('density','raw','eigenvectors','eigenvalues'))
    eig=(a@q)/np.sqrt(l)
    sym=eig@q.T
    explicit=a@((q/np.sqrt(l))@q.T)
    one=float(np.einsum('ij,ji',d,f['hcore']))+float(f['nuclear'][0])
    result={'phase':phase,'energies':{name:one+energy(d,b) for name,b in
        (('saved_native_whitening',f['whitened']),('eigen_factors',eig),('eigen_factors_rotated_back',sym),
         ('cpu_explicit_inverse_root',explicit))},
        'cpu_cholesky_native_integrals_energy':row['cholesky_native_integrals_energy'],
        'cpu_reference_energy':row['cpu_fixed_density_energy']}
    result['errors_vs_cholesky_native_integrals']={name:value-result['cpu_cholesky_native_integrals_energy'] for name,value in result['energies'].items()}
    np.savez_compressed(out/(phase+'-whitened.npz'),eigen_factors=eig,eigen_factors_rotated_back=sym,cpu_explicit_inverse_root=explicit)
    report['rows'].append(result)
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(phase,result['errors_vs_cholesky_native_integrals'],flush=True)

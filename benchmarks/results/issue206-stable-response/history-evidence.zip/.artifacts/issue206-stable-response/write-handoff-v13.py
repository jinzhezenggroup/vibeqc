"""Checkpoint completed v14 larger tests, independent residuals and work audit."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

worktree = Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root = worktree / '.artifacts/issue206-stable-response'
path = root / 'current-handoff.json'
latest = json.loads(path.read_text())
large = json.loads((root / 'larger-v14/report.json').read_text())
ledger = json.loads((root / 'larger-v14/all-endpoint-ledger-v1.json').read_text())
independent = json.loads((root / 'larger-v14-residuals/report.json').read_text())
oracle_diagnosis = json.loads((root / 'larger-v14-oracle-diagnosis/report.json').read_text())
assert all(r['status'] != 'running' for r in [large, ledger, independent])
assert large['frozen']['library_sha256'] == latest['latest_frozen_candidate']['library_sha256']
assert large['slurm_job_id'] == independent['source_native_slurm_job_id'] == '9947'
with (root / 'handoff-before-v13.json').open('xb') as stream:
    stream.write(path.read_bytes())
summary = {
    'native_status': large['status'], 'work_audit_status': ledger['status'],
    'independent_residual_status': independent['status'], 'slurm_job_id': large['slurm_job_id'],
    'library_sha256': large['frozen']['library_sha256'],
    'native_source_identity': large['frozen']['native_source_identity'],
    'settings': large['predeclared_settings'], 'native_by_request': ledger['by_request'],
    'independent_by_request': independent['by_request'],
    'unique_independent_states': len(independent['states']),
    'oracle_diagnosis': {
        'status': oracle_diagnosis['status'],
        'report': str(root / 'larger-v14-oracle-diagnosis/report.json'),
        'conclusion': 'Cholesky/eigen metric fitting and generalized/symmetric-overlap providers all retain >1e-12 tight changed-state projector defects. Native/independent physical matrices still need direct comparison.',
    },
    'reports': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in [
        'larger-v14/report.json', 'larger-v14/all-endpoint-ledger-v1.json',
        'larger-v14-residuals/report.json', 'larger-v14-terminal.txt',
        'larger-v14-residuals-terminal.txt', 'larger-v14-oracle-diagnosis/report.json']},
    'limitations': ['Untimed diagnosis with intrusive traces; no performance admission.',
                   'Explicit cc-pVDZ/JKFIT RHF geometries only; UHF large/holdout and direct-path gates remain.',
                   'Unconstrained-memory qualification does not qualify v14 streamed low-memory plans.'],
}
checkpoint = {
    'scope': 'Completed v14 numerical checkpoint with independent physical residuals; every failure remains retained.',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'previous_completed_evidence': str(root / 'completed-checkpoint-v9.json'),
    'v14_larger_qualification': summary, 'active_gpu_jobs': [], 'active_cpu_audits': [],
    'goal_status': 'incomplete; remaining qualification/integration and stock performance gates remain',
}
with (root / 'completed-checkpoint-v10.json').open('x') as stream:
    stream.write(json.dumps(checkpoint, indent=2) + '\n')
latest.update(
    observed_at_utc=checkpoint['created_at_utc'],
    completed_evidence_audit=str(root / 'completed-checkpoint-v10.json'),
    v14_larger_qualification=summary,
    pending_jobs_at_update={},
    evidence_manifest=str(root / 'evidence-manifest-v12.json'),
    native_test_checkpoint=str(root / 'qualification-v14/report.json'),
    native_test_status='v14 native CPU/CUDA, snapshot, occupied and final-state memcheck passed',
    build_status={'status': 'built frozen v14; native source unchanged',
                  'library_sha256': large['frozen']['library_sha256'],
                  'source_identity': large['frozen']['native_source_identity']},
    next=[
        'Diagnose the24 failed independent1e-12 octamer residual endpoints at exact saved densities. Compare native Fock/overlap/projectors to CPU before changing production or further admission. CPU decomposition/provider substitutions did not eliminate failures; original1e-10 group passed.',
        'Requalify changed v14 force selection on the constrained-memory octamer. v12 Slurm9943 evidence does not qualify v14.',
        'Complete remaining supported routes, larger UHF,384/768 and non-water/unequal-auxiliary holdouts with independent residuals.',
        'Integrate newer master and requalify affected paths before reviewable PR(s); retain #415 switch and keep #409 separate.',
        'Establish direct-path gates and at least five interleaved clean stock GPU4PySCF repeats per domain. #206 remains open; #427 remains draft.',
    ],
)
for field in ['small_qualification_audit', 'larger_batch_result', 'live_job_observation']:
    if field in latest:
        latest.setdefault('historical_' + field + '_before_v14', latest[field])
latest['small_qualification_audit'] = str(root / 'qualification-v14/per-request-audit-v1.json')
latest['larger_batch_result'] = summary
latest['live_job_observation'] = {'observed_at_utc': checkpoint['created_at_utc'], 'active_gpu_jobs': []}
latest['status'] = ('uncommitted v14; declared small/larger native and independent checks passed; no timing admission'
                    if all(r['status'] == 'passed' for r in [large, ledger, independent]) else
                    'uncommitted v14; completed larger diagnostics contain failed gates; no admission')
latest['reports']['larger-v14'] = summary
snapshot = root / 'post-v14-note-after-larger-v1.md'
snapshot.write_bytes((worktree / '.agents/notes/proposed/2026-09-17-full-rank-response-candidate.md').read_bytes())
latest['latest_rationale_snapshot'] = str(snapshot)
path.write_text(json.dumps(latest, indent=2) + '\n')
for work, artifact in [
    ('issue206-auxiliary', 'issue206-auxiliary'),
    ('issue206-response-diagnosis', 'issue206-response-diagnosis'),
    ('issue206-post418', 'issue206-post418'),
    ('issue418-cooperative-rys', 'issue418'),
    ('issue206-direct-fix', 'issue206'),
    ('issue409-packed', 'issue409'),
]:
    pointer = worktree.parent / ('vibeqc-' + work) / '.artifacts' / artifact / 'current-handoff.json'
    data = json.loads(pointer.read_text())
    data['latest_stable_response_update'] = {
        k: v for k, v in latest.items() if k not in ('latest_frozen_candidate', 'reports')}
    data['latest_stable_response_update']['authoritative_handoff'] = str(path)
    pointer.write_text(json.dumps(data, indent=2) + '\n')
print(latest['status'])

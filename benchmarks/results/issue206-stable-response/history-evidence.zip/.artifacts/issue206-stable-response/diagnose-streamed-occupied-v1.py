"""Predeclared untimed v8 streamed canonical-response boundary.

Water cc-pVDZ/JKFIT,128 MiB total,16/12 MiB private response caps; source must
be streamed and the new occupied-factor route must execute in all four phases.
Independent oracle, density1e-12, energy/force3e-11. No timing admission.
"""
import hashlib
import importlib.util
import json
import os
import traceback
from pathlib import Path
from types import SimpleNamespace

assert os.environ.get('SLURM_JOB_ID')
root = Path('.artifacts/issue206-stable-response')
out = root / 'streamed-occupied-v1'
out.mkdir(exist_ok=False)
lib = (root / 'candidate-v8/libvibeqc.so').resolve()
frozen = json.loads((root / 'candidate-v8/manifest.json').read_text())
with lib.open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest() == frozen['library_sha256']
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str(lib), VIBEQC_RESOURCE_CUDA_TEST='1',
                  OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
import pytest
source = Path('tests/python/test_df_practical_response_cuda.py')
assert source.read_bytes() == (root/'candidate-v8/source'/source).read_bytes()
(out/'test-source.py').write_bytes(source.read_bytes())
spec = importlib.util.spec_from_file_location('practical_response_test', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
settings = [('dense-streamed-response16', 'dense', 128 << 20, 16 << 20),
            ('dense-streamed-response12', 'dense', 128 << 20, 12 << 20)]
report = {'scope': __doc__, 'status':'running', 'slurm_job_id':os.environ['SLURM_JOB_ID'],
          'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'), 'frozen':frozen,
          'predeclared_settings':settings, 'rows':[]}
def save():
    (out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
save()
try:
    reference = module.practical_reference.__wrapped__(SimpleNamespace(param='water-tetramer-def2-svp-spherical'))
    report['references'] = [{'energy':e, 'forces':f.tolist()} for e,f in reference[-1]]
    save()
    for name, values, budget, response_budget in settings:
        directory=out/name
        directory.mkdir()
        row={'name':name,'status':'running'}
        report['rows'].append(row)
        save()
        try:
            with pytest.MonkeyPatch.context() as mp:
                if response_budget:
                    mp.setenv('VIBEQC_DF_RESPONSE_BUDGET_BYTES',str(response_budget))
                mp.setenv('VIBEQC_DF_PROGRESS_TRACE',str(directory/'progress.jsonl'))
                module.test_practical_full_force_cold_warm_and_changed_geometry(
                    mp, directory, reference, values, 'panel', 'occupied', 'blas', budget)
            # Numerical success alone does not establish coverage of the route.
            for phase in ('cold','warm','changed','changed_warm'):
                events=[json.loads(line) for line in (directory/(phase+'.jsonl')).read_text().splitlines()]
                responses=[event for event in events if event.get('operation')=='force_response']
                assert len(responses)==1
                counters=responses[0]['counters']
                assert responses[0]['valid']
                assert counters.get('response_streamed_occupied_factor_first')==1, counters
                assert counters.get('response_streamed_occupied_raw_passes')==1
                assert counters.get('raw_tile_productions')==464
                assert counters.get('raw_value_bytes')==96*96*464*8
                assert counters.get('response_borrowed_occupied_factor_bytes')==96*20*8
                assert counters.get('response_scratch_bytes')<=response_budget
                assert not counters.get('response_borrowed_whitened_bytes',0)
                assert not counters.get('response_borrowed_jk_bytes',0)
            row['status']='passed' 
        except (Exception, pytest.fail.Exception):
            row.update(status='failed', exception=traceback.format_exc())
        save()
        print(name,row['status'],flush=True)
    report['status']='passed' if all(r['status']=='passed' for r in report['rows']) else 'failed; all settings retained'
finally:
    save()

if report['status'] != 'passed':
    raise SystemExit(1)

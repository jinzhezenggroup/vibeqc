"""Isolate forward energy arithmetic using saved candidate-v2 water densities.

Export native CUDA integral values and the forward planner's factors/J/K,
without SCF. Independently replace A/M with libcint values and compare CPU
Cholesky contraction, native whitening, and native J/K at each fixed density.
These are new untimed diagnostics, not retries of failed qualification cells.
"""
import ctypes
import hashlib
import json
import os
import traceback
from pathlib import Path

import numpy as np
from pyscf import df, gto, scf
from scipy.linalg import cholesky, solve_triangular

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis, native_build_metadata
from vibeqc import Calculator, _native
from vibeqc.calculator import Atom

assert os.environ.get('SLURM_JOB_ID')
root=Path('.artifacts/issue206-stable-response')
out=root/'forward-energy-v1'
out.mkdir(exist_ok=False)
frozen=json.loads((root/'candidate-v3/manifest.json').read_text())
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str((root/'candidate-v3/libvibeqc.so').resolve()),
    VIBEQC_DF_VALUE_STORAGE='dense',VIBEQC_DF_FORCE_SCREEN_ABS='off')
captured=json.loads((root/'changed-density-v1/report.json').read_text())
case=benchmark_cases()['water-tetramer-def2-svp-spherical']
identity=Path('benchmarks/results/issue206-practical-auxiliary/identity')
orbital,ob=load_comparison_basis(identity/'cc-pvdz.json',case,role='orbital',compute_forces=True)
auxiliary,ab=load_comparison_basis(identity/'cc-pvdz-jkfit.json',case,role='auxiliary',compute_forces=True)
report={'scope':__doc__,'slurm_job_id':os.environ['SLURM_JOB_ID'],
    'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'status':'running','rows':[],
    'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
        (Path(__file__),root/'forward-diagnostic-bridge.cpp',root/'forward-diagnostic-bridge.so',
         root/'changed-density-v1/report.json')},'frozen':frozen}

def save():
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')

def maximum(x):
    return float(np.max(np.abs(x)))

def tensor_energy(d,b):
    c=np.einsum('ij,ijp->p',d,b)
    db=np.einsum('ij,jkp->ikp',d,b,optimize=True)
    return .5*float(c@c)-.25*float(np.einsum('ijp,jip',db,db))

def fitted_energy(d,a,m):
    b=solve_triangular(cholesky(m,lower=True),a.reshape(d.size,-1).T,lower=True).T.reshape(a.shape)
    return tensor_energy(d,b)

save()
try:
    orbital_calc=Calculator(device='cuda',basis=orbital,basis_representation='spherical')
    auxiliary_calc=Calculator(device='cuda',basis=auxiliary,basis_representation='spherical')
    native=orbital_calc._library
    loaded=native_build_metadata(orbital_calc)
    report['native_build']=loaded
    assert loaded['library_sha256']==frozen['library_sha256']
    bridge=ctypes.CDLL(str((root/'forward-diagnostic-bridge.so').resolve()))
    pointer=ctypes.POINTER(ctypes.c_double)
    export=bridge.export_native_forward
    export.argtypes=[ctypes.c_void_p]*2+[ctypes.c_size_t]*2+[pointer]*12+[ctypes.c_char_p,ctypes.c_size_t]
    export.restype=ctypes.c_int
    factor=bridge.factor_reference_forward
    factor.argtypes=[ctypes.c_size_t]*2+[pointer]*9+[ctypes.c_char_p,ctypes.c_size_t]
    factor.restype=ctypes.c_int
    n,a=96,464
    for phase,changed in (('cold',False),('changed_warm',True)):
        geometry=[(s,np.array(r,dtype=float)) for s,r in case.atoms]
        if changed: geometry[1][1][0]+=.001
        density_path=root/'changed-density-v1'/(phase+'-density.npy')
        d=np.ascontiguousarray(np.load(density_path,allow_pickle=False))
        original=next(r for r in captured['rows'] if r['phase']==phase)
        assert hashlib.sha256(density_path.read_bytes()).hexdigest()==original['density_sha256']
        row={'phase':phase,'density_sha256':original['density_sha256'],'status':'running'}
        report['rows'].append(row)
        save()
        mol=gto.M(atom=geometry,unit='Bohr',basis=ob,verbose=0)
        mf=scf.RHF(mol).density_fit(auxbasis=ab)
        mf.direct_scf_tol=1e-14
        cpu_energy=mf.energy_tot(dm=d)
        ref_a=np.ascontiguousarray(df.incore.aux_e2(mol,mf.with_df.auxmol,aosym='s1'))
        ref_m=np.ascontiguousarray(mf.with_df.auxmol.intor('int2c2e'))
        ref_h,ref_s=mf.get_hcore(),mf.get_ovlp()
        raw,metric=np.empty_like(ref_a),np.empty_like(ref_m)
        overlap,hcore=np.empty((n,n)),np.empty((n,n))
        nuclear=np.empty(1)
        q,eigen,x=np.empty((a,a)),np.empty(a),np.empty((a,a))
        white,j,k=np.empty_like(raw),np.empty((n,n)),np.empty((n,n))
        context=ctypes.c_void_p()
        desc=_native.ContextDescriptor(ctypes.sizeof(_native.ContextDescriptor),_native.ABI_VERSION,0,_native.BACKEND_CUDA)
        _native.check(native,native.vibeqc_context_create(ctypes.byref(desc),ctypes.byref(context)))
        o,aux=ctypes.c_void_p(),ctypes.c_void_p()
        error=ctypes.create_string_buffer(4096)
        try:
            atoms=tuple(Atom.from_value(atom) for atom in geometry)
            o=orbital_calc._create_native_system(context,atoms,0,1)
            aux=auxiliary_calc._create_native_system(context,atoms,0,1)
            status=export(o,aux,n,a,*(v.ctypes.data_as(pointer) for v in
                (d,raw,metric,overlap,hcore,nuclear,q,eigen,x,white,j,k)),error,len(error))
            if status: raise RuntimeError(error.value.decode())
        finally:
            if aux: native.vibeqc_system_destroy(aux)
            if o: native.vibeqc_system_destroy(o)
            native.vibeqc_context_destroy(context)
        arrays=dict(density=d,raw=raw,metric=metric,overlap=overlap,hcore=hcore,nuclear=nuclear,
            eigenvectors=q.T.copy(),eigenvalues=eigen,inverse_root=x,whitened=white,coulomb=j,exchange=k,
            reference_a=ref_a,reference_m=ref_m,reference_h=ref_h,reference_s=ref_s)
        native_one=float(np.einsum('ij,ji',d,hcore))+float(nuclear[0])
        cpu_one=float(np.einsum('ij,ji',d,ref_h))+mol.energy_nuc()
        reference_df=fitted_energy(d,ref_a,ref_m)
        row.update(cpu_fixed_density_energy=cpu_energy,captured_native_energy=original['native_energy'],
            native_integral_errors={key:maximum(arrays[key]-arrays[ref]) for key,ref in
                (('raw','reference_a'),('metric','reference_m'),('hcore','reference_h'),('overlap','reference_s'))},
            one_electron_energy_delta=native_one-cpu_one,
            native_plan_energy=native_one+.5*float(np.einsum('ij,ji',d,j-.5*k)),
            native_whitened_energy=native_one+tensor_energy(d,white),
            cholesky_native_integrals_energy=native_one+fitted_energy(d,raw,metric),
            cholesky_reference_energy=cpu_one+reference_df,
            raw_A_only_energy_delta=fitted_energy(d,raw,ref_m)-reference_df,
            metric_only_energy_delta=fitted_energy(d,ref_a,metric)-reference_df,
            native_metric_eigen_residual=maximum(metric@q.T-q.T*eigen),
            native_metric_inverse_residual=maximum(x@metric@x-np.eye(a)))
        # Copy the first export before reusing the temporary output arrays.
        np.savez_compressed(out/(phase+'-native.npz'),**arrays)
        status=factor(n,a,*(v.ctypes.data_as(pointer) for v in (ref_a,ref_m,d,q,eigen,x,white,j,k)),error,len(error))
        if status: raise RuntimeError(error.value.decode())
        row.update(reference_integrals_native_plan_energy=cpu_one+.5*float(np.einsum('ij,ji',d,j-.5*k)),
            reference_integrals_native_whitened_energy=cpu_one+tensor_energy(d,white))
        np.savez_compressed(out/(phase+'-reference-factors.npz'),eigenvectors=q.T,eigenvalues=eigen,
            inverse_root=x,whitened=white,coulomb=j,exchange=k)
        row['status']='complete'
        save()
        print(phase,{key:(value-cpu_energy) for key,value in row.items() if key.endswith('_energy') and isinstance(value,float)},
            {key:value for key,value in row.items() if key.endswith('_delta')},flush=True)
    report['status']='completed forward diagnostic; original gates and failures unchanged'
except Exception:
    report.update(status='failed diagnostic',exception=traceback.format_exc())
    raise
finally:
    save()

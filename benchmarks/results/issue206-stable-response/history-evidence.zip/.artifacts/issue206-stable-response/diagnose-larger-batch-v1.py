"""Predeclared untimed v6 larger-size and B=2 complete-force diagnostics.

cc-pVDZ/cc-pVDZ-JKFIT snapshots, density tolerance 1e-12, unchanged 3e-11
energy/force gates. Every original and changed phase and every batch item is
retained; this does not admit timing or reclassify original #206 failures.
"""
import hashlib
import importlib.util
import json
import os
import traceback
from pathlib import Path
from types import SimpleNamespace

assert os.environ.get('SLURM_JOB_ID')
root=Path('.artifacts/issue206-stable-response')
out=root/'larger-batch-v1'
out.mkdir(exist_ok=False)
lib=(root/'candidate-v6/libvibeqc.so').resolve()
frozen=json.loads((root/'candidate-v6/manifest.json').read_text())
with lib.open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==frozen['library_sha256']
for key in list(os.environ):
    if key.startswith('VIBEQC_'):del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str(lib),VIBEQC_RESOURCE_CUDA_TEST='1',
                  OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np
import pytest
from vibeqc import Calculator
from benchmarks.compare_gpu4pyscf_batch import native_build_metadata
source=Path('tests/python/test_df_practical_response_cuda.py')
assert source.read_bytes()==(root/'candidate-v6/source'/source).read_bytes()
(out/'reference-source.py').write_bytes(source.read_bytes())
spec=importlib.util.spec_from_file_location('practical_response_test',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
settings=[('octamer-dense', 'water-octamer-s4-def2-svp-spherical',1,'dense','panel','dense'),
          ('octamer-packed','water-octamer-s4-def2-svp-spherical',1,'packed','auto','occupied'),
          ('tetramer-b2-dense','water-tetramer-def2-svp-spherical',2,'dense','panel','dense'),
          ('tetramer-b2-packed','water-tetramer-def2-svp-spherical',2,'packed','auto','occupied')]
report={'scope':__doc__,'status':'running','slurm_job_id':os.environ['SLURM_JOB_ID'],
        'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'frozen':frozen,
        'predeclared_settings':settings,'references':{},'rows':[]}
def save():
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
references={}
try:
    for name,key,size,values,storage,space in settings:
        directory=out/name;directory.mkdir()
        row={'name':name,'status':'running'};report['rows'].append(row);save()
        results=[]
        try:
            if key not in references:
                references[key]=module.practical_reference.__wrapped__(SimpleNamespace(param=key))
                report['references'][key]=[{'energy':e,'forces':f.tolist()} for e,f in references[key][-1]]
                save()
            case,orbital,auxiliary,moved,oracle=references[key]
            with pytest.MonkeyPatch.context() as mp:
                for env,value in {'VIBEQC_DF_VALUE_STORAGE':values,'VIBEQC_DF_RESPONSE_STORAGE':storage,
                    'VIBEQC_DF_RESPONSE_SPACE':space,'VIBEQC_DF_RESPONSE_ALGEBRA':'blas',
                    'VIBEQC_DF_EXCHANGE':'occupied','VIBEQC_DF_FORCE_SCREEN_ABS':'off',
                    'VIBEQC_DF_REFERENCE_FINAL_VALIDATION':'0','VIBEQC_DF_WEIGHTED_EXECUTION':'shell',
                    'VIBEQC_DF_DERIVATIVE_PAIRS':'packed' if values=='packed' else 'full',
                    'VIBEQC_DF_PROGRESS_TRACE':str(directory/'progress.jsonl')}.items():mp.setenv(env,value)
                calc=Calculator(method=case.method,basis=orbital,auxiliary_basis=auxiliary,
                    basis_representation='spherical',device='cuda',density_fitting='cuda',
                    energy_tolerance=1e-12,density_tolerance=1e-12,screening_tolerance=1e-14,max_iterations=100)
                metadata=native_build_metadata(calc)
                assert metadata['library_sha256']==frozen['library_sha256']
                (directory/'identity.json').write_text(json.dumps(metadata,indent=2)+'\n')
                mp.setenv('VIBEQC_DF_TRACE',str(directory/'prepare.jsonl'))
                with calc.prepare_batch([case.atoms]*size,charges=[case.charge]*size,
                        multiplicities=[case.multiplicity]*size) as batch:
                    for phase,changed in [('cold',False),('warm',False),('changed',True),('changed_warm',True)]:
                        mp.setenv('VIBEQC_DF_TRACE',str(directory/(phase+'.jsonl')))
                        positions=[np.array([r for _,r in moved])]*size if changed else None
                        result=batch.execute(positions,strict=False)
                        for index,item in enumerate(result.items):
                            data={'phase':phase,'index':index,'status':item.status,'status_message':item.status_message,
                                  'iterations':item.iterations}
                            if item.succeeded:
                                energy,force=oracle[int(changed)]
                                data.update(energy=item.energy,forces=np.asarray(item.forces).tolist(),
                                    energy_error=abs(item.energy-energy),force_error=float(np.max(np.abs(item.forces-force))))
                            results.append(data)
                        (directory/'results.json').write_text(json.dumps(results,indent=2)+'\n')
                        (directory/(phase+'-resources.json')).write_text(json.dumps(
                            [d.to_dict() for d in batch.last_density_fitting_metric_diagnostics()],indent=2)+'\n')
                        assert all(item.succeeded for item in result.items), phase
                assert all(r['energy_error']<=3e-11 and r['force_error']<=3e-11 for r in results), results
            row['status']='passed'
        except Exception:
            row.update(status='failed',exception=traceback.format_exc())
        save();print(name,row['status'],flush=True)
    report['status']='passed' if all(r['status']=='passed' for r in report['rows']) else 'failed; all settings retained'
finally:save()

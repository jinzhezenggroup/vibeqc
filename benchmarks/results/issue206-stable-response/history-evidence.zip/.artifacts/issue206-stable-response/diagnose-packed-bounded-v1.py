"""Predeclared untimed v7 bounded packed-GEMM regression; retain every result.

Resident source borrowing (16 MiB private response cap) is separate from the
80/96 MiB total dense budgets and 160 MiB packed capacity request. Neither
changes the retained original 1e-10 qualification or the failed 128 MiB packed
request. Gates stay 3e-11 at density tolerance 1e-12.
"""
import hashlib
import importlib.util
import json
import os
import traceback
from pathlib import Path
from types import SimpleNamespace

assert os.environ.get('SLURM_JOB_ID')
root = Path('.artifacts/issue206-stable-response')
out = root / 'packed-bounded-v1'
out.mkdir(exist_ok=False)
lib = (root / 'candidate-v7/libvibeqc.so').resolve()
frozen = json.loads((root / 'candidate-v7/manifest.json').read_text())
with lib.open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest() == frozen['library_sha256']
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str(lib), VIBEQC_RESOURCE_CUDA_TEST='1',
                  OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
import pytest
source = Path('tests/python/test_df_practical_response_cuda.py')
assert source.read_bytes() == (root/'candidate-v7/source'/source).read_bytes()
(out/'test-source.py').write_bytes(source.read_bytes())
spec = importlib.util.spec_from_file_location('practical_response_test', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
settings = [('dense-resident-response16', 'dense', 0, 16 << 20),
            ('packed-resident-response16', 'packed', 0, 16 << 20)]
report = {'scope': __doc__, 'status':'running', 'slurm_job_id':os.environ['SLURM_JOB_ID'],
          'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'), 'frozen':frozen,
          'predeclared_settings':settings, 'rows':[]}
def save():
    (out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
save()
try:
    reference = module.practical_reference.__wrapped__(SimpleNamespace(param='water-tetramer-def2-svp-spherical'))
    report['references'] = [{'energy':e, 'forces':f.tolist()} for e,f in reference[-1]]
    save()
    for name, values, budget, response_budget in settings:
        directory=out/name
        directory.mkdir()
        row={'name':name,'status':'running'}
        report['rows'].append(row)
        save()
        try:
            with pytest.MonkeyPatch.context() as mp:
                if response_budget:
                    mp.setenv('VIBEQC_DF_RESPONSE_BUDGET_BYTES',str(response_budget))
                mp.setenv('VIBEQC_DF_PROGRESS_TRACE',str(directory/'progress.jsonl'))
                module.test_practical_full_force_cold_warm_and_changed_geometry(
                    mp, directory, reference, values, 'panel', 'dense', 'blas', budget)
            row['status']='passed'
        except (Exception, pytest.fail.Exception):
            row.update(status='failed', exception=traceback.format_exc())
        save()
        print(name,row['status'],flush=True)
    report['status']='passed' if all(r['status']=='passed' for r in report['rows']) else 'failed; all settings retained'
finally:
    save()

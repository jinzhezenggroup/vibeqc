"""Paired untimed fixed-D diagnostic: preserve old bounded failure, require new
bounded/full-fitted response to match independent PySCF derivatives at3e-11.
This is not cold/warm/changed SCF admission or a clean latency comparison.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import traceback

import numpy as np

assert os.environ.get('SLURM_JOB_ID') and 'CUDA_VISIBLE_DEVICES' in os.environ
root = Path('.artifacts/issue206-stable-response')
out = root / 'general-response-v2'
out.mkdir(exist_ok=False)
fixture = root / 'general-response-input-v1'
reference = json.loads((fixture / 'report.json').read_text())
for name, digest in reference['fixture_sha256'].items():
    assert hashlib.sha256((fixture / name).read_bytes()).hexdigest() == digest
expected = np.array(reference['two_electron_derivative'])
probe = (root / 'general_response_probe_v1').resolve()
settings = [('old-bounded192', 'v11', 192 << 20),
            ('new-bounded192', 'v12', 192 << 20),
            ('new-fitted384', 'v12', 384 << 20)]
report = {'scope': __doc__, 'status': 'running', 'settings': settings,
          'slurm_job_id': os.environ['SLURM_JOB_ID'],
          'cuda_visible_devices': os.environ['CUDA_VISIBLE_DEVICES'],
          'reference': reference, 'gate': 3e-11,
          'probe_sha256': hashlib.sha256(probe.read_bytes()).hexdigest(),
          'source_sha256': hashlib.sha256((root / 'general_response_probe_v1.cpp').read_bytes()).hexdigest(),
          'rows': []}

def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

save()
try:
    for name, version, budget in settings:
        directory = out / name
        directory.mkdir()
        frozen = json.loads((root / ('candidate-' + version) / 'manifest.json').read_text())
        library = (root / ('candidate-' + version) / 'libvibeqc.so').resolve()
        with library.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == frozen['library_sha256']
        row = {'name': name, 'version': version, 'budget': budget, 'status': 'running',
               'library_sha256': frozen['library_sha256'],
               'native_source_identity': frozen['native_source_identity']}
        report['rows'].append(row)
        save()
        try:
            env = {k: v for k, v in os.environ.items() if not k.startswith('VIBEQC_')}
            env.update(LD_LIBRARY_PATH=str((root / ('candidate-' + version + '-loader')).resolve())
                       + ':/group/software/cuda-12.9.1/lib64',
                       VIBEQC_DF_TRACE=str(directory / 'trace.jsonl'),
                       VIBEQC_DF_RESPONSE_STORAGE='panel', VIBEQC_DF_RESPONSE_SPACE='dense',
                       VIBEQC_DF_RESPONSE_ALGEBRA='blas', VIBEQC_DF_WEIGHTED_EXECUTION='shell',
                       VIBEQC_DF_DERIVATIVE_PAIRS='full', VIBEQC_DF_FORCE_SCREEN_ABS='off')
            command = [str(probe), str(fixture / 'input.txt'), str(budget), str(directory / 'arrays.bin')]
            row['command'] = command
            save()
            with (directory / 'native.txt').open('x') as stream:
                completed = subprocess.run(command, env=env, stdout=stream,
                                           stderr=subprocess.STDOUT, timeout=450)
            row['exit_code'] = completed.returncode
            assert completed.returncode == 0
            records = [json.loads(line) for line in (directory / 'native.txt').read_text().splitlines()]
            identity = next(r for r in records if r['operation'] == 'identity')
            assert identity['source_identity'] == frozen['native_source_identity']
            assert Path(identity['library']).resolve() == library
            actual = np.fromfile(directory / 'arrays.bin').reshape(expected.shape)
            row['maximum_error'] = float(np.max(np.abs(actual - expected)))
            row['actual_derivative'] = actual.tolist()
            row['resources'] = next(r for r in records if r['operation'] == 'response')
            row['numerical_pass'] = bool(np.all(np.isfinite(actual)) and row['maximum_error'] <= 3e-11)
            events = [json.loads(line) for line in (directory / 'trace.jsonl').read_text().splitlines()]
            response = [r for r in events if r.get('operation') == 'force_response']
            assert len(response) == 1 and response[0]['valid']
            counts = response[0]['counters']
            row['response_counters'] = {k: v for k, v in counts.items() if not k.startswith('shell_')}
            assert row['resources']['device_bytes'] <= budget
            assert not row['resources']['borrowed_device_bytes'] and not row['resources']['occupied_response']
            if name == 'new-bounded192':
                tile = row['resources']['auxiliary_weight_tile']
                panels = (928 + tile - 1) // tile
                assert counts['response_streamed_general_factor_first'] == 1
                assert counts['response_streamed_fitting_raw_passes'] == panels * panels
                assert counts['raw_value_bytes'] == panels * panels * 192 * 192 * 928 * 8
                assert row['resources']['recomputed_value_bytes'] == counts['raw_value_bytes']
            if name == 'new-fitted384':
                assert counts['response_full_rank_single_tensor'] == 1
            row['status'] = 'passed numerical gate' if row['numerical_pass'] else 'failed numerical gate'
        except Exception:
            row.update(status='failed diagnostic', exception=traceback.format_exc())
        save()
        print(name, row['status'], row.get('maximum_error'), flush=True)
    candidates = [r for r in report['rows'] if r['version'] == 'v12']
    okay = len(candidates) == 2 and all(r['status'] == 'passed numerical gate' for r in candidates)
    report['status'] = ('completed; new candidate gates passed; every baseline failure retained'
                        if okay else 'failed new-candidate gate; all samples retained')
finally:
    save()
raise SystemExit(0 if okay else 1)

"""Audit completed v6/v7 diagnostics without treating requested routes as executed ones."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path('.artifacts/issue206-stable-response')
versions = {'budget-boundaries-v2': 'v6', 'larger-batch-v1': 'v6', 'packed-bounded-v1': 'v7'}
expected = {'budget-boundaries-v2': (12, 2), 'larger-batch-v1': (24, 0), 'packed-bounded-v1': (8, 0)}
output = {'scope': __doc__, 'clean_benchmarks': 0, 'audits': {}, 'frozen_file_checks': {}}
for version in ('v6', 'v7'):
    frozen_dir = root / ('candidate-' + version)
    frozen = json.loads((frozen_dir / 'manifest.json').read_text())
    for name, expected_hash in frozen['records'].items():
        with (frozen_dir / name).open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected_hash, (version, name)
    output['frozen_file_checks'][version] = len(frozen['records'])
for name, version in versions.items():
    data = json.loads((root / name / 'all-sample-audit.json').read_text())
    assert (data['completed_endpoints'], data['failed_or_rejected_endpoints']) == expected[name]
    assert data['maximum_energy_error'] <= 3e-11 and data['maximum_force_error'] <= 3e-11
    frozen = json.loads((root / ('candidate-' + version) / 'manifest.json').read_text())
    summary = {k: v for k, v in data.items() if k not in ('tests', 'cases')}
    summary['cases'] = []
    for case in data['cases']:
        identity = case['identity']
        native = identity.get('native_build', identity)
        assert native['library_sha256'] == frozen['library_sha256']
        assert native['probe']['source_identity'] == frozen['native_source_identity']
        assert native['probe']['device']['name'] == 'NVIDIA GeForce RTX 5090'
        rows = case['rows']
        item = {'directory': case['directory'], 'library_sha256': native['library_sha256'],
                'completed_endpoints': sum('energy_error' in r for r in rows),
                'resource_rejections': [r for r in rows if 'energy_error' not in r],
                'response_operations': []}
        for response in case['response']:
            assert response['valid']
            c = response['counters']
            route = [k for k, v in c.items() if k.startswith('response_full_rank_') and v]
            assert len(route) == 1, route
            keys = ('response_scratch_bytes', 'response_borrowed_whitened_bytes',
                    'response_borrowed_jk_bytes', 'raw_tile_productions', 'raw_value_bytes',
                    'raw_value_upload_bytes', 'raw_packed_value_reused_bytes',
                    'response_fitted_panel_gemms', 'response_fitted_panel_gemvs',
                    'response_fitted_projection_flops', 'response_fitted_unpack_staging_copies',
                    'response_fitted_unpack_staging_bytes', 'response_metric_blas_gemms',
                    'response_auxiliary_blocks', 'response_occupied_rank')
            item['response_operations'].append({'phase': response['phase'], 'nbf': response['nbf'],
                'naux': response['naux'], 'route': route[0], 'work': {k: c.get(k, 0) for k in keys}})
            if name == 'packed-bounded-v1':
                assert c.get('raw_tile_productions', 0) == c.get('raw_value_upload_bytes', 0) == 0
                assert c['response_scratch_bytes'] == 16660800
                assert c['response_fitted_panel_gemms'] == 64
                assert c.get('response_fitted_panel_gemvs', 0) == 0
                if case['directory'].startswith('packed'):
                    assert c['response_fitted_unpack_staging_copies'] == 3712
                    assert c['response_fitted_unpack_staging_bytes'] == 138264576
                    assert c['response_borrowed_whitened_bytes'] == 17283072
                    assert c.get('raw_packed_value_reused_bytes', 0) == 0
        if name == 'larger-batch-v1':
            item['metric_and_resources'] = {}
            expected_rank = 928 if case['directory'].startswith('octamer') else 464
            for phase in ('cold', 'warm', 'changed', 'changed_warm'):
                values = json.loads((root / name / case['directory'] / (phase + '-resources.json')).read_text())
                assert len(values) == (1 if expected_rank == 928 else 2)
                assert all(r['effective_rank'] == expected_rank and not r['streamed'] for r in values)
                item['metric_and_resources'][phase] = values
        summary['cases'].append(item)
    output['audits'][name] = summary
output['sanitizers'] = {}
for name, log in [('streamed-memcheck-v1', 'native-memcheck.txt'),
                  ('streamed-memcheck-v1', 'streamed-memcheck.txt'),
                  ('qualification-v7', 'memcheck.txt')]:
    contents = (root / name / log).read_text()
    assert 'ERROR SUMMARY: 0 errors' in contents
    output['sanitizers'][name + '/' + log] = 'ERROR SUMMARY: 0 errors'
xml = ET.parse(root / 'qualification-v7/report.xml')
tests = list(xml.iter('testcase'))
assert len(tests) == 41 and all(t.find('failure') is None and t.find('error') is None and t.find('skipped') is None for t in tests)
output['v7_python_passed'] = len(tests)
output['retained_failure'] = 'Slurm9926 complete-force memcheck timed out with no completed endpoint or error summary; targeted checks do not reclassify it.'
path = root / 'completed-checkpoint-v2.json'
with path.open('x') as stream:
    json.dump(output, stream, indent=2)
    stream.write('\n')
print('Audited v6/v7 source hashes, loaded metadata, all phases/routes, work, memory, metric ranks, and targeted sanitizer summaries.')

"""Snapshot completed phases of the live v12 job without touching its outputs.

This is a read-only numerical/work audit of existing evidence. Partial success
does not qualify the whole job, relax the original density request, or admit
diagnostic timings as performance measurements.
"""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

root = Path('.artifacts/issue206-stable-response')
case = root / 'streamed-general-v1/octamer-total384'
output = root / 'streamed-general-observation-v2.json'
if output.exists():
    raise FileExistsError(output)
frozen = json.loads((root / 'candidate-v12/manifest.json').read_text())
identity = json.loads((case / 'identity.json').read_text())
assert identity['slurm_job_id'] == '9943'
assert identity['native_build']['library_sha256'] == frozen['library_sha256']
assert identity['native_build']['probe']['source_identity'] == frozen['native_source_identity']
result_bytes = (case / 'results.json').read_bytes()
rows = json.loads(result_bytes)
observed = []
for row in rows:
    assert row['energy_error'] <= 3e-11 and row['force_error'] <= 3e-11
    trace_bytes = (case / (row['phase'] + '.jsonl')).read_bytes()
    events = [json.loads(line) for line in trace_bytes.splitlines()]
    occupied = [e for e in events if e.get('operation') == 'ri_k_occupied'
                and e.get('counters', {}).get('occupied_rank', 0) > 0]
    # Preserve the original gate failure while auditing independent response evidence.
    capture_gate = 'passed' if occupied else 'failed: missing per-phase K capture'
    for event in occupied:
        counters = event['counters']
        assert event['valid'] and event['source_backed'] and event['streamed']
        assert counters['streamed_occupied_source_first'] == 1
        assert counters['occupied_rank'] == 40
        assert counters['streamed_occupied_row_blocks'] == 9
        assert counters['streamed_occupied_raw_generation_rows'] == 984
        assert counters['raw_panel_source_auxiliary_evaluations'] == 984 * 192 * 928
        assert counters['streamed_occupied_scratch_capacity_bytes'] == 4 * 829440 * 8
    responses = [e for e in events if e.get('operation') == 'force_response']
    assert len(responses) == 1 and responses[0]['valid']
    counters = responses[0]['counters']
    general = counters.get('response_streamed_general_factor_first') == 1
    canonical = counters.get('response_streamed_occupied_factor_first') == 1
    assert general != canonical
    if general:
        assert counters['response_full_rank_bounded_factor_first'] == 1
        assert counters['response_streamed_fitting_raw_passes'] == 16
        assert counters['raw_tile_productions'] == 640
        assert counters['raw_value_bytes'] == 16 * 192 * 192 * 928 * 8
        assert not counters.get('response_borrowed_occupied_factor_bytes', 0)
    else:
        assert counters['response_streamed_occupied_raw_passes'] == 1
        assert counters['raw_tile_productions'] == 928
        assert counters['raw_value_bytes'] == 192 * 192 * 928 * 8
        assert counters['response_borrowed_occupied_factor_bytes'] == 192 * 40 * 8
    assert counters['response_scratch_bytes'] <= 192 << 20
    assert not counters.get('response_borrowed_jk_bytes', 0)
    assert not counters.get('response_borrowed_whitened_bytes', 0)
    observed.append({
        'endpoint': row,
        'numerical_and_response_gates': 'passed',
        'predeclared_per_phase_K_capture_gate': capture_gate,
        'trace_sha256': hashlib.sha256(trace_bytes).hexdigest(),
        'response_route': 'general' if general else 'canonical',
        'response_counters': {k: v for k, v in counters.items() if not k.startswith('shell_')},
        'occupied_K_execution_kinds': [e['execution'] for e in occupied],
        'occupied_K_note': 'Capture counters describe graph construction, not aggregate replay work.',
        'physical_final_fock_records': sum(e.get('operation') == 'final_state_physical_fock' for e in events),
    })
queue = subprocess.run(
    ['squeue', '--jobs=9943', '--noheader', '--format=%i|%T|%M|%l'],
    check=True, capture_output=True, text=True).stdout.strip()
report = {
    'scope': __doc__,
    'observed_at_utc': datetime.now(timezone.utc).isoformat(),
    'slurm_job_id': '9943',
    'session': 12007,
    'squeue_snapshot': queue,
    'status': 'partial observation; whole-job qualification pending',
    'results_snapshot_sha256': hashlib.sha256(result_bytes).hexdigest(),
    'library_sha256': frozen['library_sha256'],
    'native_source_identity': frozen['native_source_identity'],
    'completed_phases': observed,
    'preserved_observer_failure': str(root / 'streamed-general-observation-v1-failure.json'),
    'capture_gate_diagnosis': 'Warm uses a cached graph: source df_rhf_scf.cpp:334-399 and progress scope13306. Missing fresh capture is not absence of occupied iterations. Original controller remains unchanged and is expected to reject this bookkeeping gate.',
    'pending_phases': [p for p in ('cold', 'warm', 'changed', 'changed_warm')
                       if p not in {row['phase'] for row in rows}],
    'original_density_tolerance': '1e-10 remains unqualified; this diagnostic requests 1e-12',
}
with output.open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('squeue_snapshot', 'status', 'pending_phases')}))
print('Completed and audited:', [row['phase'] for row in rows])

"""Prepare CPU-only ownership and exact-geometry comparator audit for review."""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path.cwd()))
from tools.compare_cuda_ownership import compare
from tools.report_cuda_ownership import ownership_report

root = Path.cwd()
art = root / '.artifacts/issue206-stable-response'
base = art / 'ownership-base-v1'
base.mkdir(exist_ok=False)
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
ledger = json.loads(subprocess.check_output(['git', 'show', f'{revision}:docs/cuda_ownership.json']))
paths = set(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', revision, 'src'], text=True).splitlines())
for owner in ledger['subsystems'].values():
    paths.update(owner['evidence'])
paths.update(subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', revision, *[f['owner'] for f in ledger['generated_families']]], text=True).splitlines())
for name in sorted(paths):
    target = base / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(subprocess.check_output(['git', 'show', f'{revision}:{name}']))
old = ownership_report(base, ledger)
new = ownership_report(root, json.loads((root/'docs/cuda_ownership.json').read_text()))
delta = compare(base, old, root, new)
delta['baseline_revision'] = revision
for name, data in [('ownership-base-v1.json', old), ('ownership-current-v1.json', new), ('ownership-delta-v1.json', delta)]:
    (art/name).write_text(json.dumps(data, indent=2)+'\n')
print('ownership', delta)

native_path = art/'mainline-clean-v14/practical-water-octamer-s4-def2-svp-spherical-b1-forces.json'
oracle_path = art/'larger-reference-v1/report.json'
data = json.loads(native_path.read_text())
oracle = json.loads(oracle_path.read_text())
reference = oracle['cases']['water-octamer-s4-def2-svp-spherical']
assert data['workload']['batch_size'] == 1
geometry = [[atom['element'], atom['coordinates_bohr']] for atom in data['workload']['geometries'][0]]
assert geometry == reference['original_geometry']
for role, filename in [('orbital','cc-pvdz.json'), ('auxiliary','cc-pvdz-jkfit.json')]:
    path = Path('benchmarks/results/issue206-practical-auxiliary/identity')/filename
    assert data['workload']['basis_overrides'][role] == json.loads(path.read_text())
    assert hashlib.sha256(path.read_bytes()).hexdigest() == oracle['input_sha256'][str(path)]
ref = reference['references'][0]
rows = []
for engine in ('vibeqc', 'gpu4pyscf'):
    for i, sample in enumerate(data[engine]['warm_samples']):
        rows.append({'engine': engine, 'repeat': i,
                     'energy_error': abs(sample['energies_hartree'][0] - ref['energy']),
                     'force_error': float(np.max(np.abs(np.asarray(sample['forces_hartree_per_bohr'][0])-ref['forces'])))})
result = {'scope':'CPU-only comparison of saved arrays at verified exact original geometry and bases; no rerun or gate reclassification.',
          'source_sha256':{str(p.relative_to(art)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (native_path,oracle_path)},
          'paired_verdict':'failed_numeric_gate', 'rows':rows,
          'maximum_force_error':{engine:max(r['force_error'] for r in rows if r['engine']==engine) for engine in ('vibeqc','gpu4pyscf')},
          'limitation':'B4 scaled geometries are not covered by this cached independent reference.'}
(art/'mainline-clean-v14/practical192-b1-cpu-audit-v1.json').write_text(json.dumps(result,indent=2)+'\n')
print('cached reference',result['maximum_force_error'])

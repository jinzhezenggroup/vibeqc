"""Record v8 streamed-factor implementation and v9 trace-only correction honestly."""
import json
from datetime import datetime, timezone
from pathlib import Path
worktree=Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root=worktree/'.artifacts/issue206-stable-response'
p=root/'current-handoff.json'
snapshot=root/'handoff-before-v4.json'
if not snapshot.exists():snapshot.write_bytes(p.read_bytes())
latest=json.loads(p.read_text())
latest['observed_at_utc']=datetime.now(timezone.utc).isoformat()
latest['latest_frozen_candidate']=json.loads((root/'candidate-v9/manifest.json').read_text())
for v in ('v7','v8'):
 latest['previous_candidates'][v]=json.loads((root/f'candidate-{v}/manifest.json').read_text())['library_sha256']
for name in ('qualification-v8','streamed-occupied-v1','streamed-occupied-job-v2','streamed-occupied-v2','streamed-occupied-job-v3','streamed-occupied-v3','qualification-v9'):
 path=root/name/'report.json'
 if path.exists():
  d=json.loads(path.read_text());latest['reports'][name]={k:d[k] for k in ('status','slurm_job_id','rows') if k in d}
latest['v8_extension']='Decouple canonical factor validation from resident tensor leases. For full-rank source-generated streamed owners with eligible factors and insufficient full-tensor capacity, own sum(rank^2)*Naux projections and reusable weight/projection buffer. Raw source feeds all spins/charges once. Exact owner/token/density/device-generation validation preserved; RHF/UHF/empty-spin native oracle checks and invalid-view tests added.'
latest['v8_qualification']='Slurm9934 native and native memcheck pass (zero errors);61 Python regressions pass including13 numerical cases/52 endpoints(E<=2.388e-12,F<=4.942e-13),3 explicit resource rejections,41 packed/resident tests and4 streamed-J/K tests. Requested water total128MiB plus private16/12MiB overrides reject before force because the existing API forbids combining public and private overrides. Those two failures remain failures.'
latest['v9_extension']='Relative to frozen v8, only response_dense_weight_panel_elements reports tile*Nao^2 instead of Naux*Nao^2 and CudaDfResponseBuffers documentation explains internal owned scratch. Numerical algorithms unchanged. Separate frozen library/source hashes retained.'
latest['additional_preflight_failure']='Slurm9935 failed CPU-reference source identity preflight before force: compared old generator hash to edited live test. Corrected Slurm9936 verifies original generator in frozen v6 plus unchanged basis snapshots and geometry. Failed reports and terminal retained.'
latest['pending_jobs_at_update']={'9936':{'session':71789,'scope':'frozen-v8 octamer384/512MiB total-budget strict all-phase diagnostic; finite20m'},'9937':{'session':55290,'scope':'frozen-v9 native and occupied/final-state/final-projection compatibility; finite10m, queued after9936'}}
latest['octamer_cpu_budget_lower_bounds']={'dense_value_bytes':162842671,'packed_value_bytes':495546415,'scope':'CPU-only native planner, excludes source/DIIS reservations; no GPU execution.'}
latest['remaining_boundaries']=['New streamed canonical route still needs practical molecular qualification; Slurm9936 currently running. Projection retention, not occupied-row blocking, is implemented.', 'No-resident-C arbitrary/corrected densities, inadequate all-occupied-projection capacity, or forced dense/scalar ablations keep the old general route.', 'Streamed Coulomb with scratch shorter than Naux and host-streamed compatibility whitening remain unchanged.', 'Original1e-10 first-changed force remains failed; no clean performance or stock GPU4PySCF acceptance.']
latest['next']=['Poll9936/session71789 and9937/session55290; preserve every endpoint or timeout and inspect actual route/work counters.','Update note and manifest after final results; review bounds, provenance and compatibility before any numerical PR.','Keep #415 switch; #206 open, #427 draft; no clean speedup claim.']
latest['evidence_manifest']=str(root/'evidence-manifest-v3.json')
p.write_text(json.dumps(latest,indent=2)+'\n')
for work,artifact in [('issue206-auxiliary','issue206-auxiliary'),('issue206-response-diagnosis','issue206-response-diagnosis'),('issue206-post418','issue206-post418'),('issue418-cooperative-rys','issue418'),('issue206-direct-fix','issue206'),('issue409-packed','issue409')]:
 path=Path('/home/jzzeng/codes')/('vibeqc-'+work)/'.artifacts'/artifact/'current-handoff.json'
 data=json.loads(path.read_text())
 data['latest_stable_response_update']={k:v for k,v in latest.items() if k not in ('latest_frozen_candidate','reports')}
 data['latest_stable_response_update']['authoritative_handoff']=str(p)
 path.write_text(json.dumps(data,indent=2)+'\n')
print('Recorded v8/v9, retained failures and two pending jobs; all six old pointers updated.')

"""Checkpoint terminal v12 endpoints, preserving the original harness failure."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

worktree = Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root = worktree / '.artifacts/issue206-stable-response'


def read(name):
    return json.loads((root / name).read_text())


original = read('streamed-general-v1/report.json')
job = read('streamed-general-job-v1/report.json')
audit = read('streamed-general-replay-final-v1.json')
all_samples = read('streamed-general-v1/all-sample-audit.json')
assert original['status'] != 'running' and job['status'] != 'running'
assert audit['status'] == 'completed evidence audit'
assert len(audit['phases']) == 4 and not audit['pending_phases']
assert all_samples['completed_endpoints'] == 4
assert all_samples['failed_or_rejected_endpoints'] == 0
assert all(p['execution_and_response_audit'] == 'passed' for p in audit['phases'])
checkpoint = {
    'scope': 'Terminal v12 diagnostic evidence; original harness failure preserved separately from independent numerical/execution audit.',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'previous_completed_evidence': str(root / 'completed-checkpoint-v6.json'),
    'library_sha256': audit['library_sha256'],
    'native_source_identity': audit['native_source_identity'],
    'slurm_job_id': '9943',
    'original_controller_status': original['status'],
    'original_job_status': job['status'],
    'original_job_rows': job['rows'],
    'independent_replay_audit': str(root / 'streamed-general-replay-final-v1.json'),
    'practical': {k: v for k, v in all_samples.items() if k not in ('cases', 'tests')},
    'phase_summary': [{k: v for k, v in p.items() if k in (
        'phase', 'energy_error', 'force_error', 'iterations', 'host_graph_replays',
        'graph_constructions', 'response_route', 'response_scratch_bytes',
        'response_borrowed_factor_bytes', 'response_raw_value_bytes',
        'source_work_stream_plus_verified_replays')} for p in audit['phases']],
    'stationarity_cpu_diagnosis': str(root / 'stationarity-corrections-v1/report.json'),
    'retained_boundaries': [
        'Original density1e-10 request remains unqualified. All new octamer endpoints requested1e-12.',
        'The original controller failed its fresh-capture-per-phase assumption. Cached graph work is validated by the separate replay audit; the original result is not overwritten.',
        'v10 numerical failure and all earlier incomplete/cancelled jobs remain preserved.',
        'Remaining supported-route qualification, direct-path acceptance, and clean stock GPU4PySCF comparisons are incomplete.',
    ],
}
for name in ('streamed-general-v1/report.json', 'streamed-general-job-v1/report.json',
             'streamed-general-replay-final-v1.json', 'streamed-general-v1/all-sample-audit.json'):
    checkpoint.setdefault('evidence_sha256', {})[name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
with (root / 'completed-checkpoint-v7.json').open('x') as stream:
    stream.write(json.dumps(checkpoint, indent=2) + '\n')
path = root / 'current-handoff.json'
with (root / 'handoff-before-v10.json').open('xb') as stream:
    stream.write(path.read_bytes())
latest = read('current-handoff.json')
latest['observed_at_utc'] = checkpoint['created_at_utc']
latest['completed_evidence_audit'] = str(root / 'completed-checkpoint-v7.json')
latest['pending_jobs_at_update'] = {}
for name, report in (('streamed-general-v1', original), ('streamed-general-job-v1', job)):
    latest['reports'][name] = {k: report[k] for k in ('status', 'slurm_job_id', 'rows') if k in report}
latest['live_job_observation'] = {
    'status': 'terminated; all four numerical endpoints completed',
    'original_controller_status': original['status'],
    'audit': str(root / 'streamed-general-replay-final-v1.json'),
}
latest['v12_endpoint_qualification'] = checkpoint['phase_summary']
latest['stationarity_cpu_diagnosis'] = checkpoint['stationarity_cpu_diagnosis']
latest['remaining_boundaries'] = checkpoint['retained_boundaries'] + [
    'Dense seed/final streamed K still regenerates42 raw tensors per build; qualification of general response is not a low-memory latency claim.',
    'Tiny-scratch Coulomb, host-streamed compatibility, remaining truncated/general scopes and larger/domain holdouts still need coverage.',
]
latest['next'] = [
    'Use the prepared diagnose-changed-density-v2.py under finite main/5090 Slurm to capture current frozen-v12 densities at the original1e-10 request; resolve physical stationarity/Pulay error before choosing a production repair.',
    'Do not retry Slurm9943 to erase its controller failure. Existing arrays and replay/provenance suffice for corrected bookkeeping; retain both reports.',
    'Keep #415 switch, #206 open, #427 draft and #409 separate. No clean performance admission, commits or external posts from this checkpoint.',
]
latest['evidence_manifest'] = str(root / 'evidence-manifest-v9.json')
path.write_text(json.dumps(latest, indent=2) + '\n')
for work, artifact in [
    ('issue206-auxiliary', 'issue206-auxiliary'),
    ('issue206-response-diagnosis', 'issue206-response-diagnosis'),
    ('issue206-post418', 'issue206-post418'),
    ('issue418-cooperative-rys', 'issue418'),
    ('issue206-direct-fix', 'issue206'),
    ('issue409-packed', 'issue409'),
]:
    pointer = Path('/home/jzzeng/codes') / ('vibeqc-' + work) / '.artifacts' / artifact / 'current-handoff.json'
    data = json.loads(pointer.read_text())
    data['latest_stable_response_update'] = {
        k: v for k, v in latest.items() if k not in ('latest_frozen_candidate', 'reports')}
    data['latest_stable_response_update']['authoritative_handoff'] = str(path)
    pointer.write_text(json.dumps(data, indent=2) + '\n')
print('Checkpointed terminal v12 endpoints and preserved original controller failure.')

"""Preserve the partial live-job observation and its capture-gate diagnosis."""
import json
from datetime import datetime, timezone
from pathlib import Path

worktree = Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root = worktree / '.artifacts/issue206-stable-response'
path = root / 'current-handoff.json'
with (root / 'handoff-before-v9.json').open('xb') as stream:
    stream.write(path.read_bytes())
latest = json.loads(path.read_text())
observation = json.loads((root / 'streamed-general-observation-v2.json').read_text())
latest['observed_at_utc'] = datetime.now(timezone.utc).isoformat()
latest['live_job_observation'] = {
    'evidence': str(root / 'streamed-general-observation-v2.json'),
    'squeue_snapshot': observation['squeue_snapshot'],
    'completed_phases': [{k: v for k, v in row['endpoint'].items() if k != 'forces'}
                         for row in observation['completed_phases']],
    'pending_phases': observation['pending_phases'],
    'status': observation['status'],
    'capture_gate_diagnosis': observation['capture_gate_diagnosis'],
    'preserved_observer_failure': observation['preserved_observer_failure'],
}
latest['remaining_boundaries'][0] = (
    'Slurm9943 v12 cold and warm pass numerical/response gates, actually selecting '
    'general and canonical occupied response respectively. Changed/changed-warm '
    'are pending. Original controller incorrectly demands a fresh occupied-K '
    'capture in every phase and is expected to reject warm graph reuse. Preserve '
    'its original status; independently audit replay/provenance without retries '
    'or relaxed numerical gates. Whole-job qualification remains pending.')
latest['remaining_boundaries'][1] = (
    'Canonical occupied molecular response is now observed on octamer warm, '
    'at force error1.230e-12 with59568736 owned bytes and61440 borrowed factor '
    'bytes. Changed geometry and remaining supported routes still need qualification.')
latest['next'] = [
    'Continue live Slurm9943/session12007, finite45-minute limit. Do not restart. '
    'Cold and warm finished; changed/changed-warm pending.',
    'On termination preserve original controller status. Audit all endpoints and '
    'response counters. Diagnose expected missing warm K-capture assertion using '
    'existing cached-graph progress/provenance, rather than launch a retry.',
    'Keep all original numerical failures, #415 switch, #206 open, #427 draft, '
    '#409 separate. No clean benchmarks, commits, pushes, PRs or comments in this continuation.',
]
latest['evidence_manifest'] = str(root / 'evidence-manifest-v8.json')
path.write_text(json.dumps(latest, indent=2) + '\n')
for work, artifact in [
    ('issue206-auxiliary', 'issue206-auxiliary'),
    ('issue206-response-diagnosis', 'issue206-response-diagnosis'),
    ('issue206-post418', 'issue206-post418'),
    ('issue418-cooperative-rys', 'issue418'),
    ('issue206-direct-fix', 'issue206'),
    ('issue409-packed', 'issue409'),
]:
    pointer = Path('/home/jzzeng/codes') / ('vibeqc-' + work) / '.artifacts' / artifact / 'current-handoff.json'
    data = json.loads(pointer.read_text())
    data['latest_stable_response_update'] = {
        k: v for k, v in latest.items() if k not in ('latest_frozen_candidate', 'reports')}
    data['latest_stable_response_update']['authoritative_handoff'] = str(path)
    pointer.write_text(json.dumps(data, indent=2) + '\n')
print('Recorded two completed numerical phases, the preserved capture-gate failure, and live job9943.')

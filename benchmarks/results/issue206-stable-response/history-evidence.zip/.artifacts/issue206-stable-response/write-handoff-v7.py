"""Close the v10/v11 checkpoint with a failed cold streamed boundary; no active jobs."""
import json
from datetime import datetime, timezone
from pathlib import Path
worktree=Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root=worktree/'.artifacts/issue206-stable-response'
p=root/'current-handoff.json'
with (root/'handoff-before-v7.json').open('xb') as stream:stream.write(p.read_bytes())
latest=json.loads(p.read_text())
latest['observed_at_utc']=datetime.now(timezone.utc).isoformat()
for name in ('streamed-occupied-v4','streamed-occupied-job-v4'):
 d=json.loads((root/name/'report.json').read_text())
 latest['reports'][name]={k:d[k] for k in ('status','slurm_job_id','rows','srun_exit_code','completed_force_endpoints','failed_force_endpoints','unfinished_phase','not_started_phases') if k in d}
latest['pending_jobs_at_update']={}
latest['completed_evidence_audit']=str(root/'completed-checkpoint-v5.json')
latest['small_qualification_audit']=str(root/'completed-checkpoint-v4.json')
latest['failed_streamed_boundary_v10']='Slurm9939 frozen v10: source-first occupied K selected,984 generated rows=5.125 logical passes per captured K. SCF converges20iterations, but strict finalization rejects one frame and updates density once; old SCF factors no longer match the corrected final identity. New occupied response not selected. Old general bounded response gives cold force error4.8908516056545e-9 >3e-11 (energy error0). Deliberately cancelled during warm after observing failed cold. Changed phases never start; actual exit143, not timeout or timing sample.'
latest['scheduling_extension_denial']='Slurm denied requested20->45minute scheduling extension; original20-minute finite limit remained. Job subsequently cancelled because of completed cold numerical failure.'
latest['stop_decision_v10']=str(root/'streamed-occupied-stop-v2.json')
latest['remaining_boundaries']=['The streamed owned occupied response is still only natively qualified: strict final density correction prevents original SCF factors from being borrowed on the practical octamer. Its actual general fallback fails cold force accuracy at4.891e-9.','Corrected/arbitrary-density bounded general response remains numerically unqualified; do not weaken exact density/generation checks to activate occupied response. Either give the verified corrected frame its own factors or stabilize this fallback.','Source-first occupied K is qualified by physical/capture/native memcheck and fixed-density independent tests, but dense seeds and final Fock fallback still repeat costly raw-source generation. No endpoint speedup admission.','Original1e-10 first-changed water force remains failed; streamed Coulomb tiny-scratch and host compatibility routes retain old behavior; no clean timing or stock GPU4PySCF admission.']
latest['next']=['Repair verified post-correction factor ownership or the bounded general response; retain exact model/owner/density/generation gates. A stale SCF factor is not the corrected final state.','Use a bounded independent fixed-density/physical test to establish the changed mechanism before another costly four-phase endpoint. Preserve Slurm9939 failed cold and incomplete warm; no unchanged retry for admission.','Keep #415 switch; #206 open, #427 draft; #409 separate. No clean benchmarks, commits, pushes, PRs or comments in this continuation.']
latest['evidence_manifest']=str(root/'evidence-manifest-v5.json')
p.write_text(json.dumps(latest,indent=2)+'\n')
for work,artifact in [('issue206-auxiliary','issue206-auxiliary'),('issue206-response-diagnosis','issue206-response-diagnosis'),('issue206-post418','issue206-post418'),('issue418-cooperative-rys','issue418'),('issue206-direct-fix','issue206'),('issue409-packed','issue409')]:
 path=Path('/home/jzzeng/codes')/('vibeqc-'+work)/'.artifacts'/artifact/'current-handoff.json'
 data=json.loads(path.read_text());data['latest_stable_response_update']={k:v for k,v in latest.items() if k not in ('latest_frozen_candidate','reports')}
 data['latest_stable_response_update']['authoritative_handoff']=str(p)
 path.write_text(json.dumps(data,indent=2)+'\n')
print('Finalized v10/v11 evidence and six prior pointers; no running Slurm jobs or build. Goal remains incomplete.')

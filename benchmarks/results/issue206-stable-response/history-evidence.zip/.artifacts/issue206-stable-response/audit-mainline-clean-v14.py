"""Recompute all predeclared v14 warm cells without importing a GPU library.

Keep failed, slower and unstable cells. A paired warm numerical/timing win is
only a domain-specific ordinary-latency observation; independent residual,
cold/changed, direct and complete resource requirements remain separate.
"""
import hashlib
import json
import math
from collections import Counter
from pathlib import Path
from statistics import median

import numpy as np

if not __debug__:
    raise RuntimeError('Evidence assertions require non-optimized Python')
root = Path('.artifacts/issue206-stable-response')
out = root / 'mainline-clean-v14'
manifest = json.loads((out / 'manifest.json').read_text())
assert 'status' in manifest, 'Audit only the completed controller'
protocol = manifest['predeclared_statistics']
assert protocol == {'repeats': 7, 'maximum_relative_mad': .03, 'minimum_reduction': .02,
                    'bootstrap_pairs': 10000, 'seed': 206, 'confidence': .95}


def flatten(value):
    if isinstance(value, list):
        for item in value:
            yield from flatten(item)
    else:
        assert isinstance(value, (int, float)) and math.isfinite(value)
        yield value


def error(first, second):
    return max(abs(a - b) for a, b in zip(flatten(first), flatten(second), strict=True))


def statistics(samples):
    times = [s['seconds'] for s in samples]
    assert len(times) == 7 and all(math.isfinite(t) and t > 0 for t in times)
    center = median(times)
    branches = Counter(tuple(c['iterations'] for c in s['convergence']) for s in samples)
    return {'seconds': times, 'median_seconds': center,
            'relative_mad': median(abs(t - center) for t in times) / center,
            'branches': [{'iterations': list(k), 'count': v} for k, v in sorted(branches.items())],
            'reported_residuals': [[c['final_residuals'] for c in s['convergence']] for s in samples]}


points = []
for case, batch, energy_gate, force_gate, gradient, forces, domain in manifest['points']:
    name = f'{domain}-{case}-b{batch}-' + ('forces' if forces else 'energy')
    entry = next(r for r in manifest['checks'] if r['name'] == name)
    point = {'name': name, 'domain': domain, 'batch_size': batch,
             'observable': 'energy_and_force' if forces else 'energy',
             'controller_status': entry['status']}
    points.append(point)
    path = out / (name + '.json')
    if not path.exists():
        point.update(classification='incomplete_or_failed_execution', numeric_pass=False)
        continue
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['result_sha256']
    data = json.loads(path.read_text())
    native = data['native_build']
    assert native['library_sha256'] == manifest['build']['library_sha256']
    assert native['probe']['source_identity'] == manifest['build']['native_source_identity']
    assert data['settings']['gates']['maximum_energy_error_hartree'] == energy_gate
    if forces:
        assert data['settings']['gates']['maximum_force_error_hartree_per_bohr'] == force_gate
    qualification = json.loads((out / f'{domain}-{case}-b{batch}-qualification.json').read_text())
    assert qualification['contract_engine'] == 'cuTENSOR'
    resources = data['settings']['density_fitting_metric_diagnostics']
    assert len(resources) == len(qualification['results']) == batch
    for n, s in zip(resources, qualification['results'], strict=True):
        assert s['matching_full_rank']
        assert n['effective_rank'] == s['gpu4pyscf_effective_rank'] == s['naux']
    samples = {engine: data[engine]['warm_samples'] for engine in ('vibeqc', 'gpu4pyscf')}
    assert all(len(s) == 7 for s in samples.values())
    sequence = sorted((s['sequence_index'], engine) for engine, values in samples.items() for s in values)
    assert [i for i, _ in sequence] == list(range(14))
    assert [e for _, e in sequence] == data['settings']['measurement_order']
    paired = []
    for n, s, recorded in zip(samples['vibeqc'], samples['gpu4pyscf'], data['accuracy']['paired_warm_repeats'], strict=True):
        de = error(n['energies_hartree'], s['energies_hartree'])
        df = error(n['forces_hartree_per_bohr'], s['forces_hartree_per_bohr']) if forces else None
        assert de == recorded['maximum_energy_error_hartree']
        assert df == recorded['maximum_force_error_hartree_per_bohr']
        assert len(n['convergence']) == len(s['convergence']) == batch
        converged = all(c['converged'] for c in n['convergence'] + s['convergence'])
        matching = [c['iterations'] for c in n['convergence']] == [c['iterations'] for c in s['convergence']]
        assert matching == recorded['iteration_branches_match']
        paired.append({'energy_error': de, 'force_error': df, 'converged': converged,
                       'matching_iteration_branch': matching,
                       'passed': converged and de <= energy_gate and (not forces or df <= force_gate)})
    passed = all(p['passed'] for p in paired)
    assert passed == entry['numerically_qualified'] == data['gate']['passed']
    stats = {engine: statistics(s) for engine, s in samples.items()}
    for engine in stats:
        assert stats[engine]['median_seconds'] == data[engine]['warm_median_seconds']
    nt, st = (np.asarray(stats[e]['seconds']) for e in ('vibeqc', 'gpu4pyscf'))
    indices = np.random.default_rng(206).integers(0, 7, size=(10000, 7))
    reductions = 1 - np.median(nt[indices], axis=1) / np.median(st[indices], axis=1)
    interval = np.quantile(reductions, [.025, .975]).tolist()
    reduction = 1 - median(nt) / median(st)
    stable = all(s['relative_mad'] <= .03 for s in stats.values())
    clean = entry['clean_process_gate']
    if not passed:
        classification = 'failed_numeric_gate'
    elif not clean or not stable:
        classification = 'inconclusive_cleanliness_or_variability'
    elif reduction >= .02 and interval[0] > .02:
        classification = 'ordinary_warm_win'
    elif reduction <= -.02 and interval[1] < -.02:
        classification = 'ordinary_warm_loss'
    else:
        classification = 'tie_or_inconclusive'
    point.update(ao_count=data['workload']['ao_count'], naux=qualification['results'][0]['naux'],
                 numeric_pass=passed, paired_accuracy=paired, ordinary=stats,
                 classification=classification, native_reduction=reduction,
                 stock_over_native=median(st) / median(nt), bootstrap95_reduction=interval,
                 stable=stable, clean=clean, measured_single_cold_seconds={e: data[e]['cold_seconds'] for e in samples},
                 metric_and_native_reservations=resources, stock_versions=qualification['versions'])
summary = {'scope': __doc__, 'slurm_job_id': manifest['slurm_job_id'], 'points': points,
           'point_count': len(points), 'predeclared_statistics': protocol,
           'classification_counts': dict(Counter(p['classification'] for p in points)),
           'library_sha256': manifest['build']['library_sha256'],
           'native_source_identity': manifest['build']['native_source_identity'],
           'all_declared_warm_numeric_pass': all(p['numeric_pass'] for p in points),
           'goal_complete': False,
           'limitations': ['Ordinary warm latency only; iteration counts do not establish matched operator work.',
                          'Cold/changed repetitions, direct acceptance, independent residual coverage and complete memory/work remain required.',
                          'Strict1e-12 independent residual failures stay a separate follow-up under user steering.']}
with (out / 'summary-v1.json').open('x') as stream:
    stream.write(json.dumps(summary, indent=2, allow_nan=False) + '\n')
for p in points:
    print(p['name'], p['classification'], round(p.get('stock_over_native', 0), 3))
print(summary['classification_counts'])

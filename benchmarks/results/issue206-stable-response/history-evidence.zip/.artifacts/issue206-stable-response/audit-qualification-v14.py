"""Audit every saved v14 molecular endpoint without running GPU work.

Component traces count final provider calls and physical-weight products. The
qualification did not enable progress traces, so probe/promotion counts cannot
be recovered separately and must not be invented from component records.
"""
import ast
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

root = Path('.artifacts/issue206-stable-response')
out = root / 'qualification-v14'
frozen = json.loads((root / 'candidate-v14/manifest.json').read_text())
audit = json.loads((out / 'all-sample-audit.json').read_text())
groups = defaultdict(list)
rows = []
for case in audit['cases']:
    directory = out / case['directory']
    identity = json.loads((directory / 'identity.json').read_text())
    assert identity == case['identity']
    native = identity['native_build']
    # These saved fixtures are neutral doublet OH and singlet water tetramer.
    atoms = Counter(symbol for symbol, _ in ast.literal_eval(identity['case']))
    assert atoms in (Counter(O=1, H=1), Counter(O=4, H=8))
    spins = 2 if atoms == Counter(O=1, H=1) else 1
    assert native['library_sha256'] == frozen['library_sha256']
    assert native['probe']['source_identity'] == frozen['native_source_identity']
    saved = json.loads((directory / 'results.json').read_text())
    assert saved == case['rows']
    assert [r['phase'] for r in saved] == ['cold', 'warm', 'changed', 'changed_warm']
    for row in saved:
        assert row['energy_error'] <= 3e-11 and row['force_error'] <= 3e-11
        trace = directory / (row['phase'] + '.jsonl')
        events = [json.loads(line) for line in trace.read_text().splitlines()]
        assert all(e['valid'] for e in events)
        start = next(i for i, e in enumerate(events)
                     if e['operation'] == 'final_state_physical_fock')
        final = events[start:]
        counts = Counter(e['operation'] for e in final)
        weighted = [e for e in final if e['operation'] == 'final_state_weighted_density']
        assert len(weighted) == 1 and weighted[0]['counters']['physical_weight_gemms'] == 2 * spins
        assert counts['force_response'] == 1
        item = {
            'directory': case['directory'], 'phase': row['phase'],
            'density_tolerance': identity['density_tolerance'],
            'energy_error': row['energy_error'], 'force_error': row['force_error'],
            'scf_iterations': row['iterations'],
            'final_component_records': dict(counts),
            'observed_final_provider_solves': sum(e.get('counters', {}).get('device_eigensolves', 0)
                for e in final if e['operation'] == 'production_eigensolve'),
            'physical_weight_gemms': sum(e['counters']['physical_weight_gemms'] for e in weighted),
            'trace_sha256': hashlib.sha256(trace.read_bytes()).hexdigest(),
        }
        rows.append(item)
        groups[str(identity['density_tolerance'])].append(item)
assert len(rows) == 92 and len(audit['cases']) == 23
summary = {}
for request, items in groups.items():
    summary[request] = {
        'completed_endpoints': len(items),
        'maximum_energy_error': max(r['energy_error'] for r in items),
        'maximum_force_error': max(r['force_error'] for r in items),
        'final_provider_solves_total': sum(r['observed_final_provider_solves'] for r in items),
        'final_provider_solves_per_endpoint_range': [min(r['observed_final_provider_solves'] for r in items),
                                                    max(r['observed_final_provider_solves'] for r in items)],
        'physical_weight_gemms_total': sum(r['physical_weight_gemms'] for r in items),
    }
result = {
    'scope': __doc__, 'status': 'passed', 'library_sha256': frozen['library_sha256'],
    'native_source_identity': frozen['native_source_identity'], 'by_request': summary, 'rows': rows,
    'limitations': ['Probe/promotion split unavailable because progress tracing was disabled.',
                   'Component records do not constitute complete SCF graph replay work or clean timing.',
                   'Historical v12 numerical failures and v13 snapshot-test failure are unchanged.'],
}
with (out / 'per-request-audit-v1.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(summary, indent=2))

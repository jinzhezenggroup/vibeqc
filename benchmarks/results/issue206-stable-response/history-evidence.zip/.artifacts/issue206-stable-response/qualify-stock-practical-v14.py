"""Observe the installed stock provider and actual metric ranks outside timing.

Each call qualifies one comparison cell. Wrapping decomposition records its
unchanged return; no rank threshold or factorization policy is replaced.
"""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--case',required=True);p.add_argument('--batch',type=int,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--orbital-basis-file',type=Path,required=True)
p.add_argument('--auxiliary-basis-file',type=Path,required=True)
a=p.parse_args()
assert os.environ.get('SLURM_JOB_ID') and not a.output.exists()
import cupy as cp
import numpy as np
from gpu4pyscf.df import df as gpu_df
from gpu4pyscf.lib import cutensor
from pyscf import df, gto, scf
from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import scaled_geometries, load_comparison_basis
assert cutensor.cutensor is not None and cutensor.contract_engine is None,'stock cuTENSOR provider unavailable'
original=gpu_df._decompose_j2c;observed=[]
def observe(*args,**kwargs):
    result=original(*args,**kwargs)
    observed.append({'factorization':result[1],'coefficient_shape':list(result[0].shape),
        'dtype':str(result[0].dtype),'fallback_absolute_threshold':float(gpu_df.LINEAR_DEP_THR)})
    return result
gpu_df._decompose_j2c=observe
case=benchmark_cases()[a.case]
orbital,reference_orbital=load_comparison_basis(a.orbital_basis_file,case,role='orbital',compute_forces=True)
auxiliary,reference_auxiliary=load_comparison_basis(a.auxiliary_basis_file,case,role='auxiliary',compute_forces=True)
payload={'scope':__doc__,'slurm_job_id':os.environ['SLURM_JOB_ID'],
    'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'contract_engine':'cuTENSOR',
    'versions':{n:importlib.metadata.version(n) for n in ('gpu4pyscf-cuda12x','cupy-cuda12x','cutensor-cu12','pyscf','numpy')},
    'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'results':[]}
a.output.parent.mkdir(parents=True,exist_ok=True)
for slot,atoms in enumerate(scaled_geometries(case.atoms,a.batch)):
    mol=gto.M(atom=atoms,unit='Bohr',basis=reference_orbital,
        cart=case.basis_representation=='cartesian',charge=case.charge,spin=case.multiplicity-1,verbose=0)
    aux=df.addons.make_auxmol(mol,reference_auxiliary)
    metric=aux.intor('int2c2e');eig=np.linalg.eigvalsh(metric);start=len(observed)
    engine=(scf.UHF(mol) if case.method=='uhf' else scf.RHF(mol)).density_fit(auxbasis=reference_auxiliary).to_gpu()
    engine.with_df.build();cp.cuda.runtime.deviceSynchronize()
    # The active bdiv producer returns a device-ordered list; the retained
    # legacy producer returns a device-keyed dictionary. Observe either actual
    # container without assuming that a nearby source function is active.
    blocks=engine.with_df._cderi
    assert isinstance(blocks,(dict,list,tuple))
    entries=blocks.items() if isinstance(blocks,dict) else enumerate(blocks)
    shapes={str(k):list(v.shape) for k,v in entries}
    rank=sum(s[0] for s in shapes.values())
    row={'case':a.case,'batch':a.batch,'slot':slot,'atoms':atoms,'unit':'Bohr',
        'representation':case.basis_representation,'nbf':mol.nao,'naux':aux.nao,
        'orbital_basis':mol._basis,'auxiliary_basis':aux._basis,
        'reference_metric_sha256':hashlib.sha256(metric.tobytes()).hexdigest(),
        'reference_metric_extrema':[float(eig[0]),float(eig[-1])],
        'reference_condition':float(eig[-1]/eig[0]),'relative_threshold':1e-10,
        'reference_effective_rank':int(np.count_nonzero(eig>1e-10*eig[-1])),
        'gpu4pyscf_factor_blocks':shapes,'gpu4pyscf_effective_rank':rank,
        'gpu4pyscf_factor_container':type(blocks).__name__,
        'gpu4pyscf_df_class':type(engine.with_df).__module__+'.'+type(engine.with_df).__name__,
        'gpu4pyscf_decomposition':observed[start:],'gpu4pyscf_default_initial_guess':engine.init_guess}
    row['matching_full_rank']=rank==row['reference_effective_rank']==aux.nao
    payload['results'].append(row);a.output.write_text(json.dumps(payload,indent=2)+'\n')
    assert row['matching_full_rank'],row
    del engine, blocks, entries
    cp.get_default_memory_pool().free_all_blocks()
print(a.case,a.batch,'stock cuTENSOR and matching full ranks verified',flush=True)

"""CPU-only inverse ordering probe using retained OH density, integrals and CUDA factors.

No native execution, factorization, SCF or timing. This cannot qualify the GPU
candidate; it checks the distinct inverse application orders before that test.
"""
import hashlib
import json
from pathlib import Path

import numpy as np

root = Path('/home/jzzeng/codes/vibeqc-issue206-auxiliary/.artifacts/issue206-auxiliary')
local = Path('.artifacts/issue206-stable-response/cpu-inverse-order-v1')
local.mkdir(exist_ok=False)
fixture_path = root/'oh-force-components-v1/fixed-weights-and-reference.npz'
factors_path = root/'oh-response-weights-v1/response-arrays.npz'
f = np.load(fixture_path,allow_pickle=False)
g = np.load(factors_path,allow_pickle=False)
a,d,x,q,l = f['a'],f['density'],g['inverse_root'],g['eigenvectors'],g['eigenvalues']
report = {'scope':__doc__,'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in
          (Path(__file__),fixture_path,factors_path)},'rows':[]}
arrays = {}
for label,b in (
    ('eigen_factors', ((a@q)/l)@q.T),
    ('inverse_root_twice', (a@x)@x),
    ('inverse_matrix_first', a@(x@x)),
):
    total = d.sum(axis=0)
    c = np.einsum('ij,ijp->p',total,b)
    u = np.array([ds@b.transpose(2,0,1)@ds for ds in d]).transpose(0,2,3,1)
    wa = total[:,:,None]*c-u.sum(axis=0)
    wm = -.5*np.outer(c,c)+.5*np.einsum('sijp,ijq->pq',u,b,optimize=True)
    delta_a = np.einsum('axijp,ijp->ax',f['da'],wa-f['bar_a'])
    delta_m = np.einsum('axpq,pq->ax',f['dm'],wm-f['bar_m'])
    report['rows'].append({'label':label,'three_center_force_delta':delta_a.tolist(),
         'metric_force_delta':delta_m.tolist(),
         'combined_force_error':float(np.max(np.abs(delta_a+delta_m)))})
    arrays[label+'_a'],arrays[label+'_m'] = wa,wm
np.savez_compressed(local/'weights.npz',**arrays)
report['weights_sha256'] = hashlib.sha256((local/'weights.npz').read_bytes()).hexdigest()
(local/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

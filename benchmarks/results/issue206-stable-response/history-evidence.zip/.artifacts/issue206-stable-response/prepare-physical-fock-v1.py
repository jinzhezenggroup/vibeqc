"""Freeze a CPU-only fixed-density fixture from a failed v14 residual sample."""
import hashlib
import json
from pathlib import Path

import numpy as np
from pyscf import df, gto, scf
from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis

root = Path('.artifacts/issue206-stable-response')
out = root / 'physical-fock-input-v1'
out.mkdir(exist_ok=False)
audit_path = root / 'larger-v14-residuals/report.json'
audit = json.loads(audit_path.read_text())
selected = next(r for r in audit['rows'] if r['configuration'] == 'octamer-b1-dense-tight'
                and r['phase'] == 'changed' and r['index'] == 0)
assert selected['status'] == 'failed independent gate'
state = selected['physical']
array_path = root / 'larger-v14-residuals/states' / f'state{state["state_id"]:03d}.npz'
assert hashlib.sha256(array_path.read_bytes()).hexdigest() == state['arrays_sha256']
saved = np.load(array_path, allow_pickle=False)
references = json.loads((root / 'larger-reference-v1/report.json').read_text())
key = state['case']
case = benchmark_cases()[key]
bases = Path('benchmarks/results/issue206-practical-auxiliary/identity')
for name in ('cc-pvdz.json', 'cc-pvdz-jkfit.json'):
    path = bases / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == references['input_sha256'][str(path)]
_, orbital = load_comparison_basis(bases / 'cc-pvdz.json', case, role='orbital', compute_forces=True)
_, auxiliary = load_comparison_basis(bases / 'cc-pvdz-jkfit.json', case, role='auxiliary', compute_forces=True)
mol = gto.M(atom=references['cases'][key]['changed_geometry'], basis=orbital, unit='Bohr', verbose=0)
aux = df.addons.make_auxmol(mol, auxiliary)
mf = scf.RHF(mol).density_fit(auxbasis=auxiliary)
mf.direct_scf_tol = 1e-14
density, overlap = saved['density'], saved['overlap']
j, k = mf.get_jk(dm=density)
np.savez(out / 'reference.npz', density=density, overlap=overlap, hcore=mf.get_hcore(),
         fock=mf.get_hcore() + j - .5 * k, coulomb=j, exchange=k,
         metric=aux.intor('int2c2e', hermi=1), old_fock=saved['fock'])
np.save(out / 'raw.npy', df.incore.aux_e2(mol, aux, aosym='s1'), allow_pickle=False)


def shells(model):
    """Expand contraction columns in public AO order from the explicit basis."""
    result = []
    for atom in range(model.natm):
        for shell in model._basis[model.atom_symbol(atom)]:
            angular, rows = shell[0], shell[1:]
            for column in range(1, len(rows[0])):
                result.append((atom, angular, [(r[0], r[column]) for r in rows]))
    return result


orbital_shells, auxiliary_shells = shells(mol), shells(aux)
with (out / 'input.txt').open('x') as stream:
    stream.write(f'vibeqc-response-v1 {mol.natm} {len(orbital_shells)} {len(auxiliary_shells)} {mol.nao} {aux.nao}\n')
    for charge, xyz in zip(mol.atom_charges(), mol.atom_coords(), strict=True):
        stream.write(str(charge) + ' ' + ' '.join(format(v, '.17g') for v in xyz) + '\n')
    for atom, angular, primitives in orbital_shells + auxiliary_shells:
        stream.write(f'{atom} {angular} {len(primitives)}\n')
        for exponent, coefficient in primitives:
            stream.write(f'{exponent:.17g} {coefficient:.17g}\n')
    np.savetxt(stream, density, fmt='%.17g')
    np.savetxt(stream, overlap, fmt='%.17g')
report = {'scope': __doc__, 'source_failed_endpoint': selected, 'nbf': mol.nao, 'naux': aux.nao,
          'input_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in [Path(__file__), audit_path, array_path, bases / 'cc-pvdz.json', bases / 'cc-pvdz-jkfit.json']},
          'fixture_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}}
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print('Prepared exact failed state', state['state_id'], mol.nao, aux.nao)

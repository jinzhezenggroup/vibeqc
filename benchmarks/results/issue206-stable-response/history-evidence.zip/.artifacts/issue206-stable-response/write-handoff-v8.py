"""Checkpoint qualified bounded general response and the live four-phase job."""
import json
from datetime import datetime, timezone
from pathlib import Path
worktree=Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root=worktree/'.artifacts/issue206-stable-response'
p=root/'current-handoff.json'
with (root/'handoff-before-v8.json').open('xb') as stream:stream.write(p.read_bytes())
latest=json.loads(p.read_text())
latest['observed_at_utc']=datetime.now(timezone.utc).isoformat()
latest['previous_candidates']['v11']=latest['latest_frozen_candidate']['library_sha256']
latest['latest_frozen_candidate']=json.loads((root/'candidate-v12/manifest.json').read_text())
for name in ('qualification-v12','general-response-v2','streamed-general-v1','streamed-general-job-v1'):
 data=json.loads((root/name/'report.json').read_text())
 latest['reports'][name]={k:data[k] for k in ('status','slurm_job_id','rows') if k in data}
latest['pending_jobs_at_update']={'streamed-general-v1':{'slurm_job_id':'9943','session':12007,'time_limit':'00:45:00','frozen_candidate':'v12','status':'running'}}
latest['completed_evidence_audit']=str(root/'completed-checkpoint-v6.json')
latest['v12_extension']='Stable general full-rank response for arbitrary/corrected densities. Regenerate all-Q raw AO-pair blocks into two existing metric scratch matrices, project Q^T, divide lambda, rotate requested fitted B columns. Existing bounded response forms both adjoints before quadratic products. No new allocation or occupied-factor lease; truncated spectral fallback unchanged. Counts all ceil(Naux/tile)^2 raw passes.'
latest['v12_qualification']='Slurm9940: new native physical tests and native memcheck pass(0errors);97 Python tests pass.52 complete small endpoints pass(E<=2.388e-12,F<=4.271e-13) at density1e-12. Slurm9942 fixed-D octamer: v11 bounded192MiB fails4.775e-9; v12 bounded192MiB passes8.811e-13; v12 single-tensor384MiB passes6.253e-13. Bounded arms both own201044576bytes. New16rawpasses/4378853376bytes; no latency claim.'
latest['fixed_density_fixture']=str(root/'general-response-input-v1/report.json')
latest['preserved_launch_failure']=str(root/'general-response-v1-launch-failure.json')
latest['build_status']='Completed and frozen v12; no active build.'
latest['github_status_check']={'206':'OPEN','394':'CLOSED','404':'CLOSED','409':'OPEN','412':'CLOSED','427':'OPEN draft','source':'gh issue/pr view queried during v12 continuation'}
latest['remaining_boundaries']=['General bounded response passes native and independent fixed-density molecular gates. Complete cold/warm/changed/changed-warm coverage is still pending Slurm9943; original v10 cold failure remains recorded.','Streamed canonical occupied response still needs molecular coverage where exact factors are actually eligible; do not bypass corrected-state provenance.','Dense seeds/final Fock builds still repeat costly raw-source work. Stable general response adds raw passes and is not performance-admitted.','Original1e-10 stationarity failure, tiny-scratch/host compatibility routes, direct-path acceptance and stock GPU4PySCF performance remain open.']
latest['next']=['Wait on the verified live Slurm9943/session12007 without restarting on an observation timeout. Audit all four numerical endpoints, loaded identity, actual response route and raw/memory counts.','Preserve all failures. If changed v12 fails, diagnose the actual route/sample before another attempt; no unchanged retry for admission.','Keep #415 switch; #206 open, #427 draft; #409 separate. No clean benchmarks, commits, pushes, PRs or comments in this continuation.']
latest['evidence_manifest']=str(root/'evidence-manifest-v6.json')
p.write_text(json.dumps(latest,indent=2)+'\n')
for work,artifact in [('issue206-auxiliary','issue206-auxiliary'),('issue206-response-diagnosis','issue206-response-diagnosis'),('issue206-post418','issue206-post418'),('issue418-cooperative-rys','issue418'),('issue206-direct-fix','issue206'),('issue409-packed','issue409')]:
 path=Path('/home/jzzeng/codes')/('vibeqc-'+work)/'.artifacts'/artifact/'current-handoff.json'
 data=json.loads(path.read_text());data['latest_stable_response_update']={k:v for k,v in latest.items() if k not in ('latest_frozen_candidate','reports')}
 data['latest_stable_response_update']['authoritative_handoff']=str(p)
 path.write_text(json.dumps(data,indent=2)+'\n')
print('Recorded v12 completed evidence and live Slurm9943; all six prior pointers updated.')

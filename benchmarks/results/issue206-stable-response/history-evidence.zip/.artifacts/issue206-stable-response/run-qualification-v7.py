"""Qualify v7 packed bounded GEMM and overlapping expansion; no timing admission."""
import hashlib
import json
import os
import subprocess
import sys
import traceback
from pathlib import Path

assert os.environ.get('SLURM_JOB_ID')
root=Path('.artifacts/issue206-stable-response')
out=root/'qualification-v7'
out.mkdir(exist_ok=False)
frozen=json.loads((root/'candidate-v7/manifest.json').read_text())
library=(root/'candidate-v7/libvibeqc.so').resolve()
with library.open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==frozen['library_sha256']
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str(library),VIBEQC_RESOURCE_CUDA_TEST='1',VIBEQC_DF_DERIVATIVE_CUDA_TEST='1',
    PYTHONPATH='python:.',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',
    LD_LIBRARY_PATH=str((root/'candidate-v7-loader').resolve())+':/group/software/cuda-12.9.1/lib64')
commands=[
    ('native',[str(root/'candidate-v7/vibeqc_df_occupied_response_tests')]),
    ('memcheck',['/group/software/cuda-12.9.1/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','99',
                 str(root/'candidate-v7/vibeqc_df_occupied_response_tests')]),
    ('packed-bounded',['/tmp/vibeqc-review-env/bin/python',str(root/'diagnose-packed-bounded-v1.py')]),
    ('python',['/tmp/vibeqc-review-env/bin/python','-m','pytest','-q',
        'tests/python/test_df_packed_values_cuda.py','tests/python/test_df_resident_response_cuda.py',
        '--basetemp='+str(out/'tmp'),'--junitxml='+str(out/'report.xml')]),
]
report={'scope':__doc__,'status':'running','slurm_job_id':os.environ['SLURM_JOB_ID'],
    'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'frozen':frozen,'rows':[]}
def save():
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
    for name,command in commands:
        row={'name':name,'command':command,'status':'running'}
        report['rows'].append(row)
        save()
        with (out/(name+'.txt')).open('x') as stream:
            result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
        row.update(status='completed',exit_code=result.returncode)
        save()
        print(name,result.returncode,flush=True)
    report['status']='passed' if all(r['exit_code']==0 for r in report['rows']) else 'failed; all groups retained'
except Exception:
    report.update(status='failed controller',exception=traceback.format_exc())
    raise
finally:
    save()
sys.exit(0 if report['status']=='passed' else 1)

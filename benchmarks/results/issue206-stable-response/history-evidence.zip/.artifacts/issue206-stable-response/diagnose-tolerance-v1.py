"""Predeclared untimed tolerance sweep of the remaining first-changed force error.

Use density tolerances 1e-11 and 1e-12 for both OH and water, dense and packed,
with all four phases. Gates stay 3e-11. These changed-request diagnostics never
replace the failed original 1e-10 qualification or establish performance.
"""
import hashlib
import importlib.util
import json
import os
import traceback
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from vibeqc import Calculator
from vibeqc.progressive import _retained_density
from benchmarks.compare_gpu4pyscf_batch import native_build_metadata

assert os.environ.get('SLURM_JOB_ID')
root=Path('.artifacts/issue206-stable-response')
out=root/'tolerance-v1'
out.mkdir(exist_ok=False)
source=Path('tests/python/test_df_practical_response_cuda.py')
spec=importlib.util.spec_from_file_location('practical_reference_diagnostic',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
frozen=json.loads((root/'candidate-v4/manifest.json').read_text())
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str((root/'candidate-v4/libvibeqc.so').resolve()),
    VIBEQC_DF_EXCHANGE='occupied',VIBEQC_DF_RESPONSE_STORAGE='auto',VIBEQC_DF_RESPONSE_SPACE='auto',
    VIBEQC_DF_RESPONSE_ALGEBRA='blas',VIBEQC_DF_FORCE_SCREEN_ABS='off',
    VIBEQC_DF_REFERENCE_FINAL_VALIDATION='0',VIBEQC_DF_WEIGHTED_EXECUTION='shell')
report={'scope':__doc__,'status':'running','slurm_job_id':os.environ['SLURM_JOB_ID'],
    'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'frozen':frozen,'rows':[],
    'density_tolerances':[1e-11,1e-12],'references':{},'loaded_libraries':[],
    'inputs':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),source)}}
def save():
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
    for name in ('oh-def2-svp-spherical-uhf','water-tetramer-def2-svp-spherical'):
        case,orbital,auxiliary,moved,references=module.practical_reference.__wrapped__(SimpleNamespace(param=name))
        report['references'][name]=[{'energy':float(e),'force':f.tolist()} for e,f in references]
        save()
        for tolerance in report['density_tolerances']:
            for values in ('dense','packed'):
                label=f'{name}-{values}-{tolerance:g}'
                os.environ.update(VIBEQC_DF_VALUE_STORAGE=values,VIBEQC_DF_DERIVATIVE_PAIRS='packed' if values=='packed' else 'full')
                os.environ['VIBEQC_DF_TRACE']=str(out/(label+'-prepare.jsonl'))
                os.environ['VIBEQC_DF_PROGRESS_TRACE']=str(out/(label+'-prepare-progress.jsonl'))
                try:
                    calc=Calculator(method=case.method,basis=orbital,auxiliary_basis=auxiliary,
                        basis_representation='spherical',device='cuda',density_fitting='cuda',
                        max_iterations=100,energy_tolerance=1e-12,density_tolerance=tolerance,screening_tolerance=1e-14)
                    loaded=native_build_metadata(calc)
                    assert loaded['library_sha256']==frozen['library_sha256']
                    report['loaded_libraries'].append({'selection':label,**loaded})
                    save()
                    with calc.prepare_batch([case.atoms],charges=[case.charge],multiplicities=[case.multiplicity],warm_start=True) as batch:
                        batch.set_warm_start_updates(True)
                        for phase,changed in (('cold',False),('warm',False),('changed',True),('changed_warm',True)):
                            os.environ['VIBEQC_DF_TRACE']=str(out/(label+'-'+phase+'.jsonl'))
                            os.environ['VIBEQC_DF_PROGRESS_TRACE']=str(out/(label+'-'+phase+'-progress.jsonl'))
                            row={'case':name,'values':values,'density_tolerance':tolerance,'phase':phase,'status':'running'}
                            report['rows'].append(row)
                            save()
                            item=batch.execute([np.array([r for _,r in moved])] if changed else None,strict=True).items[0]
                            density_path=out/(label+'-'+phase+'-density.npy')
                            np.save(density_path,_retained_density(batch),allow_pickle=False)
                            energy,force=references[int(changed)]
                            row.update(status='complete',energy=item.energy,forces=np.asarray(item.forces).tolist(),
                                energy_error=abs(item.energy-energy),force_error=float(np.max(np.abs(item.forces-force))),
                                iterations=item.iterations,density_rms=item.density_rms,energy_change=item.energy_change,
                                density_sha256=hashlib.sha256(density_path.read_bytes()).hexdigest())
                            row['numeric_pass']=row['energy_error']<=3e-11 and row['force_error']<=3e-11
                            save()
                            print(label,phase,row['energy_error'],row['force_error'],row['numeric_pass'],flush=True)
                except Exception:
                    report['rows'].append({'selection':label,'status':'failed','exception':traceback.format_exc()})
                    save()
    report['status']='completed tolerance diagnostic; original 1e-10 request remains failed'
except Exception:
    report.update(status='failed diagnostic',exception=traceback.format_exc())
    raise
finally:
    save()

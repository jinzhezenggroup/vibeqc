"""Record current candidate state without rewriting historical evidence."""
import json
from datetime import datetime, timezone
from pathlib import Path

worktree = Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root = worktree / '.artifacts/issue206-stable-response'
reports = {}
for name in ('qualification-v4', 'compatibility-v2', 'tolerance-v1', 'qualification-v5', 'compatibility-v3', 'budget-boundaries-v1', 'single-tensor-memcheck-v1', 'qualification-v6', 'budget-boundaries-v2', 'streamed-memcheck-v1', 'larger-batch-v1'):
    path = root / name / 'report.json'
    if path.exists():
        d = json.loads(path.read_text())
        reports[name] = {k: d[k] for k in ('status', 'slurm_job_id', 'rows') if k in d and (k != 'rows' or name != 'tolerance-v1')}
latest = {
    'observed_at_utc': datetime.now(timezone.utc).isoformat(),
    'worktree': str(worktree),
    'branch': 'codex/issue206-stable-full-rank-response',
    'base': 'c20e83cda2260b8c30eb95d23a3127c42bfac0ca',
    'status': 'uncommitted numerical candidate, not fully qualified; no numerical PR or performance admission',
    'native_test_checkpoint': str(root/'native-single-tensor-checkpoint-v1/manifest.json'),
    'latest_frozen_candidate': json.loads((root / 'candidate-v6/manifest.json').read_text()),
    'previous_candidates': {v: json.loads((root / f'candidate-{v}/manifest.json').read_text())['library_sha256'] for v in ('v1','v2','v3','v4','v5')},
    'reports': reports,
    'strict_budget_v4': str(root / 'practical-tight-v1/audit.json'),
    'strict_budget_v4_summary': '12 pass, dense water 128 MiB fails energy 5.514e-11/force 2.380e-9, packed water 128 MiB cold OOM; 52 completed endpoints retained',
    'original_gate': 'Original 1e-10 density request still fails first-changed water force about 3.956e-11 versus 3e-11. Tighter diagnostic requests never reclassify it.',
    'v5_extension': 'Streamed forward Q/lambda factors, one complete fitted response tensor plus bounded W where capacity allows; one response raw pass; no small-budget qualification yet.',
    'v5_budget_result': '128 MiB dense passes all four phases <=6.822e-13 energy/4.538e-13 force, 464 raw slices once at same 67,090,752-byte scratch. 16 MiB response-only dense/packed and 96 MiB total dense pass. 80 MiB dense, 128/160 MiB packed reject cold before plan creation.',
    'v5_compatibility': 'Slurm9924: 5 native tests, 126 Python tests, occupied native memcheck zero errors. Initial Slurm9923 streamed probe loader failure remains retained.',
    'cpu_budget_lower_bounds': {'scope':'Native CPU-only planner, excludes source and DIIS reservations; no device work.', 'dense_value_bytes':43241659, 'packed_value_bytes':85079227, 'force_value_fraction':0.5},
    'v6_extension': 'Private source-generated streamed K uses E=A Q /sqrt(lambda); complete auxiliary contraction is invariant under Q^T, so omit the symmetric rotation and repeated full eigenprojection. Resident C and all response conventions are unchanged. Fixed packed raw-byte counter on bounded whitened reads.',
    'pending_jobs_at_update': {'9926': {'session':63403,'scope':'frozen-v5 complete water single-tensor memcheck, finite20m'}, '9927': {'session':45387,'scope':'frozen-v6 controls/native/streamed/practical, finite20m'}, '9928': {'session':28764,'scope':'frozen-v6 budget boundaries, finite20m'}, '9929': {'session':64931,'scope':'frozen-v6 augmented native and streamed probes memcheck, finite15m'}},
    'prepared_larger_batch_script': str(root/'diagnose-larger-batch-v1.py'),
    'loader_failure': 'Slurm9923 streamed probe exited 127 before numerical execution because frozen directory lacked libvibeqc.so.0; retained. compatibility-v3 selects a separate symlink loader pointing at the same frozen v5.',
    'merged_431': {'merge_commit': 'e3ea91d8aba401b692c9c5bea804bddb91631176', 'final_head': '72a3638cf2598022b585a1a5a2ef51d3bb2513bd', 'status': 'merged after final-head CI and local evidence review; CodeRabbit skipped its automatic review'},
    'constraints': ['Keep #415 switch; user accepts 2.50%-2.65% endpoint benefit.', 'Keep #206 open and #427 draft; #412 closed negative; #409 capacity/crossover separate.', 'No subagents; all real GPU work finite main/5090 Slurm.', 'Preserve all failures and samples; no unchanged clean retries for admission, gate relaxation, or diagnostic/clean pooling.', 'No builds or profiling during clean timing; no clean benchmark in this continuation.'],
    'next': ['Finish v6 controls, budget and both sanitizer audits; pending job map is historical, consult reports/sacct.', 'Qualify remaining truly bounded and small-panel fallbacks before promoting.', 'Retain packed budget rejection and account resources instead of silently changing storage.', 'After v6 qualification, run prepared larger/batch diagnostic; original cold/warm/changed and stock GPU4PySCF comparison remain required.'],
}
latest.update(
    evidence_manifest=str(root/'evidence-manifest-v1.json'),
    native_test_status='Augmented single-tensor native regression passed in Slurm9927; checkpoint source/executable hashes recorded separately from unchanged frozen v6 library.',
    v6_qualification='Slurm9927: 18 controls, 5 native, 4 streamed J/K tests pass; practical 13 pass plus packed128MiB OOM. All52 completed endpoints pass E/F 3e-11 at density tolerance1e-12, maximum force4.924e-13.',
    whole_endpoint_memcheck='Slurm9926 frozen-v5 full water128MiB memcheck timed out at20m before completing a force endpoint; no sanitizer summary, not a pass. Terminal evidence retained; sacct unavailable.',
    larger_cpu_reference=str(root/'larger-reference-v1/report.json'),
    prepared_larger_batch_script=str(root/'diagnose-larger-batch-v2.py'),
    larger_batch_job={'slurm_job_id':'9930','session':56929,'time_limit':'00:20:00','scope':'frozen-v6 octamerB1 and tetramerB2 dense/packed, all phases, cached independent CPU references; not clean timing'},
    remaining_boundaries=['Response without resident C and without space for one complete fitted tensor is still unqualified.', 'Streamed Coulomb with scratch shorter than Naux retains the old inverse-root route.', 'Host-streamed compatibility whitening remains unchanged.', 'Larger/batch checks and full stock GPU4PySCF performance acceptance remain incomplete.'],
)
(root / 'current-handoff.json').write_text(json.dumps(latest, indent=2) + '\n')
for work, artifact in [('issue206-auxiliary','issue206-auxiliary'), ('issue206-response-diagnosis','issue206-response-diagnosis'), ('issue206-post418','issue206-post418'), ('issue418-cooperative-rys','issue418'), ('issue206-direct-fix','issue206'), ('issue409-packed','issue409')]:
    path = Path('/home/jzzeng/codes') / ('vibeqc-' + work) / '.artifacts' / artifact / 'current-handoff.json'
    if not path.exists():
        raise FileNotFoundError(path)
    data = json.loads(path.read_text())
    data['latest_stable_response_update'] = {k: v for k, v in latest.items() if k not in ('latest_frozen_candidate', 'reports')}
    data['latest_stable_response_update']['authoritative_handoff'] = str(root / 'current-handoff.json')
    path.write_text(json.dumps(data, indent=2) + '\n')
print('Updated stable-response and six earlier handoffs, preserving prior fields.')

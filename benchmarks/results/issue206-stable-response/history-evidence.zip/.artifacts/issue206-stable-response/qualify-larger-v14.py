"""Untimed v14 larger/batch qualification against preserved independent PySCF.

Predeclare dense/packed 192-AO B1, 96-AO B4 and 192-AO B4 at both the original
1e-10 and tight 1e-12 density requests. Retain all four phases and every batch
item under unchanged 3e-11 E/F gates. Save exact final densities for independent
residual reconstruction. Host/component/progress tracing makes this diagnostic
work only; no latency or stock-superiority claim is admitted.
"""
import hashlib
import json
import os
import traceback
from pathlib import Path

assert os.environ.get('SLURM_JOB_ID'), 'Real GPU work requires finite Slurm'
root = Path('.artifacts/issue206-stable-response')
out = root / 'larger-v14'
out.mkdir(exist_ok=False)
frozen = json.loads((root / 'candidate-v14/manifest.json').read_text())
library = (root / 'candidate-v14/libvibeqc.so').resolve()


def digest(path):
    """Hash evidence without loading the large native binary into memory."""
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


assert digest(library) == frozen['library_sha256']
for name, expected in frozen['records'].items():
    if name.startswith('source/src/'):
        assert digest(name.removeprefix('source/')) == expected, name
for name in list(os.environ):
    if name.startswith('VIBEQC_'):
        del os.environ[name]
os.environ.update(VIBEQC_LIBRARY=str(library), VIBEQC_RESOURCE_CUDA_TEST='1',
                  OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')

import numpy as np
import pytest
from vibeqc import Calculator
from vibeqc.progressive import _retained_density
from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis, native_build_metadata
from benchmarks.df_component_ledger import aggregate_host, read_host_trace
from benchmarks.df_host_workloads import validate_final_state_counts

shapes = [
    ('octamer-b1', 'water-octamer-s4-def2-svp-spherical', 1),
    ('tetramer-b4', 'water-tetramer-def2-svp-spherical', 4),
    ('octamer-b4', 'water-octamer-s4-def2-svp-spherical', 4),
]
settings = [
    {'name': f'{label}-{values}-{request}', 'case': key, 'batch_size': size,
     'values': values, 'density_tolerance': tolerance, 'memory_budget_bytes': 0}
    for request, tolerance in [('original', 1e-10), ('tight', 1e-12)]
    for label, key, size in shapes for values in ('dense', 'packed')
]
report = {
    'scope': __doc__, 'status': 'running', 'slurm_job_id': os.environ['SLURM_JOB_ID'],
    'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
    'frozen': frozen, 'runner_sha256': digest(__file__), 'predeclared_settings': settings,
    'gates': {'maximum_energy_error': 3e-11, 'maximum_force_error': 3e-11}, 'rows': [],
}


def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


save()
try:
    reference_path = root / 'larger-reference-v1/report.json'
    reference = json.loads(reference_path.read_text())
    assert reference['status'] == 'completed'
    report['cpu_reference_report_sha256'] = digest(reference_path)
    report['cpu_reference_verified_inputs'] = {}
    for name, expected in reference['input_sha256'].items():
        # The oracle used the frozen v6 generator. Today's edited test is not
        # that generator, while both explicit basis inputs must remain exact.
        original = root / 'candidate-v6/source' / name if name.startswith('tests/') else Path(name)
        assert digest(original) == expected, str(original)
        report['cpu_reference_verified_inputs'][str(original)] = expected
    save()
    bases = Path('benchmarks/results/issue206-practical-auxiliary/identity')
    for setting in settings:
        name, key, size, values, tolerance = (setting[k] for k in
            ('name', 'case', 'batch_size', 'values', 'density_tolerance'))
        directory = out / name
        directory.mkdir()
        row = {'name': name, 'status': 'running', 'settings': setting, 'phase_work': {}}
        report['rows'].append(row)
        save()
        results = []
        try:
            case = benchmark_cases()[key]
            assert case.method == 'rhf'
            saved = reference['cases'][key]
            assert [(s, list(r)) for s, r in case.atoms] == [(s, list(r)) for s, r in saved['original_geometry']]
            moved = [(s, np.array(r)) for s, r in saved['changed_geometry']]
            expected_moved = [(s, np.array(r)) for s, r in case.atoms]
            expected_moved[1][1][0] += 0.001
            assert all(s == t and np.array_equal(r, q) for (s, r), (t, q) in zip(moved, expected_moved, strict=True))
            orbital, _ = load_comparison_basis(bases / 'cc-pvdz.json', case, role='orbital', compute_forces=True)
            auxiliary, _ = load_comparison_basis(bases / 'cc-pvdz-jkfit.json', case, role='auxiliary', compute_forces=True)
            with pytest.MonkeyPatch.context() as mp:
                for env, value in {
                    'VIBEQC_DF_VALUE_STORAGE': values,
                    'VIBEQC_DF_RESPONSE_STORAGE': 'panel' if values == 'dense' else 'auto',
                    'VIBEQC_DF_RESPONSE_SPACE': 'dense' if values == 'dense' else 'occupied',
                    'VIBEQC_DF_RESPONSE_ALGEBRA': 'blas', 'VIBEQC_DF_EXCHANGE': 'occupied',
                    'VIBEQC_DF_FORCE_SCREEN_ABS': 'off', 'VIBEQC_DF_REFERENCE_FINAL_VALIDATION': '0',
                    'VIBEQC_DF_WEIGHTED_EXECUTION': 'shell',
                    'VIBEQC_DF_DERIVATIVE_PAIRS': 'packed' if values == 'packed' else 'full',
                    'VIBEQC_DF_TRACE': str(directory / 'prepare.jsonl'),
                    'VIBEQC_DF_PROGRESS_TRACE': str(directory / 'prepare-progress.jsonl'),
                }.items():
                    mp.setenv(env, value)
                calc = Calculator(method=case.method, basis=orbital, auxiliary_basis=auxiliary,
                    basis_representation='spherical', device='cuda', density_fitting='cuda',
                    density_fitting_memory_budget_bytes=0, energy_tolerance=1e-12,
                    density_tolerance=tolerance, screening_tolerance=1e-14, max_iterations=100)
                metadata = native_build_metadata(calc)
                assert metadata['library_sha256'] == frozen['library_sha256']
                assert metadata['probe']['source_identity'] == frozen['native_source_identity']
                write(directory / 'identity.json', {'settings': setting, 'native_build': metadata,
                    'slurm_job_id': report['slurm_job_id'], 'cuda_visible_devices': report['cuda_visible_devices']})
                with calc.prepare_batch([case.atoms] * size, charges=[case.charge] * size,
                        multiplicities=[case.multiplicity] * size, warm_start=True) as batch:
                    batch.set_warm_start_updates(True)
                    for phase, changed in [('cold', False), ('warm', False), ('changed', True), ('changed_warm', True)]:
                        mp.setenv('VIBEQC_DF_TRACE', str(directory / (phase + '.jsonl')))
                        mp.setenv('VIBEQC_DF_PROGRESS_TRACE', str(directory / (phase + '-progress.jsonl')))
                        mp.setenv('VIBEQC_DF_HOST_TRACE', str(directory / (phase + '-host.jsonl')))
                        positions = [np.array([r for _, r in moved])] * size if changed else None
                        try:
                            output = batch.execute(positions, strict=False)
                        finally:
                            mp.delenv('VIBEQC_DF_HOST_TRACE')
                        assert len(output.items) == size
                        oracle = saved['references'][int(changed)]
                        for index, item in enumerate(output.items):
                            actual = {'phase': phase, 'index': index, 'status': item.status,
                                      'status_message': item.status_message, 'iterations': item.iterations}
                            if item.succeeded:
                                actual.update(energy=item.energy, forces=np.asarray(item.forces).tolist(),
                                    energy_error=abs(item.energy - oracle['energy']),
                                    force_error=float(np.max(np.abs(item.forces - np.array(oracle['forces'])))),
                                    density_rms=item.density_rms, energy_change=item.energy_change)
                            results.append(actual)
                        # Persist native arrays before diagnostics or admission checks.
                        write(directory / 'results.json', results)
                        for index, item in enumerate(output.items):
                            if item.succeeded:
                                density = directory / f'{phase}-item{index}-density.npy'
                                np.save(density, _retained_density(batch, index)[0], allow_pickle=False)
                                results[-size + index]['density_sha256'] = digest(density)
                        write(directory / 'results.json', results)
                        write(directory / (phase + '-resources.json'),
                              [d.to_dict() for d in batch.last_density_fitting_metric_diagnostics()])
                        print(name, phase, 'completed', flush=True)
                        assert all(item.succeeded for item in output.items), (phase, results[-size:])
            # Check the whole declared trajectory after retaining all endpoints,
            # including any inaccurate earlier phase.
            row['numerical_gate'] = all(r['energy_error'] <= 3e-11 and r['force_error'] <= 3e-11 for r in results)
            for phase in ('cold', 'warm', 'changed', 'changed_warm'):
                ledger = aggregate_host(read_host_trace(directory / (phase + '-host.jsonl')))
                write(directory / (phase + '-ledger.json'), ledger)
                validate_final_state_counts(ledger, batch_size=size, method='rhf', force=False,
                                            reference=False, compute_forces=True)
                values_by_scope = {}
                with (directory / (phase + '-progress.jsonl')).open() as stream:
                    for line in stream:
                        event = json.loads(line)
                        if event.get('event') == 'VALUE' and event.get('key', '').startswith('final_'):
                            values_by_scope.setdefault(str(event['id']), {})[event['key']] = event['value']
                row['phase_work'][phase] = {
                    'finalization_progress': values_by_scope,
                    'exclusive_phases': {k: v for k, v in ledger['exclusive_phases'].items()
                                         if k.startswith('final_') or k == 'strict_final_correction'},
                    'eigensolves_by_reason': ledger['eigensolves_by_reason'],
                    'device_eigensolves_by_reason': ledger['device_eigensolves_by_reason'],
                }
            row['status'] = 'passed' if row['numerical_gate'] else 'failed numerical gate; all endpoints retained'
        except Exception:
            row.update(status='failed', exception=traceback.format_exc())
        save()
        print(name, row['status'], flush=True)
    report['status'] = 'passed' if all(r['status'] == 'passed' for r in report['rows']) else 'failed; all settings retained'
except Exception:
    report.update(status='failed controller', exception=traceback.format_exc())
    raise
finally:
    save()
raise SystemExit(0 if report['status'] == 'passed' else 1)

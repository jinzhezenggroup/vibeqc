"""Publish exact scientific records, excluding binaries, routine logs and traces."""

import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

root = Path.cwd()
art = root / '.artifacts/issue206-stable-response'
out = root / 'benchmarks/results/issue206-stable-response'
out.mkdir(parents=True, exist_ok=False)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


xml = art/'qualification-v14/report.xml'
cases = []
for case in ET.fromstring(xml.read_bytes()).iter('testcase'):
    failed = case.find('failure') is not None or case.find('error') is not None
    skipped = case.find('skipped') is not None
    cases.append({'class':case.attrib.get('classname'), 'name':case.attrib['name'],
                  'status':'failed' if failed else 'skipped' if skipped else 'passed'})
assert len(cases) == 138 and all(c['status']=='passed' for c in cases)
memcheck = art/'qualification-v14/memcheck.txt'
assert 'ERROR SUMMARY: 0 errors' in memcheck.read_text()
write_json(art/'qualification-v14/test-receipts-v1.json', {
    'slurm_job_id':'9946','source_junit_sha256':sha(xml.read_bytes()),
    'source_memcheck_sha256':sha(memcheck.read_bytes()),'memcheck_errors':0,
    'native_commands':'report.json retains exact commands and exit codes',
    'tests':cases})

groups = {
    'warm': set((art/'mainline-clean-v14').glob('*.json')),
    'numerical': {art/n for n in [
        'qualification-v14/report.json','qualification-v14/per-request-audit-v1.json',
        'qualification-v14/test-receipts-v1.json','larger-v14/report.json',
        'larger-v14/all-endpoint-ledger-v1.json','larger-v14-residuals/report.json',
        'larger-v14-oracle-diagnosis/report.json','larger-reference-v1/report.json',
        'physical-fock-v1/report.json','physical-fock-input-v1/report.json']},
    'sources': {p for p in (art/'candidate-v14/source').rglob('*') if p.is_file()} | {
        art/'candidate-v14/manifest.json',art/'candidate-v14/source.patch',
        art/'candidate-v14/build_identity.hpp',art/'candidate-v14/CMakeCache.txt',
        art/'review-source-binding-v1.json',art/'ownership-base-v1.json',
        art/'ownership-current-v1.json',art/'ownership-delta-v2.json'},
    'history': set(),
}
for pattern in ['qualification-v*/tmp/**/results.json','qualification-v*/tmp/**/identity.json',
                '*/report*.json','*/manifest.json','*.py']:
    groups['history'].update(art.glob(pattern))
seen = set()
manifest = {'schema':'vibeqc.issue206-review-evidence.v1',
            'scope':'Exact saved scientific records, including failed and interrupted candidates. Archive membership never implies admission.',
            'frozen_library_sha256':'54491bce358ce474c376d19a142d26182270506e224df217fc492e0f32e59355',
            'frozen_native_source_identity':'2edd5723c767c4006e2d743cf9b0ba09744685efd7038db89c367669297f14d2',
            'baseline_revision':'e3ea91d8aba401b692c9c5bea804bddb91631176',
            'archives':[], 'exclusions':['Shared libraries, executable products and build output',
                                       'Routine stdout and JUnit XML (named verdict receipts retained)',
                                       'Full retained density arrays and intrusive traces remain in local immutable artifact inventory'],
            'goal_complete':False}
for group, paths in groups.items():
    paths = sorted(paths-seen)
    seen.update(paths)
    target = out/(group+'-evidence.zip')
    entries = []
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in paths:
            data=p.read_bytes()
            name=p.relative_to(root).as_posix()
            info=zipfile.ZipInfo(name, date_time=(2026,9,17,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644 << 16
            archive.writestr(info,data,compresslevel=9)
            entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
    assert target.stat().st_size < 1 << 20, (target,target.stat().st_size)
    manifest['archives'].append({'path':target.name,'bytes':target.stat().st_size,
                                 'sha256':sha(target.read_bytes()),'members':entries})
    print(target.name,len(paths),target.stat().st_size)
write_json(out/'manifest.json',manifest)
# Keep the main verdict and ownership summary directly readable in review.
summary=json.loads((art/'mainline-clean-v14/summary-v1.json').read_text())
write_json(out/'warm-summary.json',summary)
write_json(out/'ownership-delta.json',json.loads((art/'ownership-delta-v2.json').read_text()))

labels={'ordinary_warm_win':'win','ordinary_warm_loss':'loss',
        'failed_numeric_gate':'FAILED numerical gate',
        'tie_or_inconclusive':'tie/inconclusive',
        'inconclusive_cleanliness_or_variability':'variable; inconclusive'}
names={'water-tetramer-def2-svp-spherical':'96', 'water-octamer-s4-def2-svp-spherical':'192',
       'water-hexadecamer-2s4-def2-svp-spherical':'384', 'water-32mer-4s4-def2-svp-spherical':'768',
       'oh-def2-svp-spherical-uhf':'OH/UHF','ammonia-def2-svp-spherical':'ammonia'}
table=[]
for p in summary['points']:
    label=p['name']
    for case, short in names.items(): label=label.replace(case,short)
    n=p['ordinary']['vibeqc']['median_seconds']*1000
    s=p['ordinary']['gpu4pyscf']['median_seconds']*1000
    table.append(f"| {label} | {n:.3f} | {s:.3f} | {labels[p['classification']]} |")
readme='''# Full-rank response and physical force-state evidence

This numerical repair applies metric inversion to linear factors before quadratic
products and validates the current physical-Fock projector before complete forces.
The frozen v14 library was used in Slurm 9946, 9947 and 9949. One subsequent
comment-only correction is bound explicitly in `review-source-binding-v1.json`.
No executable numerical code changed after qualification.

The 19-cell stock campaign completed with **11 warm wins, 3 losses, 2 inconclusive
results and 3 numerical failures**. This does not close #206 or establish universal
superiority. Every raw cell, qualifier, sample and failed verdict is retained.

## Warm endpoint results

Times below are milliseconds, median of seven interleaved synchronized repeats per
engine, using engine-local frozen post-cold densities and equivalent untimed
priming. These are complete ordinary energy/force endpoints with normal convergence
work, not fixed-iteration or matched-operator-work speedups. Native E/D requests
are 1e-12/1e-10; screening is 1e-14. Stock uses its normal cuTENSOR provider and
each cell independently verifies matching full retained auxiliary rank.

Predeclared statistics: both relative MAD <= 3%, reduction >= 2%, paired bootstrap
95% lower bound > 2%, 10,000 resamples with NumPy default_rng(206). Larger variable
and failed cells cannot supply a favorable performance claim.

| Cell (AO count, batch, endpoint) | VibeQC ms | Stock ms | Verdict |
| --- | ---: | ---: | --- |
'''+ '\n'.join(table)+'''

`equal` uses the original same-basis workloads. `practical` explicitly supplies
cc-pVDZ/cc-pVDZ-JKFIT; historical case names provide geometry/spin only. B4 stock
comparisons scale each geometry, unlike the identical-geometry independent batch
regressions. The original gates are preserved: equal 96 E/F 3e-11, equal 192
E 1e-10/F 5e-10, larger/OH/ammonia E 1e-9/F 1e-8; practical E/F 3e-11.
Stock gradient tolerances are 1e-9 (96), 1e-8 (192), and 1e-10 otherwise.

The cached CPU reference matches the practical 192 B1 geometry and bases exactly.
Across seven saved samples, maximum native force error is 7.524e-13 and stock
error is 1.4375e-10. This diagnoses one failed comparison; its paired verdict
remains failed. The cached reference cannot qualify scaled B4 geometries.

## Numerical qualification and limits

- Slurm 9946: native final-state, device-validation, snapshot and occupied-response
  tests passed; CUDA memcheck reported zero errors; all 138 Python tests passed.
  The 23 practical configurations retain 92 endpoints across cold, warm, changed
  and changed-warm phases. Original 1e-10 (40 endpoints) max E/F errors are
  2.274e-12/2.5615e-11; tight 1e-12 (52 endpoints) 2.387e-12/4.3302e-13.
- Slurm 9947: dense/packed 192 B1, 96 B4 and 192 B4 retain 144 endpoints, 72 at
  each density request. All pass the unchanged E/F 3e-11 gates. All **72 original
  1e-10 endpoints** pass independent CPU residual gates. **24 tight 1e-12 octamer
  endpoints fail** independent commutator/projector gates; maximum defects are
  1.0795e-12 and 1.4493e-12. These remain failures and are a separate follow-up.
- Work ledgers count current-F solves and promoted probes without duplicate
  solves: original group 158 Focks/solves, 86 corrections, 80 probes, 8 promotions;
  tight group 164/92/82/10. Intrusive timing is excluded from clean comparisons.
- Small 128-MiB v14 tests do not qualify the larger v14 constrained-memory boundary.
  Earlier v12 low-memory results cannot qualify the changed force-state selection.
- Repeated cold/changed timing, full independent residual coverage, direct-path
  failures, and complete process memory/operator-work accounting remain for #206.
  No failure, tolerance or correction cap is waived by this PR.

## Reproduction and retention

Run from the repository root with a Python containing NumPy:

```bash
python benchmarks/results/issue206-stable-response/replay.py
```

This CPU-only command verifies every archive/member hash, extracts to a temporary
directory, recomputes all warm verdicts, and compares the result with the retained
summary. The archives preserve exact source scripts, scientific arrays in JSON,
input/geometry/basis identities, frozen build manifest, numerical audits, named
test receipts and historical failures. `manifest.json` binds compressed and
uncompressed bytes. Archive inclusion never implies numerical admission.

`sources-evidence.zip` contains the frozen changed sources, patch, build cache,
build identity and ownership reports. Reconstruct production from the reported
base and frozen sources; use the normal repository CMake build. The runners in
`history-evidence.zip` preserve exact historical commands and paths. Adapt only
environment/library/output locations for new runs, retain the numerical settings,
and use a new output directory. Each GPU run must use finite Slurm allocation:

```bash
srun --partition=main --gres=gpu:5090:1 --nodes=1 --ntasks=1 \\
  --time=00:30:00 bash -lc '<qualification or clean comparator command>'
```

Keep Slurm device visibility unchanged. Never overlap clean timing with builds,
profilers or intrusive tracing. The exact clean controller has 19 predeclared
cells; it exits nonzero when any cell fails and retains all completed samples.
Production has no CPU oracle dependency. Saved density arrays, full component
traces, failed-run stdout and binaries remain in the local artifact inventory;
Git retains compact scientific records and hashes, not the multi-GB build tree.

Ownership versus e3ea91d: handwritten scientific roles +583/-40 (scientific
+578/-40, oracle +5/-0), runtime +9/-0, no unchanged-line reclassification.
Generated capabilities are unchanged. Spectral rank-deficient, bounded-source
and scalar/serial routes remain necessary fallbacks/oracles. The decision note
records their retirement conditions and every material rejected alternative.
'''
(out/'README.md').write_text(readme)

"""CPU-only independent molecular DF derivative fixture; no native SCF or timing."""
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pyscf
from pyscf import df, gto, lib, scf

lib.num_threads(2)
root = Path('.artifacts/issue206-stable-response')
out = root / 'general-response-input-v1'
out.mkdir(exist_ok=False)
source = Path('tests/python/test_df_practical_response_cuda.py')
spec = importlib.util.spec_from_file_location('practical_response', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
case, _, _, orbital, auxiliary = module._practical_model('water-octamer-s4-def2-svp-spherical')
mol = gto.M(atom=case.atoms, basis=orbital, unit='Bohr', verbose=0)
aux = df.addons.make_auxmol(mol, auxiliary)
mf = scf.RHF(mol).density_fit(auxbasis=auxiliary)
mf.conv_tol, mf.conv_tol_grad, mf.max_cycle = 1e-13, 1e-12, 200
mf.direct_scf_tol = 1e-14
mf.kernel()
assert mf.converged
density = mf.make_rdm1()
gradient = mf.nuc_grad_method()
gradient.auxbasis_response = True
vhf = gradient.get_veff(mol, density)
expected = np.array(vhf.aux, copy=True)
for atom, (_, _, begin, end) in enumerate(mol.aoslice_by_atom()):
    expected[atom] += 2 * np.einsum('xij,ij->x', vhf[:, begin:end], density[begin:end])
overlap = mf.get_ovlp()
fock = mf.get_fock(dm=density)
commutator = fock @ density @ overlap - overlap @ density @ fock
metric = aux.intor('int2c2e')
eigenvalues = np.linalg.eigvalsh(metric)
assert np.all(np.isfinite(expected))
assert np.max(np.abs(commutator)) < 1e-10
assert np.count_nonzero(eigenvalues > 1e-10 * eigenvalues[-1]) == aux.nao

def shells(model):
    values = []
    for atom in range(model.natm):
        for shell in model._basis[model.atom_symbol(atom)]:
            angular, rows = shell[0], shell[1:]
            for column in range(1, len(rows[0])):
                values.append((atom, angular, [(r[0], r[column]) for r in rows]))
    return values

orbital_shells, auxiliary_shells = shells(mol), shells(aux)
with (out / 'input.txt').open('x') as stream:
    stream.write(f'vibeqc-response-v1 {mol.natm} {len(orbital_shells)} {len(auxiliary_shells)} {mol.nao} {aux.nao}\n')
    for charge, xyz in zip(mol.atom_charges(), mol.atom_coords(), strict=True):
        stream.write(str(charge) + ' ' + ' '.join(format(v, '.17g') for v in xyz) + '\n')
    for atoms, angular, primitives in orbital_shells + auxiliary_shells:
        stream.write(f'{atoms} {angular} {len(primitives)}\n')
        for exponent, coefficient in primitives:
            stream.write(f'{exponent:.17g} {coefficient:.17g}\n')
    np.savetxt(stream, density, fmt='%.17g')
    np.savetxt(stream, overlap, fmt='%.17g')
np.savez_compressed(out / 'reference.npz', density=density, overlap=overlap,
                    two_electron_derivative=expected, metric_eigenvalues=eigenvalues)
inputs = [source, Path(__file__),
          Path('benchmarks/results/issue206-practical-auxiliary/identity/cc-pvdz.json'),
          Path('benchmarks/results/issue206-practical-auxiliary/identity/cc-pvdz-jkfit.json')]
record = {'scope': __doc__, 'engine': 'PySCF', 'version': pyscf.__version__,
          'nbf': mol.nao, 'naux': aux.nao, 'metric_relative_threshold': 1e-10,
          'metric_min_max': [float(eigenvalues[0]), float(eigenvalues[-1])],
          'energy': float(mf.e_tot), 'commutator_max': float(np.max(np.abs(commutator))),
          'two_electron_derivative': expected.tolist(),
          'input_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
          'fixture_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                             for p in (out / 'input.txt', out / 'reference.npz')}}
(out / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k not in ('two_electron_derivative', 'input_sha256')}, indent=2))

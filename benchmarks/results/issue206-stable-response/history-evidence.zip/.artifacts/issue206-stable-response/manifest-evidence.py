"""Hash a declared completed-evidence checkpoint, excluding active outputs."""
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

root=Path('.artifacts/issue206-stable-response')
version=sys.argv[1]
active=set(sys.argv[2:])
out=root/f'evidence-manifest-{version}.json'
if out.exists():raise FileExistsError(out)
files={};links={}
for directory, subdirs, names in os.walk(root, followlinks=False):
    base=Path(directory)
    if base==root:
        subdirs[:]=[n for n in subdirs if n not in active]
    subdirs[:]=[n for n in subdirs if n!='__pycache__']
    for name in list(subdirs)+names:
        p=base/name
        rel=str(p.relative_to(root))
        if p.is_symlink():
            links[rel]=os.readlink(p)
            continue
        if not p.is_file() or name=='current-handoff.json' or name.startswith('evidence-manifest-'):
            continue
        with p.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
        files[rel]={'sha256':digest,'bytes':p.stat().st_size}
manifest={'scope':'Completed local evidence checkpoint; mutable handoffs, prior umbrella manifests, bytecode and declared active output directories excluded.',
    'created_at_utc':datetime.now(timezone.utc).isoformat(),
    'active_output_directories_excluded':sorted(active),'files':files,'symlinks_not_double_counted':links}
out.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(str(out),len(files),'files',sum(f['bytes'] for f in files.values()),'bytes')

"""Record v14 qualification while preserving all earlier failed candidates."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

worktree = Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root = worktree / '.artifacts/issue206-stable-response'
path = root / 'current-handoff.json'
latest = json.loads(path.read_text())
frozen = json.loads((root / 'candidate-v14/manifest.json').read_text())
qualification = json.loads((root / 'qualification-v14/report.json').read_text())
audit = json.loads((root / 'qualification-v14/per-request-audit-v1.json').read_text())
assert qualification['status'] == audit['status'] == 'passed'
assert qualification['frozen'] == frozen
assert qualification['slurm_job_id'] == '9946'
assert audit['library_sha256'] == frozen['library_sha256']
assert latest['latest_frozen_candidate']['library_sha256'] != frozen['library_sha256']
with (root / 'handoff-before-v12.json').open('xb') as stream:
    stream.write(path.read_bytes())

summary = {
    'status': 'passed for declared v14 small-molecule and native suites; larger systems pending',
    'slurm_job_id': '9946', 'native_source_identity': frozen['native_source_identity'],
    'library_sha256': frozen['library_sha256'], 'python_tests_passed': 138,
    'groups': qualification['rows'], 'by_request': audit['by_request'],
    'reports': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in [
        'qualification-v13/report.json', 'qualification-v14/report.json',
        'qualification-v14/report.xml', 'qualification-v14/all-sample-audit.json',
        'qualification-v14/per-request-audit-v1.json']},
    'limitations': audit['limitations'],
}
checkpoint = {
    'scope': 'Completed changed-candidate numerical checkpoint, without timing admission.',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'previous_completed_evidence': str(root / 'completed-checkpoint-v8.json'),
    'v14_qualification': summary, 'active_gpu_jobs': [],
    'goal_status': 'incomplete; larger, supported-route, direct-path and stock performance gates remain',
}
with (root / 'completed-checkpoint-v9.json').open('x') as stream:
    stream.write(json.dumps(checkpoint, indent=2) + '\n')
for version in ('v12', 'v13'):
    old = json.loads((root / ('candidate-' + version) / 'manifest.json').read_text())
    latest['previous_candidates'][version] = old['library_sha256']
latest.update(
    observed_at_utc=checkpoint['created_at_utc'],
    status='uncommitted v14 force-state repair; declared small/native qualification passed; no performance admission',
    latest_frozen_candidate=frozen,
    completed_evidence_audit=str(root / 'completed-checkpoint-v9.json'),
    v14_qualification=summary,
    original_gate='Changed v14 passes all 40 declared original1e-10 small endpoints at unchanged3e-11 E/F gates. Historical v12 failure remains failed; remaining original #206 matrix is not qualified.',
    pending_jobs_at_update={},
    evidence_manifest=str(root / 'evidence-manifest-v11.json'),
    next=[
        'Qualify v14 larger cc-pVDZ/JKFIT shapes and batches at separately declared original1e-10 and tight1e-12 requests; verify cached independent reference provenance.',
        'Record progress and actual probes/promotions/provider work in new larger runs. Do not infer the unavailable split from v14 small component traces.',
        'Requalify v14 low-memory streamed octamer; earlier v12 success does not qualify changed force selection.',
        'Integrate newer master when appropriate, qualify remaining supported routes/direct path/holdouts and run at least five interleaved clean stock comparisons before any superiority claim.',
        'Keep #415 switch, #206 open, #427 draft and #409 separate; preserve every historical failure.',
    ],
)
latest['reports']['qualification-v13'] = {
    'status': 'failed at obsolete snapshot callback after native analytic suites; unchanged failure retained',
    'slurm_job_id': '9945', 'production_library_identical_to_v14': True,
}
latest['reports']['qualification-v14'] = summary
# Preserve revised documentation independently of the earlier native freeze.
snapshot = root / 'post-v14-documentation-v1'
snapshot.mkdir(exist_ok=False)
for name in ['docs/df_final_state.md', 'docs/fock_build.md', 'docs/df_component_trace.md',
             '.agents/notes/proposed/2026-09-17-full-rank-response-candidate.md']:
    target = snapshot / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((worktree / name).read_bytes())
latest['post_freeze_documentation'] = str(snapshot)
path.write_text(json.dumps(latest, indent=2) + '\n')
for work, artifact in [
    ('issue206-auxiliary', 'issue206-auxiliary'),
    ('issue206-response-diagnosis', 'issue206-response-diagnosis'),
    ('issue206-post418', 'issue206-post418'),
    ('issue418-cooperative-rys', 'issue418'),
    ('issue206-direct-fix', 'issue206'),
    ('issue409-packed', 'issue409'),
]:
    pointer = worktree.parent / ('vibeqc-' + work) / '.artifacts' / artifact / 'current-handoff.json'
    data = json.loads(pointer.read_text())
    data['latest_stable_response_update'] = {
        k: v for k, v in latest.items() if k not in ('latest_frozen_candidate', 'reports')}
    data['latest_stable_response_update']['authoritative_handoff'] = str(path)
    pointer.write_text(json.dumps(data, indent=2) + '\n')
print('v14 completed qualification recorded; no active GPU jobs at this checkpoint.')

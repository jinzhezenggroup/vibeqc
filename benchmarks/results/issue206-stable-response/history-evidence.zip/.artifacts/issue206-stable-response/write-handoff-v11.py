"""Checkpoint current-v12 original-tolerance failure after completed diagnostics."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

worktree = Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root = worktree / '.artifacts/issue206-stable-response'
report_path = root / 'changed-density-v2/report.json'
report = json.loads(report_path.read_text())
assert report['slurm_job_id'] == '9944'
assert len(report['rows']) == 4 and all(r['status'] == 'complete' for r in report['rows'])
changed = next(r for r in report['rows'] if r['phase'] == 'changed')
assert changed['native_force_error'] > 3e-11
assert changed['reconstructed']['consistent']['vs_oracle'] > 3e-11
path = root / 'current-handoff.json'
with (root / 'handoff-before-v11.json').open('xb') as stream:
    stream.write(path.read_bytes())
latest = json.loads(path.read_text())
assert report['native_build']['library_sha256'] == latest['latest_frozen_candidate']['library_sha256']
assert report['native_build']['probe']['source_identity'] == latest['latest_frozen_candidate']['native_source_identity']
summary = {
    'scope': report['scope'], 'status': report['status'], 'slurm_job_id': '9944',
    'report': str(report_path),
    'report_sha256': hashlib.sha256(report_path.read_bytes()).hexdigest(),
    'native_build_sha256': report['native_build']['library_sha256'],
    'rows': [{k: r[k] for k in ('phase', 'iterations', 'density_rms',
              'native_energy_error', 'physical_energy_error', 'native_force_error',
              'commutator', 'canonical_density_drift')} | {
                  'consistent_force_error': r['reconstructed']['consistent']['vs_oracle'],
                  'canonical_force_error': r['reconstructed']['canonical']['vs_oracle'],
              } for r in report['rows']],
    'conclusion': 'Current original1e-10 first-changed request still fails. Consistent weights alone also fail; physical stationarity needs repair. Native finalization already used two Fock evaluations and one density correction.',
}
checkpoint = {
    'scope': 'Completed diagnostic checkpoint, preserving every failed numerical gate.',
    'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'previous_completed_evidence': str(root / 'completed-checkpoint-v7.json'),
    'current_tolerance_diagnosis': summary,
    'active_gpu_jobs': [],
    'goal_status': 'incomplete; no stock superiority or direct-path admission',
}
with (root / 'completed-checkpoint-v8.json').open('x') as stream:
    stream.write(json.dumps(checkpoint, indent=2) + '\n')
latest['observed_at_utc'] = checkpoint['created_at_utc']
latest['completed_evidence_audit'] = str(root / 'completed-checkpoint-v8.json')
latest['original_tolerance_current_v12'] = summary
latest['original_gate'] = (
    'Slurm9944 confirms current frozen-v12 density1e-10 first-changed water force '
    'error3.955578833231277e-11 >3e-11. Independent CPU at the exact native density '
    'with consistent DFD/2 weights still fails3.0257574223924166e-11. '
    'Tight1e-12 successes never reclassify this failure.')
latest['pending_jobs_at_update'] = {}
latest['next'] = [
    'Choose and implement a physically justified final-stationarity/consistent-force-state repair using current saved v12 densities. Native reconstructed density RMS0 is not the physical fixed-point defect; changed CPU fixed-point drift is1.099e-10. Do not merely tighten the external request or force an already-performed rebuild.',
    'Retain original1e-10 numerical gates and all phases in the next changed-candidate qualification, with independent density/Fock/force evidence and counted correction work.',
    'Do not rerun9943 to erase its harness failure. All four completed1e-12 endpoints pass the separate replay audit; original controller exit1 remains retained.',
    'Keep #415 switch, #206 open, #427 draft and #409 separate. Remaining supported-route, direct-path and clean stock GPU4PySCF gates remain required.',
]
latest['evidence_manifest'] = str(root / 'evidence-manifest-v10.json')
path.write_text(json.dumps(latest, indent=2) + '\n')
for work, artifact in [
    ('issue206-auxiliary', 'issue206-auxiliary'),
    ('issue206-response-diagnosis', 'issue206-response-diagnosis'),
    ('issue206-post418', 'issue206-post418'),
    ('issue418-cooperative-rys', 'issue418'),
    ('issue206-direct-fix', 'issue206'),
    ('issue409-packed', 'issue409'),
]:
    pointer = Path('/home/jzzeng/codes') / ('vibeqc-' + work) / '.artifacts' / artifact / 'current-handoff.json'
    data = json.loads(pointer.read_text())
    data['latest_stable_response_update'] = {
        k: v for k, v in latest.items() if k not in ('latest_frozen_candidate', 'reports')}
    data['latest_stable_response_update']['authoritative_handoff'] = str(path)
    pointer.write_text(json.dumps(data, indent=2) + '\n')
print('Current-v12 original-tolerance failure recorded; no GPU jobs remain active.')

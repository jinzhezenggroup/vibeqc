"""Run all candidate diagnostic groups once, retaining failures and identities."""
import hashlib
import json
import os
import subprocess
import sys
import traceback
from pathlib import Path

assert os.environ.get('SLURM_JOB_ID')
root = Path('.artifacts/issue206-stable-response')
output = root / 'qualification-v2'
output.mkdir(exist_ok=False)
library = (root/'candidate-v2/libvibeqc.so').resolve()
manifest = json.loads((root/'candidate-v2/manifest.json').read_text())
with library.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == manifest['library_sha256']
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str(library), VIBEQC_RESOURCE_CUDA_TEST='1',
                  VIBEQC_DF_DERIVATIVE_CUDA_TEST='1', PYTHONPATH='python:.',
                  OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
                  LD_LIBRARY_PATH=str(library.parent)+':/group/software/cuda-12.9.1/lib64')
commands = [
    ('controls', ['/tmp/vibeqc-308-gpu4pyscf-env/bin/python', str(root/'qualify-candidate-controls-v2.py')]),
    ('native', ['ctest','--test-dir','build/cuda','--output-on-failure','--timeout','120','-R',
                'vibeqc_df_occupied_response_tests']),
    ('practical', ['/tmp/vibeqc-review-env/bin/python','-m','pytest','-q',
                   'tests/python/test_df_practical_response_cuda.py',
                   '--basetemp='+str(output/'practical-tmp'),'--junitxml='+str(output/'practical.xml')]),
]
report = {'scope': __doc__, 'slurm_job_id': os.environ['SLURM_JOB_ID'],
          'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
          'frozen': manifest, 'rows': [], 'status': 'running'}

def save():
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')

save()
try:
    for name, command in commands:
        row = {'name': name, 'command': command, 'status': 'running'}
        report['rows'].append(row)
        save()
        with (output/(name+'.txt')).open('x') as stream:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
        row.update(status='completed', exit_code=result.returncode)
        save()
        print(name, result.returncode, flush=True)
    report['status'] = 'passed' if all(r['exit_code']==0 for r in report['rows']) else 'failed; every group retained'
except Exception:
    report.update(status='failed controller', exception=traceback.format_exc())
    raise
finally:
    save()
sys.exit(0 if report['status']=='passed' else 1)

"""Slurm-only capture of frozen-v14 physical matrices at an unchanged failed D."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

import numpy as np

assert os.environ.get('SLURM_JOB_ID') and 'CUDA_VISIBLE_DEVICES' in os.environ
root = Path('.artifacts/issue206-stable-response')
out = root / 'physical-fock-v1'
out.mkdir(exist_ok=False)
fixture = root / 'physical-fock-input-v1'
reference = json.loads((fixture / 'report.json').read_text())
frozen = json.loads((root / 'candidate-v14/manifest.json').read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


for name, expected in reference['fixture_sha256'].items():
    assert digest(fixture / name) == expected
library = (root / 'candidate-v14/libvibeqc.so').resolve()
assert digest(library) == frozen['library_sha256']
report = {'scope': __doc__, 'status': 'running', 'slurm_job_id': os.environ['SLURM_JOB_ID'],
          'cuda_visible_devices': os.environ['CUDA_VISIBLE_DEVICES'], 'frozen': frozen,
          'fixture_report_sha256': digest(fixture / 'report.json'),
          'input_sha256': {str(p): digest(p) for p in [Path(__file__), root / 'physical_fock_probe_v1.cpp',
                                                     root / 'physical_fock_probe_v1']}}


def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


save()
env = {k: v for k, v in os.environ.items() if not k.startswith('VIBEQC_')}
env.update(LD_LIBRARY_PATH=str((root / 'candidate-v14-loader').resolve()) + ':/group/software/cuda-12.9.1/lib64',
           VIBEQC_DF_TRACE=str(out / 'trace.jsonl'), VIBEQC_DF_EXCHANGE='occupied',
           VIBEQC_DF_VALUE_STORAGE='dense', VIBEQC_DF_RESIDENT_EXCHANGE='auto')
command = [str(root / 'physical_fock_probe_v1'), str(fixture / 'input.txt'), str(out)]
with (out / 'native.txt').open('x') as stream:
    result = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=240)
report['exit_code'] = result.returncode
report['status'] = 'capture completed' if result.returncode == 0 else 'failed capture'
save()
assert result.returncode == 0
records = [json.loads(line) for line in (out / 'native.txt').read_text().splitlines()]
identity = next(r for r in records if r['operation'] == 'identity')
assert identity['source_identity'] == frozen['native_source_identity']
assert Path(identity['library']).resolve() == library
report['native_identity'] = identity
report['diagnostic_resources'] = next(r for r in records if r['operation'] == 'fixed_density_fock')
cpu = np.load(fixture / 'reference.npz', allow_pickle=False)
n, a = reference['nbf'], reference['naux']
report['matrix_differences'] = {}
for name in ('overlap', 'hcore', 'coulomb', 'exchange', 'fock', 'metric', 'density'):
    shape = (a, a) if name == 'metric' else (n, n)
    native = np.fromfile(out / (name + '.bin')).reshape(shape)
    assert np.all(np.isfinite(native))
    report['matrix_differences'][name] = float(np.max(np.abs(native - cpu[name])))
report['output_sha256'] = {p.name: digest(p) for p in out.glob('*.bin')}
report['status'] = 'completed fixed-density capture; no admission or SCF retry'
save()
print(json.dumps(report['matrix_differences'], indent=2), flush=True)

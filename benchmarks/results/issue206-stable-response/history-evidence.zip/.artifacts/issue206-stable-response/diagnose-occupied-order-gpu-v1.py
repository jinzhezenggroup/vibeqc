"""Untimed occupied-factor ordering diagnosis at retained native densities.

Compare raw-projection inverse order, Coulomb consistency, whitened projection,
and inverse-applied AO projection. Each complete force is independently checked
with the unchanged derivative backend. No native SCF or clean timing is replayed.
"""

import hashlib
import json
import os
import traceback
from pathlib import Path

import cupy as cp
import numpy as np
from pyscf import df, gto, scf

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis, native_build_metadata
from tools.vibeqc_validation.df_gradient import execute_df_gradient
from tools.vibeqc_validation.one_electron_gradient import execute_gradient
from vibeqc import Calculator


def maximum(x):
    return float(np.max(np.abs(x)))


def main():
    assert os.environ.get("SLURM_JOB_ID"), "GPU diagnostics require finite Slurm"
    root = Path("/home/jzzeng/codes/vibeqc-issue206-auxiliary/.artifacts/issue206-auxiliary")
    out = Path(".artifacts/issue206-stable-response/occupied-order-gpu-v1")
    out.mkdir(exist_ok=False)
    campaign = json.loads((root / "practical-warm-v1/manifest.json").read_text())
    for key in list(os.environ):
        if key.startswith("VIBEQC_"):
            del os.environ[key]
    os.environ.update(campaign["controls"])
    captured = json.loads((root / "final-density-v1/report.json").read_text())
    reference = {r["case"]: r for r in json.loads((root / "retained-density-reconstruction-v1.json").read_text())["rows"]}
    oracle = {r["case"]: r for r in json.loads((root / "cpu-diagnosis-v1.json").read_text())["rows"]}
    report = {"scope": __doc__, "slurm_job_id": os.environ["SLURM_JOB_ID"],
              "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
              "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "cupy_version": cp.__version__, "rows": [], "status": "running"}

    def save():
        (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    save()
    try:
        for original in captured["rows"]:
            name = original["case"]
            case = benchmark_cases()[name]
            orbital, ob = load_comparison_basis(root / "cc-pvdz.json", case, role="orbital", compute_forces=True)
            auxiliary, ab = load_comparison_basis(root / "cc-pvdz-jkfit.json", case, role="auxiliary", compute_forces=True)
            density_path = root / "final-density-v1" / (name + "-density.npy")
            spin_density = np.load(density_path, allow_pickle=False)
            uhf = case.method == "uhf"
            density = spin_density if uhf else spin_density[0]
            mol = gto.M(atom=case.atoms, unit="Bohr", basis=ob, spin=case.multiplicity - 1, cart=False, charge=case.charge, verbose=0)
            mf = (scf.UHF(mol) if uhf else scf.RHF(mol)).density_fit(auxbasis=ab)
            fock = mf.get_hcore() + mf.get_veff(mol, density)
            metric = mf.with_df.auxmol.intor("int2c2e")
            a = df.incore.aux_e2(mol, mf.with_df.auxmol, aosym="s1")
            n, _, q = a.shape
            if uhf:
                saved = np.load(root / "oh-response-weights-v1/response-arrays.npz", allow_pickle=False)
                # Those factors diagonalize the separately normalized public M.
                # Its agreement with the direct PySCF convention was checked in
                # Slurm9907; retain that small input difference explicitly here.
                values, vectors = cp.asarray(saved["eigenvalues"]), cp.asarray(saved["eigenvectors"])
                eigensystem_source = "exact saved native CUDA factors from Slurm9908"
            else:
                values, vectors = cp.linalg.eigh(cp.asarray(metric))
                eigensystem_source = "CuPy CUDA factorization of independent libcint M"
            eigenvalues = cp.asnumpy(values)
            assert eigenvalues[0] > 1e-10 * eigenvalues[-1], "full-rank identity required"
            ga = cp.asarray(a.reshape(n*n, q))
            gb = ((ga @ vectors) / values) @ vectors.T
            b = gb.reshape(n, n, q)
            # RHF's two identical spin densities each equal D/2. This keeps the
            # same UHF energy functional and explicitly accounts for both spins.
            spins = cp.asarray(spin_density if uhf else np.repeat(spin_density / 2, 2, axis=0))
            total = spins.sum(axis=0)
            inverse_root = (vectors / cp.sqrt(values)) @ vectors.T
            white = (ga @ inverse_root).reshape(n,n,q)
            factors = []
            factor_errors = []
            for d, rank in zip(spins, mol.nelec, strict=True):
                dv, dc = cp.linalg.eigh(d)
                factor = dc[:, -rank:] * cp.sqrt(dv[-rank:]) if rank else cp.empty((n,0))
                factors.append(factor)
                factor_errors.append(float(cp.max(cp.abs(factor @ factor.T - d)).get()))
            for ordering in ('raw_projection_raw_coulomb', 'raw_projection_fitted_coulomb',
                             'white_projection_fitted_coulomb', 'fitted_ao_projection'):
                if ordering == 'raw_projection_raw_coulomb':
                    raw_c = total.reshape(-1) @ ga
                    c = ((raw_c @ vectors) / values) @ vectors.T
                else:
                    c = total.reshape(-1) @ gb
                wa = total[:, :, None] * c
                wm = -0.5 * cp.outer(c,c)
                for factor in factors:
                    rank = factor.shape[1]
                    if not rank:
                        continue
                    source_a = b if ordering == 'fitted_ao_projection' else (
                        white if ordering == 'white_projection_fitted_coulomb' else ga.reshape(n,n,q))
                    projected = (factor.T @ source_a.transpose(2,0,1) @ factor).transpose(1,2,0)
                    flat = projected.reshape(rank*rank,q)
                    if ordering.startswith('raw_projection'):
                        flat = ((flat @ vectors) / values) @ vectors.T
                    elif ordering.startswith('white_projection'):
                        flat = flat @ inverse_root
                    u = flat.reshape(rank,rank,q)
                    wa -= (factor @ u.transpose(2,0,1) @ factor.T).transpose(1,2,0)
                    wm += .5 * flat.T @ flat
                weight_a, weight_m = cp.asnumpy(wa), cp.asnumpy(wm)
                weighted = (density @ fock @ density).sum(axis=0) if uhf else density @ fock @ density / 2
                total_cpu = density.sum(axis=0) if uhf else density
                one_weights = np.array([-weighted, total_cpu, total_cpu])
                orbital_calc = Calculator(device="cuda", basis=orbital, basis_representation="spherical")
                auxiliary_calc = Calculator(device="cuda", basis=auxiliary, basis_representation="spherical")
                identity = native_build_metadata(orbital_calc)
                assert identity["library_sha256"] == campaign["build"]["library_sha256"]
                one, one_resources = execute_gradient(orbital_calc, case.atoms, one_weights, multiplicity=case.multiplicity)
                fitted, fitted_resources = execute_df_gradient(orbital_calc, auxiliary_calc, case.atoms, weight_a, weight_m, multiplicity=case.multiplicity)
                nuclear = mf.nuc_grad_method().grad_nuc()
                force = -(one + fitted + nuclear)
                row = {"case": name, "ordering": ordering, "density_factor_errors": factor_errors, "native_build": identity, "eigensystem_source": eigensystem_source,
                       "density_sha256": hashlib.sha256(density_path.read_bytes()).hexdigest(),
                       "rank": q, "condition": float(eigenvalues[-1]/eigenvalues[0]),
                       "force": force.tolist(), "one_electron_gradient": one.tolist(),
                       "df_gradient": fitted.tolist(), "nuclear_gradient": nuclear.tolist(),
                       "vs_cpu_at_same_density": maximum(force-reference[name]["reconstructed"]["consistent"]["forces"]),
                       "vs_tight_cpu_oracle": maximum(force-oracle[name]["forces_hartree_per_bohr"]),
                       "vs_original_native_endpoint": maximum(force-original["native_forces"]),
                       "one_electron_bridge_resources": one_resources, "df_bridge_resources": fitted_resources,
                       "algebra_resources": "prototype not instrumented; no complete resource or timing claim"}
                np.savez_compressed(out / (name + "-" + ordering + "-weights.npz"), bar_a=weight_a, bar_m=weight_m,
                                    one_weights=one_weights, eigenvalues=eigenvalues, eigenvectors=cp.asnumpy(vectors))
                report["rows"].append(row)
                save()
                print(name, ordering, {k:v for k,v in row.items() if k.startswith("vs_")}, flush=True)
        report["status"] = "completed algebra prototype; original gates and production library unchanged"
    except Exception:
        report["status"] = "failed diagnostic"
        report["exception"] = traceback.format_exc()
        raise
    finally:
        save()


if __name__ == "__main__":
    main()

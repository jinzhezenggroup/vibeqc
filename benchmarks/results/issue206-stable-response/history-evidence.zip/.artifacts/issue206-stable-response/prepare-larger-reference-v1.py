"""Independent CPU-only PySCF references for the predeclared larger/B2 cases.

No Calculator is constructed and no native/GPU probe is called.
"""
import hashlib
import importlib.util
import json
import os
import traceback
from pathlib import Path
from types import SimpleNamespace
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import pyscf
root=Path('.artifacts/issue206-stable-response')
out=root/'larger-reference-v1';out.mkdir(exist_ok=False)
source=Path('tests/python/test_df_practical_response_cuda.py')
assert source.read_bytes()==(root/'candidate-v6/source'/source).read_bytes()
spec=importlib.util.spec_from_file_location('practical_response_test',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
inputs=[source,Path('benchmarks/results/issue206-practical-auxiliary/identity/cc-pvdz.json'),
        Path('benchmarks/results/issue206-practical-auxiliary/identity/cc-pvdz-jkfit.json')]
report={'scope':__doc__,'status':'running','pyscf_version':pyscf.__version__,
        'input_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},'cases':{}}
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
    for key in ('water-octamer-s4-def2-svp-spherical','water-tetramer-def2-svp-spherical'):
        case,orbital,auxiliary,moved,references=module.practical_reference.__wrapped__(SimpleNamespace(param=key))
        report['cases'][key]={'original_geometry':[(s,list(r)) for s,r in case.atoms],
            'changed_geometry':[(s,list(r)) for s,r in moved],
            'references':[{'energy':e,'forces':f.tolist()} for e,f in references]}
        save();print(key,'CPU references complete',flush=True)
    report['status']='completed'
except Exception:
    report.update(status='failed',exception=traceback.format_exc());raise
finally:save()

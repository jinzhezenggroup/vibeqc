"""Audit source-first K qualification without reclassifying earlier failures."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path('.artifacts/issue206-stable-response')
base = root / 'candidate-v10'
frozen = json.loads((base / 'manifest.json').read_text())
for name, digest in frozen['records'].items():
    with (base / name).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == digest, name
directory = root / 'qualification-v10'
report = json.loads((directory / 'report.json').read_text())
assert report['status'] == 'passed'
assert all(r['status'] == 'completed' and r['exit_code'] == 0 for r in report['rows'])
assert 'ERROR SUMMARY: 0 errors' in (directory / 'memcheck.txt').read_text()
tests = {}
for name, expected in [('streamed', 8), ('report', 38)]:
    cases = list(ET.parse(directory / (name + '.xml')).iter('testcase'))
    assert len(cases) == expected
    assert all(all(t.find(tag) is None for tag in ('failure', 'error', 'skipped')) for t in cases)
    tests[name] = len(cases)
practical = json.loads((directory / 'all-sample-audit.json').read_text())
assert practical['completed_endpoints'] == 52
assert practical['failed_or_rejected_endpoints'] == 0
assert practical['maximum_energy_error'] <= 3e-11
assert practical['maximum_force_error'] <= 3e-11
for case in practical['cases']:
    native = case['identity']['native_build']
    assert native['library_sha256'] == frozen['library_sha256']
    assert native['probe']['source_identity'] == frozen['native_source_identity']
rejections = [p for p in (directory / 'tmp').rglob('resource-result.json')
              if not any(x.is_symlink() for x in p.parents)]
assert len(rejections) == 3
assert all(json.loads(p.read_text())['status'] == 7 for p in rejections)
work = []
for path in (directory / 'streamed-tmp').rglob('trace.jsonl'):
    if any(x.is_symlink() for x in path.parents):
        continue
    for line in path.read_text().splitlines():
        event = json.loads(line)
        counts = event.get('counters', {})
        if counts.get('streamed_occupied_source_first') != 1:
            continue
        assert event['valid'] and event['source_backed'] and event['streamed']
        assert event['nbf'] == 96 and event['naux'] == 96 and counts['occupied_rank'] == 20
        blocks = counts['streamed_occupied_row_blocks']
        rows = 96 // blocks
        generated = rows * blocks * (blocks + 1) // 2 if counts['occupied_exchange_triangular'] else 96 * blocks
        assert counts['streamed_occupied_raw_generation_rows'] == generated
        assert counts['raw_panel_source_auxiliary_evaluations'] == generated * 96 * 96
        assert counts['raw_value_bytes'] == generated * 96 * 96 * 8
        assert counts['streamed_occupied_retained_projection_capacity_bytes'] == 2 * rows * 96 * 20 * 8
        work.append({'trace': str(path.relative_to(directory)), 'generated_rows': generated,
                     'equivalent_raw_passes': generated / 96, 'counters': counts})
assert len(work) == 8
output = {
    'scope': __doc__, 'clean_benchmarks': 0,
    'library_sha256': frozen['library_sha256'],
    'native_source_identity': frozen['native_source_identity'],
    'verified_frozen_records': len(frozen['records']),
    'qualification': {'status': report['status'], 'slurm_job_id': report['slurm_job_id'],
                      'python_tests_passed': tests, 'native_memcheck_errors': 0},
    'practical': {k: v for k, v in practical.items() if k not in ('cases', 'tests')},
    'expected_resource_rejections': len(rejections),
    'source_first_work': work,
    'retained_failures': {
        'initial_v10_build': 'Mixed enum/int lambda return inference; explicit return type fixes it. Both build logs retained.',
        'initial_audit_cli': 'Called audit-practical.py with a root-prefixed argument; its internal root duplicated the path and output creation failed. No samples were changed. Corrected invocation uses qualification-v10.',
        'Slurm9936': 'Cancelled before force; zero completed endpoints. This is neither a numerical pass nor a clean timing sample.',
        'original_1e-10': 'First-changed water force approximately3.956e-11 remains failed against3e-11.',
        'Slurm9926': 'Complete-force sanitizer timeout remains not passed.'
    },
    'larger_boundary': 'A separate changed-candidate384MiB diagnostic must complete and establish actual K/response routes before extending numerical coverage.'
}
with (root / 'completed-checkpoint-v4.json').open('x') as stream:
    json.dump(output, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: output[k] for k in ('qualification', 'practical', 'expected_resource_rejections')}, indent=2))

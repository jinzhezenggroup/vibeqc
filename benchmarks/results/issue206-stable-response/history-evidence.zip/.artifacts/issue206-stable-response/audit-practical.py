"""Summarize all persisted endpoints without dropping failures or partial cases."""
import json
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path('.artifacts/issue206-stable-response')
name=sys.argv[1]
report_dir=root/name
results=[]
for f in sorted(report_dir.rglob('results.json')):
    if any(p.is_symlink() for p in f.parents if p != report_dir.parent):
        continue
    rows=json.loads(f.read_text())
    identity=f.parent/'identity.json'
    item={'directory':str(f.parent.relative_to(report_dir)), 'rows':rows,
          'identity':json.loads(identity.read_text()) if identity.exists() else None,
          'response':[]}
    for phase in ('cold','warm','changed','changed_warm'):
        trace=f.parent/(phase+'.jsonl')
        if not trace.exists():continue
        for line in trace.read_text().splitlines():
            d=json.loads(line)
            if d.get('operation')=='force_response':
                item['response'].append({'phase':phase,'valid':d['valid'],
                    'nbf':d['nbf'],'naux':d['naux'],
                    'counters':{k:v for k,v in d['counters'].items() if not k.startswith('shell_')}})
    results.append(item)
all_rows=[r for c in results for r in c['rows']]
completed=[r for r in all_rows if 'energy_error' in r]
failed=[r for r in all_rows if 'energy_error' not in r or r['energy_error']>3e-11 or r['force_error']>3e-11]
tests=[]
xml=report_dir/'practical.xml'
if xml.exists():
    for t in ET.parse(xml).iter('testcase'):
        tests.append({'name':t.attrib['name'], 'passed':t.find('failure') is None and t.find('error') is None})
d={'scope':'Untimed all-sample audit. Original density-tolerance 1e-10 failures remain failed.',
   'case_count':len(results),'completed_endpoints':len(completed),'failed_or_rejected_endpoints':len(failed),
   'maximum_energy_error':max((r['energy_error'] for r in completed),default=None),
   'maximum_force_error':max((r['force_error'] for r in completed),default=None),
   'tests':tests,'cases':results}
(report_dir/'all-sample-audit.json').write_text(json.dumps(d,indent=2)+'\n')
print({k:v for k,v in d.items() if k not in ('cases','tests')})

"""CPU-only decomposition/eigenprovider diagnosis at saved v14 densities.

Compare PySCF Cholesky/eigen metric fitting and generalized/symmetric-overlap
eigenvectors without updating any native density. Every original residual-audit
failure remains failed; alternative arithmetic is diagnostic, not admission.
"""
import hashlib
import json
from pathlib import Path

import numpy as np
import scipy.linalg
from pyscf import df, gto, scf
from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis

root = Path('.artifacts/issue206-stable-response')
out = root / 'larger-v14-oracle-diagnosis'
out.mkdir(exist_ok=False)
audit_path = root / 'larger-v14-residuals/report.json'
audit = json.loads(audit_path.read_text())
assert audit['status'].startswith('failed')
reference_path = root / 'larger-reference-v1/report.json'
reference = json.loads(reference_path.read_text())
key = 'water-octamer-s4-def2-svp-spherical'
case = benchmark_cases()[key]
bases = Path('benchmarks/results/issue206-practical-auxiliary/identity')
_, orbital = load_comparison_basis(bases / 'cc-pvdz.json', case, role='orbital', compute_forces=True)
_, auxiliary = load_comparison_basis(bases / 'cc-pvdz-jkfit.json', case, role='auxiliary', compute_forces=True)
mol = gto.M(atom=reference['cases'][key]['changed_geometry'], basis=orbital, unit='Bohr', verbose=0)
auxmol = df.addons.make_auxmol(mol, auxiliary)
metric = auxmol.intor('int2c2e', hermi=1)
metric_eigenvalues = scipy.linalg.eigvalsh(metric)
overlap = mol.intor('int1e_ovlp', hermi=1)
se, su = scipy.linalg.eigh(overlap)
orthogonalizer = (su / np.sqrt(se)) @ su.T
selected = [r for r in audit['rows'] if r['configuration'] in
            ('octamer-b1-dense-original', 'octamer-b1-dense-tight') and
            r['phase'] in ('changed', 'changed_warm')]
assert len(selected) == 4
report = {
    'scope': __doc__, 'status': 'running',
    'residual_audit_sha256': hashlib.sha256(audit_path.read_bytes()).hexdigest(),
    'predeclared_modes': ['cd', 'eig'],
    'metric_rank_at_native_cutoff': int(np.sum(metric_eigenvalues > metric_eigenvalues[-1] * 1e-10)),
    'metric_condition': float(metric_eigenvalues[-1] / metric_eigenvalues[0]),
    'overlap_condition': float(se[-1] / se[0]), 'rows': [],
}


def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def maximum(array):
    return float(np.max(np.abs(array)))


save()
for mode in report['predeclared_modes']:
    model = scf.RHF(mol).density_fit(auxbasis=auxiliary)
    model.direct_scf_tol = 1e-14
    model.with_df._cderi = df.incore.cholesky_eri(mol, auxmol=auxmol,
        decompose_j2c=mode, lindep=float(metric_eigenvalues[-1] * 1e-10))
    hcore = model.get_hcore()
    for selected_row in selected:
        state = selected_row['physical']
        input_path = root / 'larger-v14-residuals/states' / f'state{state["state_id"]:03d}.npz'
        assert hashlib.sha256(input_path.read_bytes()).hexdigest() == state['arrays_sha256']
        arrays = np.load(input_path, allow_pickle=False)
        density = arrays['density']
        fock = hcore + model.get_veff(mol, density)
        row = {k: selected_row[k] for k in ('configuration', 'phase', 'index', 'density_tolerance')}
        row.update(metric_decomposition=mode, original_audit_status=selected_row['status'],
                   fock_delta_from_original_audit=maximum(fock - arrays['fock']),
                   commutator=maximum(fock @ density @ overlap - overlap @ density @ fock),
                   projectors={})
        saved_arrays = {'density': density, 'fock': fock, 'overlap': overlap}
        for provider in ('generalized', 'symmetric_overlap'):
            if provider == 'generalized':
                _, coeff = model.eig(fock, overlap)
            else:
                _, vectors = scipy.linalg.eigh(orthogonalizer.T @ fock @ orthogonalizer)
                coeff = orthogonalizer @ vectors
            occupied = coeff[:, :mol.nelectron // 2]
            projector = 2 * occupied @ occupied.T
            delta = projector - density
            row['projectors'][provider] = {
                'fixed_point_maximum': maximum(delta),
                'fixed_point_rms': float(np.sqrt(np.mean(delta ** 2))),
                'eigenframe_orthogonality': maximum(coeff.T @ overlap @ coeff - np.eye(mol.nao)),
            }
            saved_arrays[provider + '_projector'] = projector
        report['rows'].append(row)
        np.savez(out / f'{mode}-state{state["state_id"]:03d}.npz', **saved_arrays)
        save()
        print(json.dumps(row), flush=True)
report['status'] = 'completed diagnosis; original residual failures unchanged'
save()

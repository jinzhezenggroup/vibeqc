"""Audit v8/v9 evidence, keeping cancelled and preflight-only attempts separate."""
import difflib
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path('.artifacts/issue206-stable-response')
output={'scope':__doc__,'clean_benchmarks':0,'frozen':{},'reports':{}}
for version in ('v8','v9'):
 base=root/('candidate-'+version);m=json.loads((base/'manifest.json').read_text())
 for name,digest in m['records'].items():
  with (base/name).open('rb') as stream:
   assert hashlib.file_digest(stream,'sha256').hexdigest()==digest,(version,name)
 output['frozen'][version]={'library_sha256':m['library_sha256'],'native_source_identity':m['native_source_identity'],'verified_file_count':len(m['records'])}
a=json.loads((root/'candidate-v8/manifest.json').read_text());b=json.loads((root/'candidate-v9/manifest.json').read_text())
changed=[name for name in a['records'] if name.startswith('source/src/') and a['records'][name]!=b['records'][name]]
assert set(changed)=={'source/src/scf/cuda/df_response_weights.cu','source/src/scf/cuda_df_gradient.hpp'}
output['v8_to_v9_native_diffs']={name:''.join(difflib.unified_diff((root/'candidate-v8'/name).read_text().splitlines(True),(root/'candidate-v9'/name).read_text().splitlines(True))) for name in changed}
for version in ('v8','v9'):
 directory=root/('qualification-'+version)
 report=json.loads((directory/'report.json').read_text())
 assert all(row['status']=='completed' for row in report['rows'])
 cases=list(ET.parse(directory/'report.xml').iter('testcase'))
 assert all(t.find('failure') is None and t.find('error') is None and t.find('skipped') is None for t in cases)
 output['reports']['qualification-'+version]={'status':report['status'],'slurm_job_id':report['slurm_job_id'],'python_passed':len(cases),'command_results':[{k:row[k] for k in ('name','status','exit_code')} for row in report['rows']]}
assert output['reports']['qualification-v8']['python_passed']==61
assert output['reports']['qualification-v9']['status']=='passed'
assert 'ERROR SUMMARY: 0 errors' in (root/'qualification-v8/memcheck.txt').read_text()
practical=json.loads((root/'qualification-v8/all-sample-audit.json').read_text())
assert practical['completed_endpoints']==52 and practical['failed_or_rejected_endpoints']==0
assert practical['maximum_energy_error']<=3e-11 and practical['maximum_force_error']<=3e-11
for c in practical['cases']:
 native=c['identity']['native_build']
 assert native['library_sha256']==a['library_sha256'] and native['probe']['source_identity']==a['native_source_identity']
output['v8_practical']={k:v for k,v in practical.items() if k not in ('cases','tests')}
rejections=list((root/'qualification-v8/tmp').rglob('resource-result.json'))
assert len(rejections)==3 and all(json.loads(p.read_text())['status']==7 for p in rejections)
output['v8_resource_rejections']=3
literal_panels=0
for path in (root/'qualification-v9/tmp').rglob('*.jsonl'):
 if path.is_symlink() or any(p.is_symlink() for p in path.parents):continue
 for line in path.read_text().splitlines():
  record=json.loads(line)
  c=record.get('counters',{})
  if c.get('response_dense_weight_panel_elements',0):
   assert c['response_dense_weight_panel_elements']==c['response_pseudo_density_capacity_elements']
   literal_panels+=1
assert literal_panels>0
output['v9_literal_dense_panel_records']=literal_panels
cancelled=json.loads((root/'streamed-occupied-v3/report.json').read_text())
assert cancelled['srun_exit_code']==143 and cancelled['not_started_settings']==['octamer-total512']
assert not list((root/'streamed-occupied-v3').rglob('results.json'))
output['incomplete_molecular_boundary']={'status':cancelled['status'],'completed_force_endpoints':0,'not_started_settings':cancelled['not_started_settings'],'decision':json.loads((root/'streamed-occupied-stop-v1.json').read_text())}
output['earlier_failures']={'Slurm9934':'two invalid mixed public/private budget requests, before force; qualification-v8 overall remains failed','Slurm9935':'reference source preflight mismatch, before force; frozen historical source verification corrected','original_1e-10':'first-changed water force approximately3.956e-11 remains failed against3e-11','Slurm9926':'complete-force sanitizer timeout remains not passed'}
with (root/'completed-checkpoint-v3.json').open('x') as f:json.dump(output,f,indent=2);f.write('\n')
print({k:v for k,v in output.items() if k in ('reports','v8_practical','v8_resource_rejections','v9_literal_dense_panel_records')})

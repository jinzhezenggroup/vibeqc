"""CPU-only independent residual audit of every completed v14 larger endpoint.

Reconstruct physical F[D] with PySCF/libcint at each saved native density,
without an SCF rerun or density correction. Apply the originally declared
commutator and fixed-point density gates, plus the unchanged energy gate.
Cache only byte-identical density/geometry inputs; retain an audit row for
every batch item and phase. No native Calculator or GPU context is created.
"""
import hashlib
import json
import os
import traceback
from collections import defaultdict
from pathlib import Path

import numpy as np
import pyscf
from pyscf import gto, scf
from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis

root = Path('.artifacts/issue206-stable-response')
source = root / 'larger-v14'
out = root / 'larger-v14-residuals'
out.mkdir(exist_ok=False)
(out / 'states').mkdir()
native = json.loads((source / 'report.json').read_text())
assert native['status'] != 'running', 'Do not audit changing outputs'
reference_path = root / 'larger-reference-v1/report.json'
reference = json.loads(reference_path.read_text())
basis_root = Path('benchmarks/results/issue206-practical-auxiliary/identity')
report = {
    'scope': __doc__, 'status': 'running', 'pyscf_version': pyscf.__version__,
    'source_native_status': native['status'], 'source_native_slurm_job_id': native['slurm_job_id'],
    'input_sha256': {}, 'rows': [], 'states': [],
    'gates': {'commutator': 'min(1e-8, requested_density_tolerance)',
              'fixed_point_maximum_and_rms': 'min(1e-8, requested_density_tolerance)',
              'physical_energy_error': 3e-11, 'electron_trace': 1e-8, 'idempotency': 1e-8},
    'threads': {k: os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS')},
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


def maximum(array):
    return float(np.max(np.abs(array)))


for path in [source / 'report.json', reference_path, Path(__file__),
             basis_root / 'cc-pvdz.json', basis_root / 'cc-pvdz-jkfit.json']:
    report['input_sha256'][str(path)] = digest(path)
assert digest(reference_path) == native['cpu_reference_report_sha256']
for name, expected in reference['input_sha256'].items():
    path = root / 'candidate-v6/source' / name if name.startswith('tests/') else Path(name)
    assert digest(path) == expected, name
save()
models = {}
cache = {}
try:
    for configuration in native['rows']:
        setting = configuration['settings']
        directory = source / setting['name']
        saved_path = directory / 'results.json'
        if not saved_path.exists():
            continue
        report['input_sha256'][str(saved_path)] = digest(saved_path)
        for endpoint in json.loads(saved_path.read_text()):
            if 'density_sha256' not in endpoint:
                continue
            phase, index = endpoint['phase'], endpoint['index']
            row = {'configuration': setting['name'], 'phase': phase, 'index': index,
                   'density_tolerance': setting['density_tolerance'], 'status': 'running'}
            report['rows'].append(row)
            save()
            try:
                key = setting['case']
                changed = phase.startswith('changed')
                model_key = (key, changed)
                if model_key not in models:
                    case = benchmark_cases()[key]
                    _, orbital = load_comparison_basis(basis_root / 'cc-pvdz.json', case,
                                                       role='orbital', compute_forces=True)
                    _, auxiliary = load_comparison_basis(basis_root / 'cc-pvdz-jkfit.json', case,
                                                         role='auxiliary', compute_forces=True)
                    saved = reference['cases'][key]
                    geometry = saved['changed_geometry' if changed else 'original_geometry']
                    mol = gto.M(atom=geometry, unit='Bohr', basis=orbital,
                                charge=case.charge, spin=case.multiplicity - 1, verbose=0)
                    mf = scf.RHF(mol).density_fit(auxbasis=auxiliary)
                    mf.direct_scf_tol = 1e-14
                    models[model_key] = (mol, mf, mf.get_hcore(), mf.get_ovlp())
                mol, mf, hcore, overlap = models[model_key]
                path = directory / f'{phase}-item{index}-density.npy'
                identity = digest(path)
                assert identity == endpoint['density_sha256']
                report['input_sha256'][str(path)] = identity
                state_key = (model_key, identity)
                if state_key not in cache:
                    density = np.load(path, allow_pickle=False)
                    assert density.shape == (mol.nao, mol.nao)
                    fock = hcore + mf.get_veff(mol, density)
                    eps, coeff = mf.eig(fock, overlap)
                    occupied = coeff[:, :mol.nelectron // 2]
                    projector = 2 * occupied @ occupied.T
                    delta = projector - density
                    energy = float(np.einsum('ij,ji', density, hcore + fock) / 2 + mol.energy_nuc())
                    state_id = len(report['states'])
                    array_path = out / 'states' / f'state{state_id:03d}.npz'
                    np.savez(array_path, density=density, fock=fock, overlap=overlap,
                             hcore=hcore, projector=projector, eigenvalues=eps,
                             physical_weight=density @ fock @ density / 2)
                    physical = {
                        'state_id': state_id, 'case': key, 'changed_geometry': changed,
                        'density_sha256': identity, 'arrays_sha256': digest(array_path),
                        'commutator_maximum': maximum(fock @ density @ overlap - overlap @ density @ fock),
                        'fixed_point_density_maximum': maximum(delta),
                        'fixed_point_density_rms': float(np.sqrt(np.mean(delta ** 2))),
                        'electron_trace_error': abs(float(np.einsum('ij,ji', density, overlap)) - mol.nelectron),
                        'idempotency_error': maximum(density @ overlap @ density - 2 * density),
                        'physical_energy': energy,
                        'physical_energy_error': abs(energy - reference['cases'][key]['references'][int(changed)]['energy']),
                    }
                    report['states'].append(physical)
                    cache[state_key] = physical
                physical = cache[state_key]
                tolerance = min(1e-8, setting['density_tolerance'])
                row.update(physical=physical, gates={
                    'commutator': physical['commutator_maximum'] <= tolerance,
                    'fixed_point_maximum': physical['fixed_point_density_maximum'] <= tolerance,
                    'fixed_point_rms': physical['fixed_point_density_rms'] <= tolerance,
                    'energy': physical['physical_energy_error'] <= 3e-11,
                    'electron_trace': physical['electron_trace_error'] <= 1e-8,
                    'idempotency': physical['idempotency_error'] <= 1e-8,
                })
                row['status'] = 'passed' if all(row['gates'].values()) else 'failed independent gate'
            except Exception:
                row.update(status='failed audit', exception=traceback.format_exc())
            save()
        print(setting['name'], 'audited', flush=True)
    summary = defaultdict(list)
    for row in report['rows']:
        summary[str(row['density_tolerance'])].append(row)
    report['by_request'] = {
        request: {
            'endpoints': len(rows), 'failed_endpoints': sum(r['status'] != 'passed' for r in rows),
            **{name: max(r.get('physical', {}).get(name, float('inf')) for r in rows)
               for name in ('commutator_maximum', 'fixed_point_density_maximum',
                            'fixed_point_density_rms', 'physical_energy_error')},
        }
        for request, rows in summary.items()
    }
    report['status'] = 'passed' if report['rows'] and all(r['status'] == 'passed' for r in report['rows']) else 'failed; every endpoint retained'
except Exception:
    report.update(status='failed controller', exception=traceback.format_exc())
    raise
finally:
    save()
print(json.dumps(report.get('by_request'), indent=2), flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)

"""CUDA whitening-order prototype on exact saved native A/Q/lambda.

No new factorization or SCF. Keep every ordering and its complete fixed-density
energy, including inaccurate results. This is not a performance campaign.
"""
import hashlib
import json
import os
import traceback
from pathlib import Path

import cupy as cp
import numpy as np

assert os.environ.get('SLURM_JOB_ID')
root=Path('.artifacts/issue206-stable-response')
out=root/'forward-order-gpu-v1'
out.mkdir(exist_ok=False)
reference=json.loads((root/'forward-energy-v1/report.json').read_text())
report={'scope':__doc__,'status':'running','rows':[],'slurm_job_id':os.environ['SLURM_JOB_ID'],
    'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'cupy_version':cp.__version__,
    'inputs':{str(Path(__file__)):hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
def save():
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
    for original in reference['rows']:
        phase=original['phase']
        path=root/'forward-energy-v1'/(phase+'-native.npz')
        report['inputs'][str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
        f=np.load(path,allow_pickle=False)
        a,q,l,d=(cp.asarray(f[key]) for key in ('raw','eigenvectors','eigenvalues','density'))
        one=float(np.einsum('ij,ji',f['density'],f['hcore']))+float(f['nuclear'][0])
        projected=a@q
        candidates={
            'project_scale_rotate':(projected/cp.sqrt(l))@q.T,
            'project_scaled_rotation':projected@(q/cp.sqrt(l)).T,
            'scaled_projection_rotate':(a@(q/cp.sqrt(l)))@q.T,
            'explicit_inverse_root':a@((q/cp.sqrt(l))@q.T),
        }
        for label,b in candidates.items():
            c=cp.einsum('ij,ijp->p',d,b)
            db=cp.einsum('ij,jkp->ikp',d,b,optimize=True)
            energy=one+.5*float((c@c).get())-.25*float(cp.einsum('ijp,jip',db,db).get())
            row={'phase':phase,'ordering':label,'energy':energy,
                 'error_vs_cholesky_native_integrals':energy-original['cholesky_native_integrals_energy'],
                 'error_vs_reference_at_same_density':energy-original['cpu_fixed_density_energy']}
            np.savez_compressed(out/(phase+'-'+label+'.npz'),whitened=cp.asnumpy(b))
            report['rows'].append(row)
            save()
            print(row,flush=True)
    report['status']='completed prototype; original gates and failures unchanged'
except Exception:
    report.update(status='failed diagnostic',exception=traceback.format_exc())
    raise
finally:
    save()

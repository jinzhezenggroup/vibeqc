"""Finalize v8/v9 continuation: all jobs ended, molecular streamed coverage incomplete."""
import json
from datetime import datetime, timezone
from pathlib import Path
worktree=Path('/home/jzzeng/codes/vibeqc-issue206-stable-response')
root=worktree/'.artifacts/issue206-stable-response'
p=root/'current-handoff.json'
snapshot=root/'handoff-before-v5.json'
if not snapshot.exists():snapshot.write_bytes(p.read_bytes())
latest=json.loads(p.read_text());latest['observed_at_utc']=datetime.now(timezone.utc).isoformat()
for name in ('streamed-occupied-v3','streamed-occupied-job-v3','qualification-v9'):
 d=json.loads((root/name/'report.json').read_text())
 latest['reports'][name]={k:d[k] for k in ('status','slurm_job_id','rows','not_started_settings') if k in d}
latest['pending_jobs_at_update']={}
latest['completed_evidence_audit']=str(root/'completed-checkpoint-v3.json')
latest['v9_qualification']='Slurm9937: native and46 Python occupied/final-state/final-projection tests pass. Source audit confirms v8->v9 native changes are only the literal panel counter and descriptor docs;64 dense-panel trace records match actual pseudo-density capacity.'
latest['cancelled_streamed_boundary']='Slurm9936 deliberately cancelled before its20-minute limit: octamer384MiB streamed SCF was about110seconds per observed iteration under intrusive diagnostics and never reached force. Zero complete endpoints;512MiB setting not started. Preserve explicit stop decision, partial traces, original running reports and actual exit143 terminal. This is not a timeout, numerical pass or clean timing sample; no unchanged retry admitted.'
latest['stop_decision']=str(root/'streamed-occupied-stop-v1.json')
latest['remaining_boundaries']=['New owned streamed occupied response passes physical native RHF/UHF tests and memcheck, but larger ill-conditioned molecular coverage is still incomplete: Slurm9936 stopped in SCF before force.', 'Only all-occupied-projection retention is implemented; occupied-row blocking and arbitrary/corrected-density strict fallback are not. Forced dense/scalar or insufficient projection capacity keep the old general route.', 'Streamed Coulomb with scratch shorter than Naux and host-streamed compatibility whitening retain their old routes.', 'Original1e-10 first-changed water force remains failed; no complete clean timing or stock GPU4PySCF admission.']
latest['next']=['Address repeated raw-source work in constrained streamed J/K before repeating the costly octamer endpoint. Its cancellation is an incomplete sample and cannot be counted as force qualification.', 'A separately declared fixed-density physical diagnostic may check the projected response arithmetic without another costly SCF, but cannot replace cold/warm/changed endpoint admission.', 'Review the v9 source and scientifically qualify the declared scope before a numerical PR; no candidate commit/push/PR/comment yet.', 'Keep #415 switch; #206 remains open, #427 draft; #409 capacity/crossover separate.']
latest['evidence_manifest']=str(root/'evidence-manifest-v4.json')
p.write_text(json.dumps(latest,indent=2)+'\n')
for work,artifact in [('issue206-auxiliary','issue206-auxiliary'),('issue206-response-diagnosis','issue206-response-diagnosis'),('issue206-post418','issue206-post418'),('issue418-cooperative-rys','issue418'),('issue206-direct-fix','issue206'),('issue409-packed','issue409')]:
 path=Path('/home/jzzeng/codes')/('vibeqc-'+work)/'.artifacts'/artifact/'current-handoff.json'
 data=json.loads(path.read_text());data['latest_stable_response_update']={k:v for k,v in latest.items() if k not in ('latest_frozen_candidate','reports')}
 data['latest_stable_response_update']['authoritative_handoff']=str(p)
 path.write_text(json.dumps(data,indent=2)+'\n')
print('Finalized v9 and all six prior pointers; no running jobs or pending build.')

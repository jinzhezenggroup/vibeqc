"""Audit existing v12 endpoints using executed iterations and cached graphs.

The original controller/status and its erroneous per-phase capture requirement
are preserved. This CPU-only postprocessor independently checks the unchanged
numerical, response, memory and occupied-K work gates; it never reruns a solve.
Graph work is inferred from its captured body and verified one-step readbacks,
not claimed to be a hardware measurement of every replayed kernel.
"""
import argparse
import hashlib
import json
import math
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('output', help='New artifact filename; existing evidence is never overwritten.')
parser.add_argument('--require-complete', action='store_true')
args = parser.parse_args()
root = Path('.artifacts/issue206-stable-response')
output = root / args.output
assert not output.exists(), output
case = root / 'streamed-general-v1/octamer-total384'
frozen = read_json(root / 'candidate-v12/manifest.json')
identity = read_json(case / 'identity.json')
assert identity['native_build']['library_sha256'] == frozen['library_sha256']
assert identity['native_build']['probe']['source_identity'] == frozen['native_source_identity']
assert identity['slurm_job_id'] == '9943'
assert identity['budget'] == 384 << 20
for name, expected in frozen['records'].items():
    if name.startswith('source/src/'):
        assert digest(Path(name.removeprefix('source/')).read_bytes()) == expected, name
with (root / 'candidate-v12/libvibeqc.so').open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == frozen['library_sha256']

source_proof = {}
for name in ('src/scf/cuda/df_rhf_scf.cpp', 'src/scf/cuda/df_scf_state.hpp'):
    live = Path(name).read_bytes()
    committed = subprocess.run(['git', 'show', frozen['git_head'] + ':' + name],
                               check=True, capture_output=True).stdout
    assert live == committed, name
    source_proof[name] = {'sha256': digest(live), 'unchanged_from': frozen['git_head']}

original = read_json(root / 'streamed-general-v1/report.json')
results_bytes = (case / 'results.json').read_bytes()
results = json.loads(results_bytes)
phase_order = ('cold', 'warm', 'changed', 'changed_warm')
assert [r['phase'] for r in results] == list(phase_order[:len(results)])
assert results and len(results) <= 4
if args.require_complete:
    assert len(results) == 4 and original['status'] != 'running'

# A live journal may end mid-write. Only its complete prefix is parsed. Every
# audited completed endpoint must nevertheless have a closed SCF/finalization.
progress = (case / 'progress.jsonl').read_bytes()
prefix = progress[:progress.rfind(b'\n') + 1]
scopes = {}
for line in prefix.splitlines():
    event = json.loads(line)
    sid = event['id']
    if event['event'] == 'BEGIN':
        assert sid not in scopes
        scopes[sid] = {'id': sid, 'parent': event['parent'], 'name': event['name'],
                       'values': {}, 'status': 'open'}
    elif event['event'] == 'VALUE':
        scopes[sid]['values'].setdefault(event['key'], []).append(event['value'])
    elif event['event'] == 'END':
        scopes[sid]['status'] = event['status']
compact = [s for s in scopes.values() if s['name'] == 'compact_rhf_scf']
assert len(compact) >= len(results)


def descendants(scope_id, name):
    selected = []
    for scope in scopes.values():
        if scope['name'] != name:
            continue
        parent = scope['parent']
        while parent in scopes:
            if parent == scope_id:
                selected.append(scope)
                break
            parent = scopes[parent]['parent']
    return selected


def only(items):
    assert len(items) == 1, len(items)
    return items[0]


def value(scope, key):
    return only(scope['values'][key])


audited = []
captured = None
capture_phase = None
for index, result in enumerate(results):
    phase = result['phase']
    reference = original['references'][int(phase.startswith('changed'))]
    energy_error = abs(result['energy'] - reference['energy'])
    assert len(result['forces']) == len(reference['forces']) == 24
    differences = []
    for actual, expected in zip(result['forces'], reference['forces']):
        assert len(actual) == len(expected) == 3
        differences.extend(abs(a - b) for a, b in zip(actual, expected))
    assert all(math.isfinite(v) for v in differences)
    force_error = max(differences)
    assert energy_error == result['energy_error'] <= 3e-11
    assert force_error == result['force_error'] <= 3e-11
    trace_bytes = (case / (phase + '.jsonl')).read_bytes()
    events = [json.loads(line) for line in trace_bytes.splitlines()]
    assert all(e['valid'] for e in events)
    scf = compact[index]
    assert scf['status'] == 'returned'
    readbacks = descendants(scf['id'], 'compact_iteration_readback')
    assert [value(s, 'device_iterations') for s in readbacks] == list(range(1, result['iterations'] + 1))
    assert [value(s, 'converged') for s in readbacks] == [0] * (result['iterations'] - 1) + [1]
    replays = sum(scf['values'].get('host_graph_replay', []))
    assert replays == result['iterations'] - 1
    provenance = only([e for e in events if e['operation'] == 'occupied_scf_provenance'])['counters']
    assert provenance['dense_seed_iterations'] == 1
    assert provenance['factor_seed_iterations'] == 0
    assert provenance['occupied_iterations'] == replays
    assert provenance['validated_density_generations'] == 1
    captures = [e for e in events if e['execution'] == 'graph_capture'
                and e['operation'] in ('ri_j', 'ri_k_occupied')]
    constructions = sum(scf['values'].get('graph_construction_attempt', []))
    if phase in ('cold', 'changed'):
        assert constructions == 1 and len(captures) == 2
        captured, capture_phase = captures, phase
    else:
        assert constructions == 0 and not captures and captured is not None
        assert capture_phase == ('cold' if phase == 'warm' else 'changed')
    k = only([e for e in captured if e['operation'] == 'ri_k_occupied'])
    assert k['streamed'] and k['source_backed']
    expected_k = {
        'streamed_occupied_source_first': 1, 'occupied_rank': 40,
        'streamed_occupied_row_blocks': 9, 'streamed_occupied_raw_generation_rows': 984,
        'raw_panel_source_auxiliary_evaluations': 984 * 192 * 928,
        'streamed_occupied_scratch_capacity_bytes': 4 * 829440 * 8,
    }
    assert all(k['counters'][name] == expected for name, expected in expected_k.items())
    response = only([e for e in events if e['operation'] == 'force_response'])['counters']
    general = response.get('response_streamed_general_factor_first') == 1
    canonical = response.get('response_streamed_occupied_factor_first') == 1
    assert general != canonical
    if general:
        assert response['response_full_rank_bounded_factor_first'] == 1
        assert response['response_streamed_fitting_raw_passes'] == 16
        assert response['raw_tile_productions'] == 640
        assert response['raw_value_bytes'] == 16 * 192 * 192 * 928 * 8
        assert not response.get('response_borrowed_occupied_factor_bytes', 0)
    else:
        assert response['response_streamed_occupied_raw_passes'] == 1
        assert response['raw_tile_productions'] == 928
        assert response['raw_value_bytes'] == 192 * 192 * 928 * 8
        assert response['response_borrowed_occupied_factor_bytes'] == 192 * 40 * 8
    assert response['response_scratch_bytes'] <= 192 << 20
    assert not response.get('response_borrowed_jk_bytes', 0)
    assert not response.get('response_borrowed_whitened_bytes', 0)
    bucket = scopes[scopes[scf['parent']]['parent']]
    assert bucket['name'] == 'run_rhf_density_fitting_cuda_bucket_impl'
    final = only(descendants(bucket['id'], 'finalization'))
    physical = [e for e in events if e['operation'] == 'final_state_physical_fock']
    assert value(final, 'final_fock_evaluations') == len(physical)
    diagnostic = only(descendants(final['id'], 'final_state_corrected')
                      + descendants(final['id'], 'final_state_reuse'))
    assert float(value(diagnostic, 'final_maximum_commutator')) <= 1e-12
    streams = [e for e in events if e['execution'] == 'stream'
               and e['operation'] in ('ri_j', 'ri_k', 'ri_k_occupied', 'force_response')]
    # These scopes are disjoint operators. Do not sum parent finalization timing
    # or capture metadata as additional operator executions.
    work = {key: sum(e['counters'].get(key, 0) for e in streams)
            + replays * sum(e['counters'].get(key, 0) for e in captured)
            for key in ('raw_tile_productions', 'raw_value_bytes')}
    audited.append({
        'phase': phase, 'energy_error': energy_error, 'force_error': force_error,
        'iterations': result['iterations'], 'host_graph_replays': replays,
        'graph_capture_phase': capture_phase, 'graph_constructions': constructions,
        'original_per_phase_capture_gate': 'passed' if constructions else 'failed; cached graph',
        'execution_and_response_audit': 'passed',
        'response_route': 'general' if general else 'canonical',
        'response_scratch_bytes': response['response_scratch_bytes'],
        'response_borrowed_factor_bytes': response.get('response_borrowed_occupied_factor_bytes', 0),
        'response_raw_value_bytes': response['raw_value_bytes'],
        'source_work_stream_plus_verified_replays': work,
        'scf_progress': scf, 'finalization_progress': final, 'final_diagnostic': diagnostic,
        'occupied_provenance': provenance, 'trace_sha256': digest(trace_bytes),
    })
report = {
    'scope': __doc__, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'completed evidence audit' if args.require_complete else 'partial evidence audit',
    'original_controller_status': original['status'], 'source_proof': source_proof,
    'native_source_identity': frozen['native_source_identity'],
    'library_sha256': frozen['library_sha256'], 'results_snapshot_sha256': digest(results_bytes),
    'progress_prefix_bytes': len(prefix), 'progress_prefix_sha256': digest(prefix),
    'phases': audited, 'pending_phases': list(phase_order[len(results):]),
    'limitations': [
        'Density1e-12 diagnostics do not qualify the original1e-10 failed request.',
        'Raw work is generated values, not measured DRAM traffic; source setup outside the selected operators is excluded.',
        'No clean timing or GPU4PySCF superiority admission.',
        'Original failed observer and controller status remain retained.',
    ],
}
with output.open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
for phase in audited:
    print({k: v for k, v in phase.items() if k in (
        'phase', 'force_error', 'host_graph_replays', 'response_route',
        'source_work_stream_plus_verified_replays')})

"""Audit complete v14 larger trajectories and their finalization work.

Bucket resource reports repeat aggregate ownership per item; deduplicate by
bucket rather than summing those copies. Response scratch/borrows are reported
separately and are not an observed whole-process GPU high-water mark. Intrusive
host/component timing is intentionally not summarized as endpoint performance.
"""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

root = Path('.artifacts/issue206-stable-response')
out = root / 'larger-v14'
report = json.loads((out / 'report.json').read_text())
assert report['status'] != 'running'
frozen = json.loads((root / 'candidate-v14/manifest.json').read_text())
rows = []
for configuration in report['rows']:
    setting = configuration['settings']
    directory = out / setting['name']
    identity = json.loads((directory / 'identity.json').read_text())
    assert identity['settings'] == setting
    assert identity['native_build']['library_sha256'] == frozen['library_sha256']
    assert identity['native_build']['probe']['source_identity'] == frozen['native_source_identity']
    results = json.loads((directory / 'results.json').read_text())
    size = setting['batch_size']
    assert len(results) == 4 * size
    for phase in ('cold', 'warm', 'changed', 'changed_warm'):
        samples = [r for r in results if r['phase'] == phase]
        assert [r['index'] for r in samples] == list(range(size))
        assert all(r['energy_error'] <= 3e-11 and r['force_error'] <= 3e-11 for r in samples)
        for sample in samples:
            density = directory / f'{phase}-item{sample["index"]}-density.npy'
            assert hashlib.sha256(density.read_bytes()).hexdigest() == sample['density_sha256']
        work = configuration['phase_work'][phase]
        calls = lambda name: work['exclusive_phases'].get(name, {}).get('calls', 0)
        checks = calls('final_state_fixed_point')
        promotions = calls('final_state_fixed_point_promotion')
        corrections = calls('strict_final_correction')
        solves = work['device_eigensolves_by_reason']['final_fock']['calls']
        assert checks == size + promotions
        assert 0 <= promotions <= corrections
        assert solves == corrections + checks - promotions
        assert calls('final_state_fock_build') == size + corrections
        scopes = list(work['finalization_progress'].values())
        selection = [s for s in scopes if 'final_fock_evaluations' in s]
        accepted = [s for s in scopes if 'final_maximum_fixed_point_density_error' in s]
        assert len(selection) == len(accepted) == size
        for key, value in [('final_fock_evaluations', size + corrections),
                           ('final_eigen_solves', solves), ('final_density_updates', corrections),
                           ('final_fixed_point_checks', checks), ('final_fixed_point_rejections', promotions)]:
            assert sum(s[key] for s in selection) == value, (setting['name'], phase, key)
        assert all(float(s['final_maximum_commutator']) <= setting['density_tolerance'] and
                   float(s['final_maximum_fixed_point_density_error']) <= setting['density_tolerance'] and
                   float(s['final_fixed_point_density_rms']) <= setting['density_tolerance'] for s in accepted)
        events = [json.loads(line) for line in (directory / (phase + '.jsonl')).read_text().splitlines()]
        assert all(e['valid'] for e in events)
        weighted = [e for e in events if e['operation'] == 'final_state_weighted_density']
        assert len(weighted) == size
        assert all(e['counters']['physical_weight_gemms'] == 2 for e in weighted)
        responses = [e for e in events if e['operation'] == 'force_response']
        assert len(responses) == size
        resources = json.loads((directory / (phase + '-resources.json')).read_text())
        buckets = {}
        for resource in resources:
            copy = {k: v for k, v in resource.items() if k != 'system_index'}
            if resource['bucket_id'] in buckets:
                assert buckets[resource['bucket_id']] == copy
            buckets[resource['bucket_id']] = copy
        rows.append({
            'configuration': setting['name'], 'phase': phase, 'batch_size': size,
            'density_tolerance': setting['density_tolerance'],
            'maximum_energy_error': max(r['energy_error'] for r in samples),
            'maximum_force_error': max(r['force_error'] for r in samples),
            'scf_iterations': [r['iterations'] for r in samples],
            'final_provider_solves': solves, 'final_density_corrections': corrections,
            'fixed_point_checks': checks, 'fixed_point_promotions': promotions,
            'final_physical_focks': size + corrections, 'physical_weight_gemms': 2 * size,
            'reported_bucket_resources': list(buckets.values()),
            'response_resources_and_work': [{k: v for k, v in e['counters'].items() if not k.startswith('shell_')}
                                             for e in responses],
        })
assert len(report['rows']) == 12 and sum(r['batch_size'] for r in rows) == 144
groups = defaultdict(list)
for row in rows:
    groups[str(row['density_tolerance'])].append(row)
summary = {}
for request, group in groups.items():
    summary[request] = {
        'endpoints': sum(r['batch_size'] for r in group),
        'maximum_energy_error': max(r['maximum_energy_error'] for r in group),
        'maximum_force_error': max(r['maximum_force_error'] for r in group),
        **{name: sum(r[name] for r in group) for name in
           ('final_provider_solves', 'final_density_corrections', 'fixed_point_checks',
            'fixed_point_promotions', 'final_physical_focks', 'physical_weight_gemms')},
    }
audit = {'scope': __doc__, 'status': 'passed', 'by_request': summary, 'rows': rows}
with (out / 'all-endpoint-ledger-v1.json').open('x') as stream:
    stream.write(json.dumps(audit, indent=2) + '\n')
print(json.dumps(summary, indent=2))

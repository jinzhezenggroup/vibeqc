"""Diagnose the original density1e-10 request on frozen v12, without admission.

Save each current native density, force and physical progress, then reconstruct
independent CPU energy/forces at that exact density. This changed-candidate
probe resolves the current stationarity/Pulay boundary; it does not retry a
failed sample for acceptance or replace any original failed endpoint.
"""
import hashlib
import json
import os
import traceback
from pathlib import Path

import numpy as np
from pyscf import gto, scf

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis, native_build_metadata
from vibeqc import Calculator
from vibeqc.progressive import _retained_density

assert os.environ.get('SLURM_JOB_ID')
root = Path('.artifacts/issue206-stable-response')
out = root/'changed-density-v2'
out.mkdir(exist_ok=False)
frozen = json.loads((root/'candidate-v12/manifest.json').read_text())
for key in list(os.environ):
    if key.startswith('VIBEQC_'):
        del os.environ[key]
os.environ.update(VIBEQC_LIBRARY=str((root/'candidate-v12/libvibeqc.so').resolve()),
    VIBEQC_DF_EXCHANGE='occupied', VIBEQC_DF_VALUE_STORAGE='dense',
    VIBEQC_DF_RESPONSE_STORAGE='panel', VIBEQC_DF_RESPONSE_SPACE='dense',
    VIBEQC_DF_RESPONSE_ALGEBRA='blas', VIBEQC_DF_WEIGHTED_EXECUTION='shell',
    VIBEQC_DF_DERIVATIVE_PAIRS='full', VIBEQC_DF_REFERENCE_FINAL_VALIDATION='0',
    VIBEQC_DF_FORCE_SCREEN_ABS='off',
    VIBEQC_DF_PROGRESS_TRACE=str(out/'progress.jsonl'))
case = benchmark_cases()['water-tetramer-def2-svp-spherical']
identity = Path('benchmarks/results/issue206-practical-auxiliary/identity')
orbital,ob = load_comparison_basis(identity/'cc-pvdz.json',case,role='orbital',compute_forces=True)
auxiliary,ab = load_comparison_basis(identity/'cc-pvdz-jkfit.json',case,role='auxiliary',compute_forces=True)
moved = [(s,np.array(r,dtype=float)) for s,r in case.atoms]
moved[1][1][0] += .001
report = {'scope':__doc__,'status':'running','slurm_job_id':os.environ['SLURM_JOB_ID'],
    'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),
    'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'controls':{k:v for k,v in os.environ.items() if k.startswith('VIBEQC_')},
    'frozen':frozen,'rows':[],'references':[]}

def save():
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')

def maximum(a):
    return float(np.max(np.abs(a)))

save()
try:
    references = []
    for geometry in (case.atoms,moved):
        mol=gto.M(atom=geometry,unit='Bohr',basis=ob,verbose=0)
        mf=scf.RHF(mol).density_fit(auxbasis=ab)
        mf.conv_tol,mf.conv_tol_grad,mf.max_cycle=1e-13,1e-12,200
        mf.direct_scf_tol=1e-14
        mf.kernel()
        assert mf.converged
        grad=mf.nuc_grad_method()
        grad.auxbasis_response=True
        force=-grad.kernel()
        references.append((mol,mf,mf.e_tot,force))
        report['references'].append({'energy':mf.e_tot,'force':force.tolist(),
            'orbital_gradient_norm':float(np.linalg.norm(mf.get_grad(mf.mo_coeff,mf.mo_occ)))})
        save()
    calc=Calculator(method='rhf',basis=orbital,auxiliary_basis=auxiliary,
        basis_representation='spherical',device='cuda',density_fitting='cuda',
        max_iterations=100,energy_tolerance=1e-12,density_tolerance=1e-10,screening_tolerance=1e-14)
    loaded=native_build_metadata(calc)
    report['native_build']=loaded
    assert loaded['library_sha256']==frozen['library_sha256']
    assert loaded['probe']['source_identity']==frozen['native_source_identity']
    save()
    with calc.prepare_batch([case.atoms],warm_start=True) as batch:
        batch.set_warm_start_updates(True)
        for phase,changed in (('cold',False),('warm',False),('changed',True),('changed_warm',True)):
            os.environ['VIBEQC_DF_TRACE']=str(out/(phase+'.jsonl'))
            row={'phase':phase,'status':'running'}
            report['rows'].append(row)
            save()
            item=batch.execute([np.array([r for _,r in moved])] if changed else None,strict=True).items[0]
            density=_retained_density(batch)[0]
            path=out/(phase+'-density.npy')
            np.save(path,density,allow_pickle=False)
            row.update(status='native captured',density_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                native_energy=item.energy,native_force=np.asarray(item.forces).tolist(),
                iterations=item.iterations,density_rms=item.density_rms,energy_change=item.energy_change)
            save()
            mol,mf,energy,force=references[int(changed)]
            h,s=mf.get_hcore(),mf.get_ovlp()
            f=h+mf.get_veff(mol,density)
            physical_energy=float(np.einsum('ij,ji',density,h+f)/2+mol.energy_nuc())
            eps,c=mf.eig(f,s)
            occ=np.zeros_like(eps)
            occ[:mol.nelectron//2]=2
            rebuilt=(c*occ)@c.T
            canonical=(c*(occ*eps))@c.T
            consistent=density@f@density/2
            row.update(electron_error=abs(float(np.einsum('ij,ji',density,s))-mol.nelectron),
                idempotency_error=maximum(density@s@density-2*density),
                commutator=maximum(f@density@s-s@density@f),
                canonical_density_drift=maximum(rebuilt-density),
                physical_energy=physical_energy,native_energy_error=abs(item.energy-energy),
                physical_energy_error=abs(physical_energy-energy),
                native_force_error=maximum(np.asarray(item.forces)-force),reconstructed={})
            save()
            mf.make_rdm1=lambda *args,d=density,**kwargs:d
            grad=mf.nuc_grad_method()
            grad.auxbasis_response=True
            grad._tag_rdm1=lambda dm,*args,**kwargs:np.asarray(dm)
            for label,w in (('canonical',canonical),('consistent',consistent)):
                grad.make_rdm1e=lambda *args,w=w,**kwargs:w
                actual=-grad.kernel(mo_energy=eps,mo_coeff=c,mo_occ=occ)
                row['reconstructed'][label]={'force':actual.tolist(),'vs_native':maximum(actual-item.forces),
                    'vs_oracle':maximum(actual-force)}
                save()
            row['status']='complete'
            save()
            print(phase,{k:row[k] for k in ('native_energy_error','physical_energy_error','native_force_error','commutator')},
                {k:{a:b for a,b in v.items() if a!='force'} for k,v in row['reconstructed'].items()},flush=True)
    report['status']='completed current-v12 stationarity diagnosis; all original gate failures unchanged'
except Exception:
    report.update(status='failed diagnostic',exception=traceback.format_exc())
    raise
finally:
    save()

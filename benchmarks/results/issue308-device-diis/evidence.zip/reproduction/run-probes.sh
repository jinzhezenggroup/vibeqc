#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_DF_VALUE_MAPPING=primitive
runner=/tmp/vibeqc-pr-review-env/bin/python
checkpoint=/tmp/vibeqc-308-large-restored-reference/vibeqc-308-96-atoms-pyscf-forces/scf.chk
reference_forces=/tmp/vibeqc-308-large-restored-reference/vibeqc-308-96-atoms-pyscf-forces/forces.npy
export VIBEQC_DF_DISABLE_DEVICE_DIIS=1
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-device-diis/cold-energy-768-fixed-point --library "$VIBEQC_LIBRARY" --probe .artifacts/df-scf-probe --scf-mode cold --property energy --scf-budget 8589934592 --checkpoint "$checkpoint" --progress --timeout 420
export VIBEQC_DF_DISABLE_DEVICE_DIIS=0
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-device-diis/cold-energy-768-diis --library "$VIBEQC_LIBRARY" --probe .artifacts/df-scf-probe --scf-mode cold --property energy --scf-budget 8589934592 --checkpoint "$checkpoint" --progress --timeout 300
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-device-diis/cold-forces-768-diis --library "$VIBEQC_LIBRARY" --probe .artifacts/df-scf-probe --scf-mode cold --property forces --scf-budget 17179869184 --checkpoint "$checkpoint" --reference-forces "$reference_forces" --progress --timeout 900

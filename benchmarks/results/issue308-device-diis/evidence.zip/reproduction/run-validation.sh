#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1 VIBEQC_DF_VALUE_MAPPING=primitive
runner=/tmp/vibeqc-pr-review-env/bin/python
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
sha256sum "$VIBEQC_LIBRARY"
nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
"$runner" -m pytest -q -rs tests/python/test_df_device_diis_cuda.py tests/python/test_df_force_state_export_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_df_retry_eigen_cuda.py tests/python/test_hf_resources_cuda.py tests/python/test_df_property_budget_cuda.py tests/python/test_df_occupied_cuda.py
build/cuda/vibeqc_density_fitting_tests
build/cuda/vibeqc_df_capture_recovery_tests
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --target-processes all --error-exitcode 86 --log-file "$PWD/.artifacts/issue308-device-diis/sanitizer-%p.log" "$runner" -m pytest -q -rs tests/python/test_df_device_diis_cuda.py -k occupied-4-spherical-uhf

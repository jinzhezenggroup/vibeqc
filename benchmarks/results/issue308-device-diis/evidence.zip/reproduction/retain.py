"""Retain the same-binary cold DIIS ablation, complete forces and prior failures."""
import hashlib
import json
from pathlib import Path
import zipfile
import numpy as np
from benchmarks.df_component_ledger import aggregate_host, read_host_trace

root=Path('.artifacts/issue308-device-diis')
out=Path('benchmarks/results/issue308-device-diis')
out.mkdir(parents=True,exist_ok=True)
sha=lambda x:hashlib.sha256(x).hexdigest()
files={}; runs={}
identity=json.loads((root/'native-identity.json').read_text())
for name in ('cold-energy-768-fixed-point','cold-energy-768-diis','cold-forces-768-diis'):
    run=root/name
    result=json.loads((run/'result.json').read_text())
    assert result['status']!='running'
    assert result['native_source_identity']==identity['native_source_identity']
    assert result['source']['native_library_sha256']==identity['library_sha256']
    for leaf in ('result.json','native.jsonl','cuda.jsonl','progress.jsonl','host.jsonl','stderr.txt','CMakeCache.txt','measured-source.patch'):
        if (run/leaf).exists():files[name+'/'+leaf]=(run/leaf).read_bytes()
    entry={k:result.get(k) for k in ('status','seconds','slurm_job','native_source_identity','native_rows','source','probe_sha256','driver','cuda_runtime_version','input','independent_checks','diagnostic_environment')}
    host=aggregate_host(read_host_trace(run/'host.jsonl'))
    entry['host_components']=host
    entry['progress']={k:result.get('progress',{}).get(k) for k in ('phases','pending')}
    entry['iteration_observations']=[r for r in result.get('progress',{}).get('observations',[]) if r.get('key') in ('device_iterations','converged','seed_generation','compact_dispatch_status','diis_history','compact_solver_workspace_bytes','compact_solver_workspace_allowance')]
    gpu=[int(v.split(',')[1]) for sample in result['memory_samples'] for v in sample['gpu_process_memory']]
    host_peak=[int(v.split()[1])*1024 for sample in result['memory_samples'] for v in sample['host'] if v.startswith('VmHWM:')]
    entry['sampled_process_gpu_peak_mib']=max(gpu,default=None)
    entry['process_host_high_water_bytes']=max(host_peak,default=None)
    if (run/'arrays.bin').exists():
        raw=(run/'arrays.bin').read_bytes();entry['full_array_identity']={'sha256':sha(raw),'bytes':len(raw)}
        values=np.frombuffer(raw,dtype=np.float64);n=768;forces='forces' in name
        assert values.size==(6*n*n+n+288 if forces else 5*n*n+n)
        assert np.isfinite(values).all()
        state=values[:5*n*n].reshape(5,n,n)
        files[name+'/state/first-24-rows-D-S-H-F-C.bin']=state[:,:24].copy().tobytes()
        files[name+'/state/orbital-energies.bin']=values[5*n*n:5*n*n+n].tobytes()
        if forces:
            files[name+'/state/actual-native-W.bin']=values[5*n*n+n:6*n*n+n].tobytes()
            files[name+'/state/full-forces.bin']=values[6*n*n+n:].tobytes()
            entry['full_forces_hartree_per_bohr']=values[6*n*n+n:].reshape(96,3).tolist()
    runs[name]=entry
for p in root.iterdir():
    if p.is_file() and p.suffix in ('.log','.sh','.py','.json'):
        files['reproduction/'+p.name]=p.read_bytes()
for p in (Path('.artifacts/issue308-frozen-device-diis-final')/'source.patch',Path('.artifacts/issue308-frozen-device-diis-final')/'SHA256SUMS',Path('.artifacts/issue308-stage/input-768/input.json')):
    files['reproduction/'+p.name]=p.read_bytes()
for p in Path('.artifacts').glob('issue308-gpu4pyscf-smoke*.log'):
    files['provider-qualification/'+p.name]=p.read_bytes()
for folder in ('issue308-frozen-device-diis-attempt1','issue308-frozen-device-diis-candidate'):
    directory=Path('.artifacts')/folder
    lib=directory/'libvibeqc.so'
    if lib.exists():
        files['prior-attempts/'+folder+'/library.json']=json.dumps({'path':str(lib),'sha256':sha(lib.read_bytes()),'bytes':lib.stat().st_size}).encode()
        files['prior-attempts/'+folder+'/working.patch']=(directory/'working.patch').read_bytes()
files['validation/hooks-final.log']=Path('/tmp/vibeqc-308-device-diis-hooks-final.log').read_bytes()
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert all(z.read(name)==data for name,data in files.items())
summary={'schema':'vibeqc.issue308.device-diis.v1','scope':'Same-library instrumented cold RHF energy ablation and full-force endpoint; includes diagnostic state export and memory sampling. DF allowances are not whole-process budgets. No clean repeated endpoint or GPU4PySCF parity claim.','identity':identity,'runs':runs,'archive':{'path':'evidence.zip','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'restoration':'Every member restored and compared byte-for-byte.'},'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())]}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
policy=Path('benchmarks/evidence-policy.json');p=json.loads(policy.read_text())
p['exceptions'][str(archive)]={'owner':'issue308-device-diis','reason':'Same-binary 768-AO cold DIIS/fixed-point control, complete actual W/forces, physical checks, stage journals, memory/provenance, reconstruction, sanitizer and retained failed attempts.','sha256':summary['archive']['sha256']}
policy.write_text(json.dumps(p,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary['archive']))

"""Interleave frozen generated-response binaries without sharing native state."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--before', type=Path, required=True)
parser.add_argument('--after', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--repeats', type=int, default=5)
args = parser.parse_args()
if not os.environ.get('SLURM_JOB_ID') or not os.environ.get('CUDA_VISIBLE_DEVICES'):
    raise SystemExit('requires scheduler-provided GPU allocation')
args.output.mkdir(exist_ok=False, parents=True)
libraries = {'before': args.before.resolve(), 'after': args.after.resolve()}
report = {'schema':'vibeqc.df_response_panel_ab.v1', 'slurm_job_id':os.environ['SLURM_JOB_ID'],
          'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],
          'libraries':{key:{'path':str(p), 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
                       for key,p in libraries.items()}, 'records':[], 'summary':[]}
counts = {'before':0, 'after':0}
order=[]
while min(counts.values()) < args.repeats:
    for label in ['before','after','after','before']:
        if counts[label] < args.repeats:
            order.append(label); counts[label]+=1
report['order_per_case']=order
for case in ['water-tetramer-def2-svp-spherical','water-octamer-s4-def2-svp-spherical']:
    for index,label in enumerate(order):
        target=args.output/f'{case}-{index}-{label}.json'
        command=[sys.executable, str(args.root/'benchmarks/issue206_df_force_probe.py'),
                 '--case',case,'--repeats','1','--memory-budget-bytes','536870912',
                 '--library',str(libraries[label]),'--output',str(target)]
        completed=subprocess.run(command,cwd=args.root,capture_output=True,text=True)
        target.with_suffix('.log').write_text(completed.stdout+'\n'+completed.stderr)
        if completed.returncode:raise RuntimeError(f'endpoint failed: {command}')
        data=json.loads(target.read_text()); record=data['records'][0]
        report['records'].append({'case':case,'label':label,'command':command,'result':target.name,'record':record})
        (args.output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
        print(case,index,label,record['energy_only']['seconds'],record['energy_plus_force']['seconds'],flush=True)
    selected=[x for x in report['records'] if x['case']==case]
    reference=next(x['record'] for x in selected if x['label']=='before')
    max_e=max_f=0.
    for item in selected:
        r=item['record']
        if r['energy_only']['iterations'] != reference['energy_only']['iterations']:
            raise RuntimeError('before/after SCF iteration branches changed')
        e=abs(r['energy_plus_force']['energy_hartree']-reference['energy_plus_force']['energy_hartree'])
        f=np.max(np.abs(np.asarray(r['energy_plus_force']['forces_hartree_per_bohr'])-
                        reference['energy_plus_force']['forces_hartree_per_bohr']))
        if not np.isfinite(e) or not np.isfinite(f) or e>1e-9 or f>1e-8:
            raise RuntimeError('before/after numerical gate failed')
        max_e=max(max_e,e);max_f=max(max_f,float(f))
    row={'case':case,'max_energy_error_hartree':max_e,'max_force_error_hartree_per_bohr':max_f}
    for label in libraries:
        values=[x['record'] for x in selected if x['label']==label]
        row[label]={key:statistics.median(x[key]['seconds'] for x in values)
                    for key in ['energy_only','energy_plus_force']}
        row[label]['force_increment']=statistics.median(x['force_increment_seconds'] for x in values)
    row['endpoint_speedup']=row['before']['energy_plus_force']/row['after']['energy_plus_force']
    report['summary'].append(row)
report['passed']=True
(args.output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')

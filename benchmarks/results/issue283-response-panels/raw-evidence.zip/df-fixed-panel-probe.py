"""One fixed-density resident/streamed J/K and complete two-electron derivative gate."""
import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument('--root',type=Path,required=True)
parser.add_argument('--library',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--budgets',type=int,nargs='+',default=[536870912,134217728,33554432])
args=parser.parse_args()
assert os.environ.get('SLURM_JOB_ID') and os.environ.get('CUDA_VISIBLE_DEVICES')
sys.path[:0]=[str(args.root/'python'),str(args.root/'benchmarks')]
os.environ['VIBEQC_LIBRARY']=str(args.library)
from _cases import benchmark_cases
from vibeqc.fock import FockPlan,FockBuildSpec
from vibeqc_compiler.dft import NativeAO
case=benchmark_cases()['water-octamer-s4-def2-svp-spherical']
report={'slurm_job_id':os.environ['SLURM_JOB_ID'],'library_sha256':hashlib.sha256(args.library.read_bytes()).hexdigest(),'records':[],'scope':'fixed symmetric density; complete two-electron derivative only, not total SCF force'}
args.output.parent.mkdir(parents=True,exist_ok=True)
with NativeAO(case.atoms,basis=case.vibeqc_basis,representation=case.basis_representation) as basis:
    n=basis.nao
    rng=np.random.default_rng(282)
    factors=rng.normal(size=(n,40))/n
    density=factors@factors.T
    report['nbf']=n
    report['density']=density.tolist()
    spec=FockBuildSpec.hf(coulomb='density_fitted',exchange='density_fitted')
    for budget in args.budgets:
        trace=args.output.with_name(args.output.stem+'-'+str(budget)+'.jsonl')
        assert not trace.exists()
        os.environ['VIBEQC_DF_TRACE']=str(trace)
        start=time.perf_counter()
        with FockPlan(basis,spec,device='cuda',device_budget_bytes=budget) as plan:
            setup=time.perf_counter()-start
            start=time.perf_counter();value=plan.evaluate(density,derivative=True);elapsed=time.perf_counter()-start
            report['records'].append({'budget_bytes':budget,'setup_seconds':setup,'jk_and_two_electron_gradient_seconds':elapsed,'diagnostics':plan.diagnostics,'energy':value.energy,'coulomb':value.coulomb.tolist(),'exchange':value.exchange.tolist(),'gradient':value.gradient.tolist(),'trace':str(trace)})
            args.output.write_text(json.dumps(report,indent=2)+'\n')
            print(budget,setup,elapsed,flush=True)
        os.environ.pop('VIBEQC_DF_TRACE')
    reference=report['records'][0]
    for record in report['records'][1:]:
        record['errors']={key:float(np.max(np.abs(np.asarray(record[key])-reference[key]))) for key in ['coulomb','exchange','gradient']}
        for key,error in record['errors'].items(): assert error<2e-9,(key,error)
    report['passed']=True
args.output.write_text(json.dumps(report,indent=2)+'\n')

"""Retain exact #283 measurements and compact, independently gated summaries."""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

import numpy as np

task = Path(__file__).resolve().parent
repo = Path('/home/jzzeng/codes/vibeqc-df-performance')
out = repo / 'benchmarks/results/issue283-response-panels'
out.mkdir(exist_ok=True)
load = lambda p: json.loads(p.read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
ab = load(task / 'df-response-panel-ab-quiet/summary.json')
assert ab['passed']
summary = {k: v for k, v in ab.items() if k != 'records'}
summary['native_checkpoint'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
summary['measurement_scope'] = 'ABBA fresh solves, five pairs per binary per case; no compilation during primary Slurm 9349 measurements'
summary['component_probes'] = []
for label in ['before', 'after']:
    for suffix, index in [('warm-components', 1), ('components', 1)]:
        name = f'df-response-panel-{label}-{suffix}.json'
        r = load(task / name)['records'][index]
        groups = r['energy_plus_force']['components']['groups']
        response = next(g for g in groups if g['operation'] == 'force_response')
        attribution = r['force_attribution']
        assert 0.9 <= attribution['named_fraction_of_increment'] <= 1
        summary['component_probes'].append({'label': label, 'file': name, 'case': r['case'], 'repeat': r['repeat'], 'attribution': attribution, 'response': response})
summary['matrix'] = []
for p in sorted((task / 'df-response-panel-matrix').glob('*ao-b*.json')):
    d = load(p)
    errors = {'energies_hartree': 0., 'forces_hartree_per_bohr': 0.}
    pairs = list(zip(d['vibeqc']['warm_samples'], d['gpu4pyscf']['warm_samples'], strict=True))
    assert len(pairs) == 5
    for a, b in pairs:
        assert all(c['converged'] for s in [a, b] for c in s['convergence'])
        for k in errors:
            x, y = np.asarray(a[k]), np.asarray(b[k])
            assert x.shape == y.shape and np.isfinite(x).all() and np.isfinite(y).all()
            errors[k] = max(errors[k], float(np.max(np.abs(x-y))))
    assert errors['energies_hartree'] < 1e-9 and errors['forces_hartree_per_bohr'] < 1e-8
    summary['matrix'].append({'file': p.name, 'all_warm_pairs_pass': True, 'maximum_errors': errors, 'vibeqc_warm_median_seconds': d['vibeqc']['warm_median_seconds'], 'gpu4pyscf_warm_median_seconds': d['gpu4pyscf']['warm_median_seconds'], 'gate': d['gate'], 'memory': d['environment'].get('density_fitting_metric_diagnostics')})
fixed = load(task / 'df-response-panel-fixed.json')
assert fixed['passed']
summary['fixed_density'] = [{k:v for k,v in r.items() if k not in ['coulomb','exchange','gradient']} for r in fixed['records']]
summary['limitations'] = [
    'The first 96-AO component pair includes asymmetric initialization and overattributes the wall increment; retained, excluded from coverage claims. Warmed second pairs attribute 98.84%/98.89%.',
    'The earlier ABBA Slurm 9346 overlapped compilation; retained as preview only.',
    'Cross-engine SCF branches differ; no iteration-matched GPU4PySCF speed claim.',
    'Value-plan device peaks exclude force staging and opaque library retention; 1 GiB is a declared sub-budget, not a measured global peak.',
    'Low-memory fixed-density result is J/K plus complete E2 gradient, not total SCF force.',
    'No reconstruction of raw three-center values from rank-truncated transformed tensors.'
]
summary['validation'] = {'cuda_native_suites': 4, 'gpu_resource_and_derivative_tests': 51, 'host_and_ownership_tests': 13, 'memcheck_errors': 0, 'hooks': 'pass'}
files = []
for p in sorted(task.glob('df-response-panel*')):
    if p.is_dir():
        files.extend(f for f in sorted(p.rglob('*')) if f.is_file() and not f.name.endswith('.so'))
    elif p.is_file():
        files.append(p)
files += [task / 'df-fixed-panel-probe.py']
files += [task / 'df-streamed-preparation-runtime' / f for f in ['optimization.patch','CMakeCache.txt']]
payloads = {str(f.relative_to(task)): f.read_bytes() for f in files}
payloads['measured-matrix-driver.patch'] = subprocess.check_output(['git','diff','--','benchmarks/issue206_df_matrix.py'], cwd=repo)
payloads['archive-response-panel.py'] = Path(__file__).read_bytes()
archive = out / 'raw-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payloads.items()):
        info=zipfile.ZipInfo(name, (2026,9,13,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,data,compresslevel=9)
manifest={'schema':'vibeqc.evidence-archive.v1','archive_sha256':sha(archive.read_bytes()),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(payloads.items())]}
(out/'raw-evidence.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
summary['archive']={'files':len(payloads),'original_bytes':sum(map(len,payloads.values())),'bytes':archive.stat().st_size,'sha256':manifest['archive_sha256']}
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
policy_path=repo/'benchmarks/evidence-policy.json'
policy=load(policy_path)
if archive.stat().st_size > policy['review_size_bytes']:
    policy['exceptions'][str(archive.relative_to(repo))]={'owner':'issue283-response-panels','reason':'Exact compressed resident/streamed J/K and E2-gradient parity arrays, ABBA endpoints, component traces and full matrix; all members independently hash-verified and byte-restored.','sha256':manifest['archive_sha256']}
policy_path.write_text(json.dumps(policy,indent=2,sort_keys=True)+'\n')
sys.path.insert(0,str(repo))
from tools.unpack_evidence import unpack
restore=task/'df-response-cache-archive-restored'
unpack(out,restore)
assert all((restore/n).read_bytes()==b for n,b in payloads.items())
print(json.dumps(summary['archive']))

"""Archive completed diagnostic attempts and independent references verbatim."""
from pathlib import Path
import hashlib
import json
import statistics
import zipfile

repo = Path('/home/jzzeng/codes/vibeqc-issue-308-large-evidence')
out = repo / 'benchmarks/results/issue308-large-diagnostics'
out.mkdir(exist_ok=False)
temporary = Path('/tmp')
groups = {'diagnostics': {}, 'qualification': {}, 'reference': {}}


def retain(group, path):
    if path.is_dir():
        for item in sorted(path.rglob('*')):
            if item.is_file() and not item.is_symlink():
                groups[group][path.name + '/' + str(item.relative_to(path))] = item.read_bytes()
    elif path.is_file():
        groups[group][path.name] = path.read_bytes()


for item in sorted(temporary.iterdir()):
    if item.name.startswith(('vibeqc-308-96-atoms-resident', 'vibeqc-308-source-scaling', 'vibeqc-308-source-ncu')):
        if item.is_file() and item.suffix == '':
            continue  # Probe binaries are reproducible from retained source and hashes.
        retain('diagnostics', item)
    if item.name.startswith('vibeqc-308-96-atoms-pyscf'):
        retain('reference', item)
    if item.name.startswith(('vibeqc-310-independent-tight-', 'vibeqc-310-independent-seed-', 'vibeqc-310-iterative-')):
        if item.name.endswith(('commit.txt', 'pr-body.md')):
            continue
        retain('qualification', item)
retain('diagnostics', temporary / 'vibeqc-308-source-resources.txt')
for item in (temporary / 'vibeqc-310-independent-failed-retained').iterdir():
    if item.is_file():
        groups['qualification']['earlier-failure-9513/' + item.name] = item.read_bytes()
retain('diagnostics', Path(__file__))

digest = lambda data: hashlib.sha256(data).hexdigest()
archives = {}
for group, files in groups.items():
    archive = out / (group + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, data in sorted(files.items()):
            zipped.writestr(name, data)
    restored = temporary / ('vibeqc-308-large-restored-' + group)
    restored.mkdir(exist_ok=False)
    with zipfile.ZipFile(archive) as zipped:
        zipped.extractall(restored)
    for name, data in files.items():
        assert (restored / name).read_bytes() == data
    archives[group] = {
        'path': archive.name, 'bytes': archive.stat().st_size,
        'sha256': digest(archive.read_bytes()), 'members': len(files),
        'restoration': 'Every member was restored and compared byte-for-byte.',
        'files': [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(files.items())],
    }

force_reference = json.loads(groups['reference']['vibeqc-308-96-atoms-pyscf-forces/result.json'])
energy_reference = json.loads(groups['reference']['vibeqc-308-96-atoms-pyscf-energy/result.json'])
scaling = json.loads(groups['diagnostics']['vibeqc-308-source-scaling/summary.json'])
assert force_reference['status'] == 'passed' and force_reference['converged']
assert '142 passed' in groups['qualification']['vibeqc-310-independent-tight-gpu-python.log'].decode()
assert '12 passed' in groups['qualification']['vibeqc-310-iterative-gpu-retry.log'].decode()
for name in ('vibeqc-310-independent-tight-memcheck.log', 'vibeqc-310-iterative-memcheck.log'):
    assert 'ERROR SUMMARY: 0 errors' in groups['qualification'][name].decode()

manifest = {
    'schema': 'vibeqc.issue308.large-diagnostics.v1',
    'scope': '96-atom diagnostic failures, independent PySCF energy/full forces, fixed-work source scaling, and completed provider qualification. No converged VibeQC 96-atom endpoint.',
    'case': {'name': 'water-32mer-4s4-def2-svp-spherical', 'atoms': 96, 'public_aos': 768, 'cartesian_aos': 800, 'orbital_basis': 'def2-svp', 'auxiliary_basis': 'def2-svp', 'geometry': 'Synthetic 2x2 array of translated WATER27 S4 octamers, not an optimized 32-mer.'},
    'attempts': [
        {'job': 9521, 'status': 'terminated_diagnostic', 'scope': '28-GiB DF budget, GPU process allocation approximately 14680 MiB; no cold energy endpoint after more than 15 minutes. Earlier passing capture qualification in this allocation is retained in #325.'},
        {'job': 9526, 'status': 'timed_out_diagnostic', 'scope': '100-second resident follow-up; 30/60-second stacks wait for resident three-center materialization, before SCF. Requested CUDA trace file was absent because the first traced operation did not complete.'},
        {'job': 9529, 'status': 'completed_diagnostic', 'scope': 'Fixed 24-by-24 raw source outputs in 24/192/768-AO systems; all values are bit-identical within each mapping. Default median 5.676801/5.7240365/5.8806915 ms; no molecular timing extrapolation.'},
        {'job': 9530, 'status': 'failed_profiler', 'scope': 'NVIDIA performance counter access denied with ERR_NVGPUCTRPERM; no hardware counter data obtained.'},
    ],
    'independent_reference': {'engine': 'PySCF 2.14.0', 'energy_hartree': force_reference['energy'], 'auxbasis_response': True, 'maximum_net_force': force_reference['maximum_net_force'], 'scope': 'Physical reference only; CPU timings are not matched GPU performance measurements. Both complete independent SCF logs and the force reference checkpoint, density, overlap and forces are retained.'},
    'qualification': {
        'independent_fock': {'pr': 323, 'source_commit': 'dd138793e28ca4c3cda53df1e79c2695917a2284', 'job': 9527, 'native_cuda': 5, 'mixed_uhf': 4, 'python_cuda': 142, 'memcheck_cases': 3, 'prior_failures': '9513 failed 12 of 13 checks before fixture/provider repairs; 9518 passed 11 and failed two spherical mixed-UHF density comparisons. Tightening both comparison owners to density convergence 1e-12 resolved the latter without changing comparison thresholds.'},
        'host_diis_retry': {'pr': 326, 'source_commit': '6c5dc9b915b519aba937eac698589028fcd7fb07', 'job': 9528, 'native_cuda': 5, 'python_cuda': 57, 'forced_retry_cases': 12, 'memcheck_cases': 2, 'provenance': 'Tests ran on the uncommitted source later committed unchanged; retained native identity and library SHA identify the exact tested source. Failure-limit tests deliberately exhaust one iteration and do not count as molecular convergence.'},
    },
    'limitations': [
        'Original interrupted result.json files remain byte-identical and may say running; this manifest and interruption records supply terminal dispositions.',
        'Host work, traces and debugger stops make large timings diagnostic. Fixed small-tile tests cannot establish large-tile occupancy or end-to-end parity.',
        'The frozen native source resource report shows 254 value-kernel registers per thread. This alone does not establish register pressure as the performance root cause.',
        'The later register-cap experiment is outside this evidence slice.',
        'No completed VibeQC 96-atom energy or complete force endpoint, GPU4PySCF parity, or closure of #308/#310/#206 is claimed.',
    ],
    'archives': archives,
}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(out / 'README.md').write_text('''# 96-atom preparation diagnostics and independent references

This slice retains completed diagnostics for 32 waters / 96 atoms / 768
spherical AOs with def2-SVP orbital and auxiliary bases. There is still no
converged VibeQC energy or full-force endpoint at this size. The synthetic
geometry is a 2x2 array of translated WATER27 S4 octamers, not an optimized 32-mer.

After the capture repair in #324, the 28-GiB resident plan still did not finish
cold energy after more than 15 minutes (Slurm 9521). The 100-second follow-up
(9526) sampled GPU waiting in resident three-center materialization at both
30 and 60 seconds, before SCF. The GPU stayed near full utilization with about
14.8 GiB allocated. The requested CUDA trace did not appear because its first
operation never completed. These are failed/terminated diagnostics, not endpoints.

Independent PySCF RHF DF energy and complete analytic forces converged with
energy tolerance 1e-12, gradient tolerance 1e-10 and auxiliary-basis response.
The force run energy is -2438.354141054296 Hartree and the maximum net force is
7.05e-13 Hartree/Bohr. Its checkpoint, density, overlap and force arrays are
retained for later physical comparison. CPU timing is not a GPU speed comparison.

Slurm 9529 held the first 24 AO-pair by 24 auxiliary outputs fixed while
growing the surrounding basis from 24 to 192 to 768 AOs. Values are bit-identical
for each mapping. Default primitive-mapping medians were 5.677, 5.724 and
5.881 ms across ten post-priming repeats. Dense zero-coefficient scans add
some cost but do not explain the observed large preparation delay by themselves.
The compiler reports 254 registers per value-kernel thread. Nsight Compute
could not obtain hardware counters (9530: ERR_NVGPUCTRPERM), so that report
alone does not establish an occupancy bottleneck. No source-layout change is
promoted from these diagnostics.

The qualification archive retains #323's passing mixed-UHF/provider/export
checks and #326's host-DIIS retry checks, alongside earlier failures and their
raw traces. Current memchecks report zero errors and zero leaks. The manifest
records exact source/library identities, scopes and counts. All archive members
were restored and compared byte-for-byte; original incomplete result files
remain unchanged. This slice does not close #308, #310 or #206.
''')

policy_path = repo / 'benchmarks/evidence-policy.json'
policy = json.loads(policy_path.read_text())
for group, archive in archives.items():
    if archive['bytes'] > policy['review_size_bytes']:
        relative = str((out / archive['path']).relative_to(repo))
        policy['exceptions'][relative] = {
            'owner': 'issue308-large-diagnostics',
            'reason': 'Byte-verified compressed independent 96-atom PySCF checkpoint and physical density/overlap/force arrays, with exact input scripts and logs, retained to reproduce strict physical comparisons without repeating the expensive SCF oracle.',
            'sha256': archive['sha256'],
        }
policy_path.write_text(json.dumps(policy, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: {key: value for key, value in v.items() if key != 'files'} for k, v in archives.items()}, indent=2))

#!/usr/bin/env bash
set -euo pipefail
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VIBEQC_DF_VALUE_MAPPING=primitive
timeout 180 /group/software/cuda-12.9.1/bin/ncu --target-processes all --set basic --kernel-name 'regex:build_cuda_df_transformed_tile_kernel' --launch-count 1 --export /tmp/vibeqc-308-source-scaling/baseline-primitive-32-profile /tmp/vibeqc-308-source-scaling-probe /tmp/vibeqc-308-source-scaling/water-32.txt /tmp/vibeqc-308-source-scaling/profile-primitive-32 24 24

#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
/tmp/vibeqc-310-xsyev-recovery-probe > /tmp/vibeqc-310-xsyev-recovery-probe.log 2>&1
export VIBEQC_RESOURCE_CUDA_TEST=1
VIBEQC_ONE_ELECTRON_DERIVATIVES=generated ctest --test-dir build/cuda -R 'vibeqc_(df_capture_recovery|df_eigensystem|df_final_snapshot)_tests' --output-on-failure > /tmp/vibeqc-324-gpu-native.log 2>&1
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_setup_eigen_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_df_occupied_cuda.py > /tmp/vibeqc-324-gpu-python.log 2>&1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 build/cuda/vibeqc_df_final_snapshot_tests > /tmp/vibeqc-324-memcheck.log 2>&1
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/usr/bin/nvidia-smi --query-gpu=name,uuid,driver_version,memory.total --format=csv
/usr/bin/nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader,nounits --loop-ms=200 > /tmp/vibeqc-308-96-atoms-resident-device-memory.csv &
probe_monitor_pid=$!
trap 'kill "$probe_monitor_pid" 2>/dev/null || true' EXIT
/usr/bin/time -v /tmp/vibeqc-pr-review-env/bin/python /tmp/vibeqc-308-96-atoms-resident-probe.py > /tmp/vibeqc-308-96-atoms-resident-probe.log 2>&1
kill "$probe_monitor_pid" 2>/dev/null || true
wait "$probe_monitor_pid" 2>/dev/null || true
trap - EXIT

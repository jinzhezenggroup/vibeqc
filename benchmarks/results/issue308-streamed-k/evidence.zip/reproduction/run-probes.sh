#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_DF_VALUE_MAPPING=primitive
runner=/tmp/vibeqc-pr-review-env/bin/python
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-192 --output .artifacts/issue308-streamed/nominal-192 --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --ao-pairs 8192 --auxiliary-tile 128 --timeout 120
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-192 --output .artifacts/issue308-streamed/planned-192-128m --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --ao-pairs 36864 --auxiliary-tile 94 --timeout 120
"$runner" - <<'PY'
import json,subprocess,os
from pathlib import Path
rows=json.loads(Path('.artifacts/issue308-streamed/shape-plans.json').read_text())
p=next(r for r in rows if r['nbf']==384 and r['budget_bytes']==1<<30)
assert not p['stores_full_three_center']
subprocess.run(['/tmp/vibeqc-pr-review-env/bin/python','-m','benchmarks.issue308_stage_probe','--input','.artifacts/issue308-stage/input-384','--output','.artifacts/issue308-streamed/planned-384-1g','--library',os.environ['VIBEQC_LIBRARY'],'--probe','.artifacts/df-stage-probe','--progress','--ao-pairs',str(p['ao_pair_tile']),'--auxiliary-tile',str(p['auxiliary_tile']),'--timeout','240'],check=True)
PY
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-streamed/nominal-768 --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --ao-pairs 8192 --auxiliary-tile 128 --operation dense --timeout 120
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-streamed/planned-768-8g --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --ao-pairs 589824 --auxiliary-tile 437 --timeout 1500

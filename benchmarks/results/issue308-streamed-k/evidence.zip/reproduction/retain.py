"""Retain completed/incomplete #308 streamed-K evidence without promoting timeouts."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile
import numpy as np

root = Path('.artifacts/issue308-streamed')
out = Path('benchmarks/results/issue308-streamed-k')
out.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
runs = []
for name in ['nominal-192', 'planned-192-128m', 'planned-384-1g', 'nominal-768', 'planned-768-8g']:
    directory = root / name
    result = json.loads((directory / 'result.json').read_text())
    assert result['status'] in ('completed', 'timeout'), result['status']
    assert result['native_source_identity'] == 'a9d959ed2d6aad6070028acdf7270d8a863d2053d99d8387ed728bbc7a404ca0'
    for leaf in ['result.json', 'native.jsonl', 'cuda.jsonl', 'progress.jsonl', 'stderr.txt', 'CMakeCache.txt', 'measured-source.patch']:
        if (directory / leaf).exists():
            files[name + '/' + leaf] = (directory / leaf).read_bytes()
    operations = []
    if (directory / 'cuda.jsonl').exists():
        for line in (directory / 'cuda.jsonl').read_text().splitlines():
            r = json.loads(line)
            if r['execution'] != 'stream' or r['operation'] not in ('ri_j', 'ri_k', 'ri_k_occupied'):
                continue
            count = r['counters'].get('raw_value_bytes', 0) // 8 + r['counters'].get('fused_source_auxiliary_evaluations', 0)
            operations.append({'operation': r['operation'], 'source_evaluations': count,
                               'raw_tensor_passes': count / (r['nbf']**2 * r['naux'])})
    shape = {}
    for r in result.get('progress', {}).get('observations', []):
        if r['name'] in ('ri_k', 'ri_k_occupied') and r['key'] in ('planner_ao_pair_tile', 'planner_auxiliary_tile', 'executed_ao_rows', 'executed_auxiliary_tile', 'executed_raw_auxiliary_tile', 'raw_tensor_passes_per_k'):
            shape[r['key']] = r['value']
    gpu = [int(value.split(',')[1].strip()) for row in result['memory_samples'] for value in row['gpu_process_memory']]
    host = [int(value.split()[1]) * 1024 for row in result['memory_samples'] for value in row['host'] if value.startswith('VmHWM:')]
    summary = {key: result[key] for key in ('status', 'slurm_job', 'seconds', 'native_rows', 'independent_checks', 'source', 'native_source_identity', 'input', 'driver', 'cuda_runtime_version', 'diagnostic_environment')}
    summary.update(run=name, k_shape=shape, completed_source_work=operations,
                   pending=result.get('progress', {}).get('pending', []),
                   sampled_process_gpu_peak_mib=max(gpu) if gpu else None,
                   process_host_high_water_bytes=max(host) if host else None)
    path = directory / 'arrays.bin'
    if path.exists():
        data = path.read_bytes()
        summary['full_array_identity'] = {'sha256': sha(data), 'bytes': len(data),
            'retention': 'Full transient outputs remain local; every component was independently compared. First 24 rows of D/J/dense K/occupied K are retained, with exact input identities and reproduction source.'}
        n = result['input']['nbf']
        arrays = np.frombuffer(data, dtype='<f8').reshape(4, n, n)
        assert np.isfinite(arrays).all()
        files[name + '/first-24-rows-D-J-K-Kocc.bin'] = arrays[:, :24].copy().tobytes()
    runs.append(summary)
for leaf in ('run-probes.sh', 'run-validation.sh', 'shape-plans.json', 'retain.py'):
    files['reproduction/' + leaf] = (root / leaf).read_bytes()
for leaf in ('benchmarks/df_stage_probe.cpp', 'benchmarks/issue308_stage_probe.py'):
    files['reproduction/' + Path(leaf).name] = subprocess.check_output(['git', 'show', 'bd05c51:' + leaf])
files['reproduction/source-from-dfd062b.patch'] = subprocess.check_output(['git', 'diff', '--binary', 'dfd062b', 'bd05c51'])
for n in (96, 192, 384, 768):
    files[f'input-{n}/input.json'] = (Path('.artifacts/issue308-stage') / f'input-{n}/input.json').read_bytes()
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(files.items()): z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert all(z.read(name) == data for name, data in files.items())
summary = {'schema': 'vibeqc.issue308.streamed-k.v1',
    'scope': 'Diagnostic fixed qualified D with component/progress tracing and memory samples. No cold SCF, full forces, global-resource acceptance, or GPU4PySCF parity claim. A timed-out K remains unvalidated.',
    'shape_budget_note': 'Planned layouts were selected by a host shape query with an assumed 1-MiB fixed reservation. The native probe accepts explicit tiles, not a public budget request. Its measured value-plan diagnostics include actual source storage; neither those diagnostics nor sampled process memory are a whole-HF budget acceptance.',
    'implementation_commit': 'bd05c51', 'runs': runs,
    'validation': {'slurm_job': '9549', 'python_gpu': '74 passed, 2 skipped in 123.15s',
                   'native_suites': ['vibeqc_density_fitting_tests', 'vibeqc_df_capture_recovery_tests'],
                   'gpu_log_sha256': sha(Path('/tmp/vibeqc-308-streamed-gpu.log').read_bytes()),
                   'host': '25 shape/resource tests and 97 policy/structure tests (overlapping); all pre-commit checks passed'},
    'archive': {'path': 'evidence.zip', 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'restoration': 'Every member restored and compared byte-for-byte.'},
    'files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())]}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
policy = Path('benchmarks/evidence-policy.json')
contents = json.loads(policy.read_text())
contents['exceptions'][str(archive)] = {'owner': 'issue308-streamed-k', 'reason': 'Exact completed/interrupted work journals, independent component error checks, sampled matrix rows, and reconstruction/input identities from the bounded 192/384/768-AO experiment. Partial evidence remains a timeout, never a passing full K.', 'sha256': summary['archive']['sha256']}
policy.write_text(json.dumps(contents, indent=2, sort_keys=True) + '\n')
print(summary['archive'])

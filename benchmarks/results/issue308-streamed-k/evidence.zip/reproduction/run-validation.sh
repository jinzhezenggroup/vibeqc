#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1 VIBEQC_DF_VALUE_MAPPING=primitive
sha256sum build/cuda/libvibeqc.so.0.1.0
nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_streamed_k_cuda.py tests/python/test_hf_resources_cuda.py tests/python/test_df_property_budget_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_df_occupied_cuda.py tests/python/test_df_retry_eigen_cuda.py tests/python/test_df_execution_trace.py
build/cuda/vibeqc_density_fitting_tests
build/cuda/vibeqc_df_capture_recovery_tests

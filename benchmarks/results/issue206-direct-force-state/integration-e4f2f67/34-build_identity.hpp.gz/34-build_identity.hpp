#ifndef VIBEQC_BUILD_IDENTITY_HPP
#define VIBEQC_BUILD_IDENTITY_HPP

// The CMake input inventory includes native code and codegen/runtime policy.
inline constexpr const char* kVibeqcSourceIdentity = "a38e875ceddc6d5fb12ebd59827897b0d7b1c7a302812de26269a3d3dc4abb4a";
#define VIBEQC_CUDA_FAST_COMPILE 0
#define VIBEQC_TUNING_RELEASE_BUILD 1

#endif

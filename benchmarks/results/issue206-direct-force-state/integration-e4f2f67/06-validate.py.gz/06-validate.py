"""Run independent checks and retain every outcome for one frozen production binary."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
ART = ROOT / '.artifacts/review'
OUT = ART / 'validation'
BUILD = ROOT / 'build/cuda-release-sm120'
SHA = 'e4f2f67fc5bdf6bc661e9dac4b92b1c59116162e'
CPU = '/home/jzzeng/miniconda3/bin/python'
GPU = '/tmp/vibeqc-308-gpu4pyscf-env/bin/python'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def revision():
    return subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()

assert os.environ.get('SLURM_JOB_ID'), 'GPU allocation required'
assert revision() == SHA
assert not subprocess.check_output(['git','status','--porcelain'])
assert f'PRODUCTION_BUILD_COMPLETE source={SHA}' in (ART/'build.log').read_text()
cache=(BUILD/'CMakeCache.txt').read_text()
for value in ('CMAKE_BUILD_TYPE:STRING=Release','VIBEQC_ENABLE_AOT_SHELLS:BOOL=ON','VIBEQC_CUDA_FAST_COMPILE:BOOL=OFF','VIBEQC_AOT_UNIT_MODE:STRING=stable-shards'):
    assert value in cache, value
OUT.mkdir(exist_ok=False)
lib=OUT/'libvibeqc.so'
shutil.copyfile((BUILD/'libvibeqc.so').resolve(),lib)
watched=['benchmarks/real_molecule_gate.py','benchmarks/compare_gpu4pyscf_batch.py','.artifacts/review/qualify-force.py']
manifest={'agent':'ChatGPT','model':'GPT-6 Astra Pro','revision':SHA,'slurm_job_id':os.environ['SLURM_JOB_ID'],'library_sha256':digest(lib),'build_cache_sha256':digest(BUILD/'CMakeCache.txt'),'build_identity':(BUILD/'generated/build_identity.hpp').read_text(),'build_log_sha256':digest(ART/'build.log'),'runner_sha256':digest(__file__),'source_hashes':{p:digest(ROOT/p) for p in watched},'checks':[],'status':'running','historical_failures_unchanged':True}

def save():
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

def run(name,command,env):
    print('START',name,flush=True)
    t=time.monotonic()
    with (OUT/f'{name}.log').open('x') as log:
        proc=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
    item={'name':name,'command':command,'returncode':proc.returncode,'seconds':time.monotonic()-t,'log_sha256':digest(OUT/f'{name}.log')}
    xml=OUT/f'{name}.xml'
    if xml.exists():
        item['tests']=[{'name':t.attrib.get('name'),'seconds':float(t.attrib.get('time',0)),'failed':bool(t.findall('failure') or t.findall('error')),'skipped':bool(t.findall('skipped'))} for t in ET.parse(xml).getroot().iter('testcase')]
    manifest['checks'].append(item)
    save()
    print('DONE',name,proc.returncode,flush=True)
    return item

env={k:v for k,v in os.environ.items() if not k.startswith('VIBEQC_') and k!='CONTRACT_ENGINE'}
env.update(PYTHONPATH='python:.',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VIBEQC_LIBRARY=str(lib),VIBEQC_MP2_CUDA_TEST='1',VIBEQC_RESOURCE_CUDA_TEST='1')
save()
try:
    # Independent checks continue after failures, but failures remain blocking.
    # No passing check or later campaign silently overwrites a native failure.
    run('native-tests',['ctest','--test-dir',str(BUILD),'--output-on-failure','-j','1','--timeout','120','--output-junit',str(OUT/'native-tests.xml')],env)
    run('host-regressions',[CPU,'-m','pytest','-q','tests/python/test_reference_gate_controls.py','tests/python/test_benchmarks.py','tests/python/test_cuda_ownership.py','tests/python/test_scf_structure.py','tests/python/test_rhf_graph_lifetime.py','tests/python/test_restore_retained_evidence.py','tests/python/test_evidence_retention.py','--junitxml',str(OUT/'host-regressions.xml')],env)
    public=run('public-oh',[CPU,'-m','pytest','-q','tests/python/test_direct_force_state_cuda.py','--junitxml',str(OUT/'public-oh.xml')],env)
    acc=run('independent-accuracy',[GPU,str(ART/'qualify-force.py'),'--arm','candidate'],dict(env,VIBEQC_DF_PROGRESS_TRACE=str(OUT/'force-work.jsonl')))
    apath=ART/'accuracy/candidate/report.json'
    report=json.loads(apath.read_text()) if apath.exists() else {}
    manifest['accuracy_status']=report.get('status','missing')
    if apath.exists(): manifest['accuracy_report_sha256']=digest(apath)
    direct_ok=(public['returncode']==0 and len(public.get('tests',[]))==1 and not public['tests'][0]['skipped'] and acc['returncode']==0 and report.get('status')=='passed' and report['native_build']['library_sha256']==manifest['library_sha256'])
    manifest['direct_accuracy_passed']=direct_ok
    save()
    if direct_ok:
        qualification=ROOT/'benchmarks/results/issue206-direct-force-state/reference-qualification/full-fock-diagnostic.json'
        q=json.loads(qualification.read_text())
        assert q['status']=='qualified' and q['qualified_gradient_tolerance']==1e-11 and q['retained_sample_count']==48
        manifest['reference_qualification_sha256']=digest(qualification)
        clean_env={k:v for k,v in env.items() if not k.startswith('VIBEQC_')}
        clean_env['VIBEQC_LIBRARY']=str(lib)
        matrix=run('matrix',[GPU,'benchmarks/real_molecule_gate.py','--density-fitting','none','--repeats','7','--reference-gradient-tolerance','96=1e-11','--reference-full-fock','96','--output-directory',str(OUT/'matrix')],clean_env)
        summary=json.loads((OUT/'matrix/summary.json').read_text())
        manifest['matrix_summary']=summary
        assert len(summary['points'])==4
        for point in summary['points']:
            record=json.loads(Path(point['artifact']).read_text())
            assert len(record['accuracy']['paired_warm_repeats'])==7
            assert record['native_build']['library_sha256']==manifest['library_sha256']
        manifest['matrix_passed']=matrix['returncode']==0 and summary['passed']
    else:
        manifest['matrix_status']='not_run_due_to_failed_direct_accuracy'
    assert revision()==SHA and not subprocess.check_output(['git','status','--porcelain'])
    assert digest(lib)==digest(BUILD/'libvibeqc.so')==manifest['library_sha256']
    assert {p:digest(ROOT/p) for p in watched}==manifest['source_hashes']
    manifest['status']='passed' if all(c['returncode']==0 and not any(t['failed'] or t['skipped'] for t in c.get('tests',[])) for c in manifest['checks']) and manifest.get('matrix_passed') else 'failed'
    save()
    print('COMPLETE',manifest['status'],flush=True)
except BaseException as exc:
    manifest['status']='failed'
    manifest['error']=repr(exc)
    save()
    raise
sys.exit(0 if manifest['status']=='passed' else 2)

import hashlib,json
from pathlib import Path
import xml.etree.ElementTree as ET
art=Path('.artifacts/review')
def read(path):
 return [{'name':t.attrib['name'],'failed':bool(t.findall('failure') or t.findall('error')),'skipped':bool(t.findall('skipped')),'output':t.findtext('system-out','')} for t in ET.parse(path).getroot().iter('testcase')]
a=read(art/'validation/native-tests.xml'); b=read(art/'baseline/native-tests.xml')
af={t['name'] for t in a if t['failed']}; bf={t['name'] for t in b if t['failed']}
d={'agent':'ChatGPT','model':'GPT-6 Astra Pro','candidate_source':'e4f2f67fc5bdf6bc661e9dac4b92b1c59116162e','baseline_source':'f1f1250ef4d6688b1b5bd1e3bb57e5e3075f4d68','candidate_library_sha256':(art/'library.sha256').read_text().split()[0],'baseline_library_sha256':(art/'baseline/library.sha256').read_text().split()[0],'candidate_native_count':len(a),'baseline_native_count':len(b),'candidate_failures':sorted(af),'baseline_failures':sorted(bf),'new_candidate_failures':sorted(af-bf),'removed_failures':sorted(bf-af),'candidate_only_tests':sorted({t['name'] for t in a}-{t['name'] for t in b}),'baseline_public_oh_exit':int((art/'baseline/public-oh-exit.txt').read_text()),'baseline_public_oh':read(art/'baseline/public-oh.xml'),'raw_suites_relabelled':False}
d['failure_outputs']={name:{'candidate':next(t['output'] for t in a if t['name']==name),'baseline':next(t['output'] for t in b if t['name']==name)} for name in af&bf}
d['all_shared_native_results_match']=all(next((x['failed'],x['skipped']) for x in a if x['name']==t['name'])==(t['failed'],t['skipped']) for t in b)
(art/'baseline/comparison.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items() if k not in ('failure_outputs','baseline_public_oh')},indent=2))
assert not d['new_candidate_failures']

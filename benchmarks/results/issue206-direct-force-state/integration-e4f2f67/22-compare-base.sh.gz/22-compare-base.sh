#!/bin/bash
set -euo pipefail
# Agent: ChatGPT
# Model: GPT-6 Astra Pro
ROOT=/home/jzzeng/reviews/chatgpt-427-456-20260919T1506/pr427
cd "$ROOT"
ART="$ROOT/.artifacts/review"
BUILD="$ROOT/build/cuda-release-sm120"
CANDIDATE=e4f2f67fc5bdf6bc661e9dac4b92b1c59116162e
BASE=f1f1250ef4d6688b1b5bd1e3bb57e5e3075f4d68
export PATH=/group/software/cuda-12.9.1/bin:/home/jzzeng/miniconda3/bin:/home/jzzeng/.local/bin:$PATH
export LD_LIBRARY_PATH=/tmp/vibeqc-308-gpu4pyscf-env/lib/python3.13/site-packages/cutensor/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=python:.
test -z "$(squeue -h -j 10215)"
python - <<'PY'
import json
from pathlib import Path
m=json.loads(Path('.artifacts/review/validation/manifest.json').read_text())
assert m['status'] in ('passed','failed')
assert m.get('matrix_summary'), 'Finish and retain the candidate matrix before baseline switching'
PY
test "$(git rev-parse HEAD)" = "$CANDIDATE"
test -z "$(git status --porcelain)"
mkdir -p "$ART/baseline/probe/tests/python" "$ART/baseline/probe/tests/data"
cp tests/python/test_direct_force_state_cuda.py "$ART/baseline/probe/tests/python/"
cp tests/data/direct_force_oh.json "$ART/baseline/probe/tests/data/"
# Copy, not hard-link: baseline compilation must not alter the candidate snapshot.
cp -a "$BUILD" "$ART/candidate-build-snapshot"
restore_candidate() {
  rc=$?
  trap - EXIT
  if test -d "$ART/candidate-build-snapshot"; then
    if test -d "$BUILD"; then mv "$BUILD" "$ART/baseline/build"; fi
    mv "$ART/candidate-build-snapshot" "$BUILD"
  fi
  git -c advice.detachedHead=false switch --detach "$CANDIDATE"
  test -z "$(git status --porcelain)"
  sha256sum -c "$ART/library.sha256"
  exit "$rc"
}
trap restore_candidate EXIT
git -c advice.detachedHead=false switch --detach "$BASE"
cmake --preset cuda-release-sm120 -DCMAKE_CUDA_COMPILER=/group/software/cuda-12.9.1/bin/nvcc -DPython3_EXECUTABLE=/home/jzzeng/miniconda3/bin/python -DVIBEQC_CUDA_COMPILE_JOBS=8 >"$ART/baseline/configure.log" 2>&1
srun --immediate=60 --partition=main --ntasks=1 --cpus-per-task=8 --time=00:15:00 cmake --build --preset cuda-release-sm120 -j 8 >"$ART/baseline/build.log" 2>&1
test "$(git rev-parse HEAD)" = "$BASE"
test -z "$(git status --porcelain)"
sha256sum "$BUILD/libvibeqc.so" >"$ART/baseline/library.sha256"
cp "$BUILD/CMakeCache.txt" "$ART/baseline/CMakeCache.txt"
cp "$BUILD/generated/build_identity.hpp" "$ART/baseline/build_identity.hpp"
export VIBEQC_LIBRARY="$BUILD/libvibeqc.so"
export VIBEQC_MP2_CUDA_TEST=1 VIBEQC_RESOURCE_CUDA_TEST=1
srun --immediate=60 --partition=main --nodes=1 --ntasks=1 --cpus-per-task=8 --gres=gpu:5090:1 --exclusive --time=00:10:00 bash -c '
  set +e
  echo "BASELINE_GPU_JOB=$SLURM_JOB_ID"
  nvidia-smi --query-gpu=name,uuid,driver_version --format=csv
  ctest --test-dir build/cuda-release-sm120 --output-on-failure -j 1 --timeout 120 --output-junit .artifacts/review/baseline/native-tests.xml >.artifacts/review/baseline/native-tests.log 2>&1
  native_rc=$?
  echo "$native_rc" >.artifacts/review/baseline/native-exit.txt
  python -m pytest -q .artifacts/review/baseline/probe/tests/python/test_direct_force_state_cuda.py --junitxml=.artifacts/review/baseline/public-oh.xml >.artifacts/review/baseline/public-oh.log 2>&1
  public_rc=$?
  echo "$public_rc" >.artifacts/review/baseline/public-oh-exit.txt
  echo "BASELINE_NATIVE_EXIT=$native_rc BASELINE_OH_EXIT=$public_rc"
  exit 0
' >"$ART/baseline/gpu-run.log" 2>&1
python - <<'PY'
import hashlib,json
from pathlib import Path
import xml.etree.ElementTree as ET
art=Path('.artifacts/review')
def read(path):
 return [{'name':t.attrib['name'],'failed':bool(t.findall('failure') or t.findall('error')),'skipped':bool(t.findall('skipped')),'output':t.findtext('system-out','')} for t in ET.parse(path).getroot().iter('testcase')]
a=read(art/'validation/native-tests.xml'); b=read(art/'baseline/native-tests.xml')
af={t['name'] for t in a if t['failed']}; bf={t['name'] for t in b if t['failed']}
d={'agent':'ChatGPT','model':'GPT-6 Astra Pro','candidate_source':'e4f2f67fc5bdf6bc661e9dac4b92b1c59116162e','baseline_source':'f1f1250ef4d6688b1b5bd1e3bb57e5e3075f4d68','candidate_library_sha256':(art/'library.sha256').read_text().split()[0],'baseline_library_sha256':(art/'baseline/library.sha256').read_text().split()[0],'candidate_native_count':len(a),'baseline_native_count':len(b),'candidate_failures':sorted(af),'baseline_failures':sorted(bf),'new_candidate_failures':sorted(af-bf),'removed_failures':sorted(bf-af),'candidate_only_tests':sorted({t['name'] for t in a}-{t['name'] for t in b}),'baseline_public_oh_exit':int((art/'baseline/public-oh-exit.txt').read_text()),'baseline_public_oh':read(art/'baseline/public-oh.xml'),'raw_suites_relabelled':False}
d['failure_outputs']={name:{'candidate':next(t['output'] for t in a if t['name']==name),'baseline':next(t['output'] for t in b if t['name']==name)} for name in af&bf}
d['all_shared_native_results_match']=all(next((x['failed'],x['skipped']) for x in a if x['name']==t['name'])==(t['failed'],t['skipped']) for t in b)
(art/'baseline/comparison.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items() if k not in ('failure_outputs','baseline_public_oh')},indent=2))
assert not d['new_candidate_failures']
PY

"""Compare a frozen native arm with independent CPU forces, without timing claims."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np
from pyscf import gto, scf

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import native_build_metadata
from vibeqc import Calculator


def maximum(x):
    return float(np.max(np.abs(x)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=("baseline", "candidate"), required=True)
    args = parser.parse_args()
    assert os.environ.get("SLURM_JOB_ID")
    out = Path(".artifacts/review/accuracy") / args.arm
    out.mkdir(parents=True, exist_ok=False)
    report = {"scope": __doc__, "arm": args.arm, "slurm_job_id": os.environ["SLURM_JOB_ID"],
              "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
              "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "native_controls": {"energy": 1e-12, "density": 1e-10, "screening": 1e-14, "max_iterations": 100},
              "cases": [], "status": "running"}

    def save():
        (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    def oracle(atoms, basis, representation, charge, multiplicity, method):
        mol = gto.M(atom=atoms, unit="Bohr", basis=basis, cart=representation=="cartesian",
                    charge=charge, spin=multiplicity-1, verbose=0)
        mf = scf.UHF(mol) if method == "uhf" else scf.RHF(mol)
        mf.conv_tol, mf.conv_tol_grad, mf.direct_scf_tol, mf.max_cycle = 1e-14, 1e-12, 1e-14, 200
        energy = float(mf.kernel())
        assert mf.converged
        residual = float(np.linalg.norm(mf.get_grad(mf.mo_coeff, mf.mo_occ)))
        assert residual < 1e-11, residual
        return {"energy": energy, "forces": (-mf.nuc_grad_method().kernel()).tolist(),
                "orbital_gradient_norm": residual}

    def run_case(label, atoms, native_basis, cpu_basis, representation, charge, multiplicity,
                 method, references, force_gate, changed=False):
        calc = Calculator(method=method, basis=native_basis, basis_representation=representation,
                          device="cuda", density_fitting="none", max_iterations=100,
                          energy_tolerance=1e-12, density_tolerance=1e-10, screening_tolerance=1e-14)
        report["native_build"] = native_build_metadata(calc)
        row = {"label": label, "method": method, "batch": len(atoms), "force_gate": force_gate,
               "geometries_bohr": atoms, "oracles": references, "samples": []}
        report["cases"].append(row)
        save()

        def sample(phase, result, refs):
            energies = np.array([r["energy"] for r in refs])
            forces = np.array([r["forces"] for r in refs])
            error_e = maximum(result.energies-energies)
            error_f = maximum(np.array([x.forces for x in result.items])-forces)
            item = {"phase": phase, "energies": result.energies.tolist(),
                    "forces": [x.forces.tolist() for x in result.items],
                    "iterations": [x.iterations for x in result.items],
                    "density_rms": [x.density_rms for x in result.items],
                    "maximum_energy_error_vs_cpu": error_e, "maximum_force_error_vs_cpu": error_f,
                    "passes_declared_accuracy_probe": error_e <= 1e-10 and error_f <= force_gate}
            row["samples"].append(item)
            save()
            print(args.arm, label, phase, error_e, error_f, flush=True)

        with calc.prepare_batch(atoms, charges=[charge]*len(atoms), multiplicities=[multiplicity]*len(atoms),
                                warm_start=True) as batch:
            sample("cold", batch.execute(strict=True), references)
            batch.set_warm_start_updates(False)
            batch.execute(strict=True)
            for _ in range(3):
                sample("frozen_warm", batch.execute(strict=True), references)
            if changed:
                moved = [[(z, list(r)) for z, r in geometry] for geometry in atoms]
                for geometry in moved:
                    geometry[-1][1][0] += 0.003
                moved_oracles = [oracle(x, cpu_basis, representation, charge, multiplicity, method) for x in moved]
                row["changed_geometries_bohr"] = moved
                row["changed_oracles"] = moved_oracles
                sample("changed", batch.execute([[r for _, r in x] for x in moved], strict=True), moved_oracles)
            # Property selection must skip the force-specific update. The
            # dedicated native journal records only that added operation.
            trace = Path(os.environ["VIBEQC_DF_PROGRESS_TRACE"])
            size_before = trace.stat().st_size
            energy_only = batch.execute(
                [[r for _, r in x] for x in moved] if changed else None,
                strict=True, properties=("energy",))
            assert all(x.forces is None for x in energy_only.items)
            emitted = [json.loads(line) for line in trace.read_bytes()[size_before:].splitlines()]
            assert not any(x["name"].startswith("direct_force_canonicalization") for x in emitted)
            refs = moved_oracles if changed else references
            eerror = maximum(energy_only.energies - np.array([x["energy"] for x in refs]))
            row["energy_only"] = {"energies": energy_only.energies.tolist(),
                                  "maximum_energy_error_vs_cpu": eerror,
                                  "extra_force_operator_records": 0}
            assert eerror <= 1e-10
            save()

    save()
    opath = Path("/home/jzzeng/codes/vibeqc-issue206-direct-fix/.artifacts/issue206/cpu-force-diagnosis/report.json")
    original_oracles = json.loads(opath.read_text())
    report["retained_oracle_sha256"] = hashlib.sha256(opath.read_bytes()).hexdigest()
    for batch in (1, 4):
        source = Path(f"/home/jzzeng/codes/vibeqc-issue206-direct-fix/.artifacts/issue206/aot-direct-matrix/matrix/water-tetramer-def2-svp-spherical-b{batch}-none.json")
        data = json.loads(source.read_text())
        atoms = [[(x["element"], x["coordinates_bohr"]) for x in g] for g in data["workload"]["geometries"]]
        original = next(x for x in original_oracles["cases"] if x["label"] == f"direct-96-b{batch}")
        assert json.loads(Path(original["original_path"]).read_text())["workload"]["geometries"] == data["workload"]["geometries"]
        run_case(f"direct-96-b{batch}", atoms, "def2-svp", "def2-svp", "spherical", 0, 1,
                 "rhf", original["oracles"], 3e-11)

    for label, method, charge, multiplicity, geometry, basis, representation, batch in (
        ("h2-sto3g", "rhf", 0, 1, [("H", [0, 0, -0.7]), ("H", [0, 0, 0.7])], "sto-3g", "cartesian", 2),
        ("h2plus-sto3g", "uhf", 1, 2, [("H", [0, 0, -0.7]), ("H", [0, 0, 0.7])], "sto-3g", "cartesian", 2),
        ("oh-svp-spherical", "uhf", 0, 2, benchmark_cases()["oh-def2-svp-spherical-uhf"].atoms, "def2-svp", "spherical", 4),
    ):
        atoms = [[(z, [v*(1+0.002*i) for v in r]) for z, r in geometry] for i in range(batch)]
        # The named native and PySCF STO-3G tables differ in coefficient digits.
        # Use the existing exact shared fixture, preserving the original gate.
        common = benchmark_cases()["h2plus-uhf2"]
        native_basis = common.vibeqc_basis if basis == "sto-3g" else basis
        cpu_basis = common.pyscf_basis if basis == "sto-3g" else basis
        references = [oracle(x, cpu_basis, representation, charge, multiplicity, method) for x in atoms]
        run_case(label, atoms, native_basis, cpu_basis, representation, charge, multiplicity, method, references, 1e-9, changed=True)
    report["status"] = "passed" if all(x["passes_declared_accuracy_probe"] for r in report["cases"] for x in r["samples"]) else "failed"
    save()
    print(args.arm, report["status"], flush=True)
    # A failed baseline is scientifically expected. Preserve the result without
    # aborting a coordinator before it can run and retain the candidate arm.


if __name__ == "__main__":
    main()

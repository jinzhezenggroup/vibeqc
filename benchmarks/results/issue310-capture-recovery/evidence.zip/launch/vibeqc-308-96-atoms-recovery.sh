#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
build/cuda/vibeqc_df_capture_recovery_tests > /tmp/vibeqc-310-large-capture-recovery-test-v2.log 2>&1
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/usr/bin/nvidia-smi --query-gpu=name,uuid,driver_version,memory.total --format=csv
/usr/bin/nvidia-smi --query-compute-apps=pid,used_memory --format=csv,noheader,nounits --loop-ms=200 > /tmp/vibeqc-308-96-atoms-recovery-device-memory.csv &
probe_monitor_pid=$!
trap 'kill "$probe_monitor_pid" 2>/dev/null || true' EXIT
/usr/bin/time -v /tmp/vibeqc-pr-review-env/bin/python /tmp/vibeqc-308-96-atoms-recovery-probe.py > /tmp/vibeqc-308-96-atoms-recovery-probe.log 2>&1
kill "$probe_monitor_pid" 2>/dev/null || true
wait "$probe_monitor_pid" 2>/dev/null || true
trap - EXIT

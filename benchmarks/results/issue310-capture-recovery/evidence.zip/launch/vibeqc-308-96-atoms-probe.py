"""Larger physical endpoint probe; memory observation makes timings diagnostic."""
from pathlib import Path
import ctypes,hashlib,json,os,resource,subprocess,time,traceback
import numpy as np
from pyscf import gto
from vibeqc import Calculator
from vibeqc.autotune import source_identity
from benchmarks._cases import benchmark_cases
from benchmarks.df_component_ledger import read_host_trace,aggregate_host
root=Path('/tmp/vibeqc-308-96-atoms');root.mkdir(exist_ok=False)
case=benchmark_cases()['water-32mer-4s4-def2-svp-spherical']
mol=gto.M(atom=case.atoms,basis=case.pyscf_basis,unit='Bohr',cart=False,verbose=0)
assert mol.natm==96 and mol.nao_nr()==768
lib=Path(os.environ['VIBEQC_LIBRARY']);native=ctypes.CDLL(str(lib));native.vibeqc_get_source_identity.restype=ctypes.c_char_p
assert native.vibeqc_get_source_identity().decode()==source_identity(Path.cwd())
payload={'schema':'vibeqc.issue308.large-endpoint.v1','case':'water-32mer-4s4-def2-svp-spherical','geometry_kind':'synthetic 2x2 array of translated WATER27 S4 octamers, not an optimized 32-mer','atoms':mol.natm,'ao_count':mol.nao_nr(),'auxiliary_basis':case.pyscf_basis,'df_budget_bytes':1<<30,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_identity':source_identity(Path.cwd()),'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'slurm_job':os.environ['SLURM_JOB_ID'],'pid':os.getpid(),'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'steps':[],'status':'running','timing_scope':'diagnostic only: host tracing and process GPU-memory sampling are active'}
(root/'geometry.json').write_text(json.dumps(case.atoms,indent=2)+'\n')
def save():
 payload['process_peak_host_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
 (root/'result.json').write_text(json.dumps(payload,indent=2)+'\n')
save()
try:
 calc=Calculator(method='rhf',device='cuda',density_fitting='cuda',basis=case.vibeqc_basis,basis_representation=case.basis_representation,auxiliary_basis=case.vibeqc_basis,density_fitting_memory_budget_bytes=1<<30,max_iterations=100,energy_tolerance=1e-12,density_tolerance=1e-10,screening_tolerance=1e-12)
 with calc.prepare_batch([case.atoms]) as batch:
  cold=None;warm_force=None
  moved=np.array([r for _,r in case.atoms]);moved[-1,0]+=.01
  for name,properties,coordinates,forced in (
   ('cold-energy',('energy',),None,False),
   ('warm-energy',('energy',),None,False),
   ('warm-forces',('energy','forces'),None,False),
   ('forced-warm-forces',('energy','forces'),None,True),
   ('changed-forces',('energy','forces'),[moved],False),
  ):
   payload['active_step']=name;save();print('START',name,flush=True)
   path=root/(name+'.host.jsonl');os.environ['VIBEQC_DF_HOST_TRACE']=str(path)
   os.environ['VIBEQC_DF_FORCE_FINAL_REBUILD']='1' if forced else '0'
   started=time.perf_counter()
   try:result=batch.execute(coordinates,strict=True,properties=properties)
   finally:
    os.environ.pop('VIBEQC_DF_HOST_TRACE',None);os.environ.pop('VIBEQC_DF_FORCE_FINAL_REBUILD',None)
   item=result.items[0]
   row={'name':name,'seconds':time.perf_counter()-started,'energy':item.energy,'iterations':item.iterations,'status':item.status,'warm_start_used':item.warm_start_used,'warm_start_fallback':item.warm_start_fallback,'host_components':aggregate_host(read_host_trace(path)),'df_diagnostics':[d.to_dict() for d in batch.last_density_fitting_metric_diagnostics()]}
   row['executed_backend']=item.executed_backend
   payload['steps'].append(row)
   if cold is None:cold=item.energy;batch.set_warm_start_updates(False)
   if coordinates is None:row['energy_difference_from_cold']=abs(item.energy-cold)
   if item.forces is not None:
    row['forces']=item.forces.tolist();row['maximum_net_force']=float(np.max(np.abs(item.forces.sum(axis=0))))
    if name=='warm-forces':warm_force=item.forces.copy()
    if name=='forced-warm-forces':
     row['maximum_rebuild_force_difference']=float(np.max(np.abs(item.forces-warm_force)))
   save()
   assert item.executed_backend=='cuda'
   assert (item.forces is not None)==('forces' in properties)
   assert not row['host_components']['eigensolves_by_reason']
   assert row.get('energy_difference_from_cold',0)<=1e-9
   assert row.get('maximum_net_force',0)<=1e-8
   assert row.get('maximum_rebuild_force_difference',0)<=1e-8
   row['checks']='passed';save();print('END',name,row['seconds'],row['energy'],row['iterations'],flush=True)
 payload['status']='passed'
except Exception as error:
 payload['status']='failed';payload['error']=repr(error);payload['traceback']=traceback.format_exc();raise
finally:save()

#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=/tmp/vibeqc-320-qualified/libvibeqc.so
export CUDA_LAUNCH_BLOCKING=1
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --report-api-errors all --error-exitcode 99 /tmp/vibeqc-pr-review-env/bin/python /tmp/vibeqc-308-96-atoms-4g-memcheck-probe.py

#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/usr/bin/nvidia-smi --query-gpu=name,uuid,driver_version,memory.total,utilization.gpu,memory.used --format=csv --loop=1 > /tmp/vibeqc-308-96-atoms-recovery-profile-gpu.csv &
probe_monitor_pid=$!
trap 'kill "$probe_monitor_pid" 2>/dev/null || true' EXIT
timeout --signal=TERM 180 /usr/bin/time -v /tmp/vibeqc-pr-review-env/bin/python /tmp/vibeqc-308-96-atoms-recovery-profile-probe.py > /tmp/vibeqc-308-96-atoms-recovery-profile-probe.log 2>&1 &
probe_timed_pid=$!
for probe_sample in 1 2; do
  sleep 30
  if ! kill -0 "$probe_timed_pid" 2>/dev/null; then break; fi
  probe_python_pid=$(python3 -c 'import json;print(json.load(open("/tmp/vibeqc-308-96-atoms-recovery-profile/result.json"))["pid"])')
  timeout 20 gdb -q -batch -ex 'set pagination off' -ex 'thread apply all bt 15' -p "$probe_python_pid" > "/tmp/vibeqc-308-96-atoms-recovery-profile-stack-$probe_sample.log" 2>&1 || true
done
set +e
wait "$probe_timed_pid"
probe_status=$?
set -e
printf 'probe exit: %s\n' "$probe_status"
exit "$probe_status"

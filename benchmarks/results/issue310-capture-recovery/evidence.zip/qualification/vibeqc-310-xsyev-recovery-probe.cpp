#include <cuda_runtime.h>
#include <chrono>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <vector>
#include "scf/cuda/df_plan_internal.hpp"
#include "scf/cuda/df_scf_library.hpp"

int main() {
  using namespace vibeqc::scf;
  using namespace vibeqc::scf::cuda_df;
  constexpr std::size_t n = 768;
  CudaDensityFittingJkPlan plan;
  double *matrix{}, *values{};
  int* info{};
  auto check=[](bool ok, const std::string& why) { if (!ok) throw std::runtime_error(why); };
  try {
    check(cudaStreamCreateWithFlags(&plan.stream, cudaStreamNonBlocking)==cudaSuccess,"stream");
    check(cudaMalloc(&matrix,n*n*sizeof(double))==cudaSuccess,"matrix");
    check(cudaMalloc(&values,n*sizeof(double))==cudaSuccess,"values");
    check(cudaMalloc(&info,sizeof(int))==cudaSuccess,"info");
    {
      DeviceSolver solver;
      std::string detail;
      check(setup_device_solver(plan,n,1,matrix,values,solver,detail)==VIBEQC_STATUS_SUCCESS,detail);
      std::vector<double> input(n*n), output(n);
      for (std::size_t i=0;i<n;++i) {
        input[i*n+i]=2;
        if (i+1<n) input[i*n+i+1]=input[(i+1)*n+i]=-.5;
      }
      auto upload=[&] { check(cudaMemcpyAsync(matrix,input.data(),input.size()*sizeof(double),cudaMemcpyHostToDevice,plan.stream)==cudaSuccess,"upload");check(cudaStreamSynchronize(plan.stream)==cudaSuccess,"upload drain"); };
      auto ordinary=[&](const char* name) {
        upload();
        const auto start=std::chrono::steady_clock::now();
        const auto status=solve_device_batch(solver,n,1,matrix,values,info,detail);
        std::cout<<name<<" status="<<status<<" detail="<<detail<<std::endl;
        check(status==VIBEQC_STATUS_SUCCESS,detail);
        check(cudaStreamSynchronize(plan.stream)==cudaSuccess,"ordinary drain");
        int host_info=-99;
        check(cudaMemcpy(&host_info,info,sizeof(int),cudaMemcpyDeviceToHost)==cudaSuccess,"info read");
        check(cudaMemcpy(output.data(),values,n*sizeof(double),cudaMemcpyDeviceToHost)==cudaSuccess,"values read");
        check(host_info==0,"nonzero solver info");
        double maximum=0;
        for(std::size_t i=0;i<n;++i)maximum=std::max(maximum,std::abs(output[i]-(2-std::cos((i+1)*std::acos(-1.)/(n+1)))));
        check(maximum<1e-10,"analytic spectrum mismatch");
        std::cout<<name<<" seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<" max_error="<<maximum<<std::endl;
      };
      ordinary("before-capture");
      upload();
      check(cudaStreamBeginCapture(plan.stream,cudaStreamCaptureModeThreadLocal)==cudaSuccess,"begin capture");
      auto status=solve_device_batch(solver,n,1,matrix,values,info,detail);
      cudaGraph_t graph{};
      auto ended=cudaStreamEndCapture(plan.stream,&graph);
      if(graph)cudaGraphDestroy(graph);
      std::cout<<"capture status="<<status<<" end="<<ended<<" pending="<<cudaPeekAtLastError()<<" detail="<<detail<<std::endl;
      bool rejected=false;
      check(recover_scf_capture(plan.stream,ended,status,rejected,detail)==VIBEQC_STATUS_SUCCESS,detail);
      ordinary("after-capture");
      ordinary("warm-ordinary");
    }
    cudaFree(info);cudaFree(values);cudaFree(matrix);cudaStreamDestroy(plan.stream);
    return 0;
  } catch(const std::exception& error) { std::cerr<<error.what()<<std::endl;return 1; }
}

"""Preserve actual-source-budget retained-B diagnostics and exact reconstruction."""
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np

root = Path('.artifacts/issue308-retained')
out = Path('benchmarks/results/issue308-retained-b')
out.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
runs = []
for name in ('planned-768-4g', 'planned-768-8g'):
    directory = root / name
    result = json.loads((directory / 'result.json').read_text())
    assert result['status'] == 'completed', result['status']
    assert result['native_source_identity'] == '22698c1caa743d027f76502e28ae5d860e97d503bdbb8da4a65cbc71348018e7'
    for leaf in ('result.json', 'native.jsonl', 'cuda.jsonl', 'progress.jsonl', 'stderr.txt', 'CMakeCache.txt', 'measured-source.patch'):
        files[name + '/' + leaf] = (directory / leaf).read_bytes()
    operations = []
    for line in (directory / 'cuda.jsonl').read_text().splitlines():
        record = json.loads(line)
        if record['operation'] not in ('resident_three_center_materialization', 'ri_j', 'ri_k', 'ri_k_occupied'):
            continue
        count = record['counters'].get('raw_value_bytes', 0) // 8
        count += record['counters'].get('fused_source_auxiliary_evaluations', 0)
        operations.append({'operation': record['operation'], 'raw_tensor_passes': count / 768**3, 'counters': record['counters']})
    assert len(operations) == 10
    assert operations[0]['raw_tensor_passes'] == 1
    assert all(row['raw_tensor_passes'] == 0 for row in operations[1:])
    gpu = [int(value.split(',')[1]) for row in result['memory_samples'] for value in row['gpu_process_memory']]
    host = [int(value.split()[1])*1024 for row in result['memory_samples'] for value in row['host'] if value.startswith('VmHWM:')]
    summary = {key: result[key] for key in ('status', 'slurm_job', 'seconds', 'native_rows', 'independent_checks', 'source', 'native_source_identity', 'input', 'driver', 'cuda_runtime_version', 'diagnostic_environment')}
    summary.update(run=name, completed_source_work=operations, sampled_process_gpu_peak_mib=max(gpu), process_host_high_water_bytes=max(host))
    data = (directory / 'arrays.bin').read_bytes()
    summary['full_array_identity'] = {'sha256': sha(data), 'bytes': len(data), 'retention': 'All components independently compared; exact first 24 rows retained. Complete transient arrays remain local.'}
    arrays = np.frombuffer(data, dtype='<f8').reshape(4, 768, 768)
    assert np.isfinite(arrays).all()
    files[name + '/first-24-rows-D-J-K-Kocc.bin'] = arrays[:, :24].copy().tobytes()
    runs.append(summary)
for leaf in ('run-probes.sh', 'run-validation.sh', 'retain.py'):
    files['reproduction/' + leaf] = (root / leaf).read_bytes()
for path in root.glob('*sanitizer*.log'):
    data = path.read_bytes()
    assert b'ERROR SUMMARY: 0 errors' in data
    files['validation/' + path.name] = data
for leaf in ('gpu', 'host', 'probes', 'direct-sanitizer'):
    files['validation/' + leaf + '.log'] = Path('/tmp/vibeqc-308-retained-' + leaf + '.log').read_bytes()
for leaf in ('benchmarks/df_stage_probe.cpp', 'benchmarks/issue308_stage_probe.py'):
    files['reproduction/' + Path(leaf).name] = Path(leaf).read_bytes()
for n in (96, 768):
    files[f'input-{n}/input.json'] = (Path('.artifacts/issue308-stage') / f'input-{n}/input.json').read_bytes()
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name, data in sorted(files.items()):
        stream.writestr(name, data)
with zipfile.ZipFile(archive) as stream:
    assert all(stream.read(name) == data for name, data in files.items())
summary = {
    'schema': 'vibeqc.issue308.retained-b.v1',
    'scope': 'Instrumented fixed independently qualified D. Actual source-aware DF value allowance; not whole-HF global-resource acceptance, cold SCF, full forces, clean timing, or GPU4PySCF parity.',
    'reconstruction': 'Measured uncommitted patch applies to 13c1547f2e3425b30ada4e2291a220784cd6fbaa. Frozen measured library retained locally under .artifacts/issue308-frozen-retained-initial/.',
    'runs': runs,
    'validation': {'gpu_job': '9552', 'gpu': '78 passed, 2 mocked-CUDA skips; native DF and capture-recovery suites passed', 'host': '129 resource/policy/ownership/structure tests passed', 'sanitizer_jobs': ['9553', '9554'], 'sanitizer': 'memcheck of independent retained Q=1/Q=5 tests, and direct native probes; zero errors'},
    'archive': {'path': 'evidence.zip', 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'restoration': 'Every member restored and compared byte-for-byte.'},
    'files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())],
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
policy = Path('benchmarks/evidence-policy.json')
contents = json.loads(policy.read_text())
contents['exceptions'][str(archive)] = {'owner': 'issue308-retained-b', 'reason': 'Exact 768-AO actual-source-budget setup/J/K journals, independent errors, sampled matrix rows, memory/provenance, sanitizer logs and reconstruction patch for retained B with bounded K panels.', 'sha256': summary['archive']['sha256']}
policy.write_text(json.dumps(contents, indent=2, sort_keys=True) + '\n')
print(json.dumps(summary['archive']))

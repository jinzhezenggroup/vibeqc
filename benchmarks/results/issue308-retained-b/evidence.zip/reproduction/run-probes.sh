#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1 VIBEQC_DF_VALUE_MAPPING=primitive
runner=/tmp/vibeqc-pr-review-env/bin/python
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
sha256sum "$VIBEQC_LIBRARY" .artifacts/df-stage-probe
nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
# Follow the native subprocesses created by pytest; a parent-only check would
# miss the actual retained-B kernels and cuBLAS calls.
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --target-processes all --error-exitcode 86 --log-file "$PWD/.artifacts/issue308-retained/sanitizer-%p.log" "$runner" -m pytest -q -rs tests/python/test_df_streamed_k_cuda.py -k True
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-retained/planned-768-4g --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --value-budget 4294967296 --repeats 2 --timeout 300
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-retained/planned-768-8g --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --value-budget 8589934592 --repeats 2 --timeout 300

#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
export VIBEQC_TEST_FOCK_DEVICE=cuda
/home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python -m pytest -q tests/python/test_hf_resources_cuda.py -k common_ledger_preserves_factor_differential > /tmp/vibeqc-311-snapshot-gpu-python-followup.log 2>&1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 build/cuda/vibeqc_df_final_snapshot_tests > /tmp/vibeqc-311-snapshot-gpu-memcheck.log 2>&1

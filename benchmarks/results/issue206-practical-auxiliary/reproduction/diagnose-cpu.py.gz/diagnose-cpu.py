"""Independent CPU DF force diagnosis of the retained practical-basis failures.

This changes no campaign sample, timing, gate or verdict. The tight CPU solve
is diagnostic only; both paired engines are compared with the same new oracle.
"""

import hashlib
import importlib.metadata
import json
from pathlib import Path

import numpy as np
from pyscf import gto, scf

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis

root = Path('.artifacts/issue206-auxiliary')
output = root / 'cpu-diagnosis-v1.json'
assert not output.exists()
report = {'scope': __doc__, 'pyscf_version': importlib.metadata.version('pyscf'), 'rows': []}
for path in sorted((root / 'practical-warm-v1').glob('*-forces.json')):
    data = json.loads(path.read_text())
    case = benchmark_cases()[data['workload']['case']]
    _, orbital = load_comparison_basis(root / 'cc-pvdz.json', case, role='orbital', compute_forces=True)
    _, auxiliary = load_comparison_basis(root / 'cc-pvdz-jkfit.json', case, role='auxiliary', compute_forces=True)
    molecule = gto.M(atom=case.atoms, unit='Bohr', basis=orbital, spin=case.multiplicity-1, charge=case.charge, cart=False, verbose=0)
    engine = (scf.UHF(molecule) if case.method == 'uhf' else scf.RHF(molecule)).density_fit(auxbasis=auxiliary)
    engine.conv_tol = 1e-13
    engine.conv_tol_grad = 1e-12
    engine.direct_scf_tol = 1e-14
    engine.max_cycle = 200
    history = []
    engine.callback = lambda env: history.append({key: float(env[key]) for key in ('cycle','e_tot','norm_gorb','norm_ddm') if key in env})
    energy = float(engine.kernel())
    gradient = engine.nuc_grad_method()
    gradient.auxbasis_response = True
    forces = -gradient.kernel()
    residual = float(np.linalg.norm(engine.get_grad(engine.mo_coeff, engine.mo_occ, engine.get_fock())))
    row = {'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'case': data['workload']['case'], 'energy_hartree': energy, 'forces_hartree_per_bohr': forces.tolist(), 'converged': bool(engine.converged), 'orbital_gradient_norm': residual, 'history': history, 'original_gate': data['gate'], 'engines': {}}
    for name in ('vibeqc','gpu4pyscf'):
        row['engines'][name] = [{'repeat': i, 'energy_error': float(np.max(np.abs(np.asarray(s['energies_hartree'])-energy))), 'force_error': float(np.max(np.abs(np.asarray(s['forces_hartree_per_bohr'])[0]-forces)))} for i,s in enumerate(data[name]['warm_samples'])]
    report['rows'].append(row)
    output.write_text(json.dumps(report, indent=2)+'\n')
    print(row['case'], 'CPU converged', row['converged'], 'gradient norm', residual, {e: max(s['force_error'] for s in samples) for e,samples in row['engines'].items()}, flush=True)
    assert engine.converged and residual < 1e-11

"""First practical cc-pVDZ/cc-pVDZ-JKFIT external campaign, no prior-cell retry.

Water tetramer RHF (96/464) and OH UHF (19/93), seven interleaved pairs.
Both E and full-force max errors must be <=3e-11 in every pair; stock gradient
convergence is predeclared1e-10, native energy/density1e-12/1e-10. These are new
mathematical models and cannot replace prior failed equal-basis acceptance.
Ordinary latency stability: both relative MAD<=3%; only a >=2% reduction with
paired bootstrap95% interval above2% may be called a repeatable ordinary win.
Use10000 paired bootstrap samples, NumPy default_rng(206), before examining data.
No matched-work, cold/changed or complete resource coverage claim follows.
"""

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

assert os.environ.get("SLURM_JOB_ID"), "Run through finite Slurm allocation"
root = Path.cwd()
artifacts = root / ".artifacts/issue206-auxiliary"
out = artifacts / "practical-warm-v1"
out.mkdir(exist_ok=False)
environment = {
    k: v for k, v in os.environ.items()
    if not k.startswith("VIBEQC_") and k != "CONTRACT_ENGINE"
}
environment.update(
    PYTHONPATH="python:.", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
    LD_LIBRARY_PATH="/tmp/vibeqc-308-gpu4pyscf-env/lib/python3.13/site-packages/cutensor/lib:/group/software/cuda-12.9.1/lib64:" + environment.get("LD_LIBRARY_PATH", ""),
    VIBEQC_LIBRARY="/home/jzzeng/codes/vibeqc-issue418-cooperative-rys/.artifacts/issue418/final-production/libvibeqc.so",
    VIBEQC_DF_VALUE_STORAGE="dense", VIBEQC_DF_REFERENCE_FINAL_VALIDATION="0",
    VIBEQC_DF_FINAL_PROJECTION="auto", VIBEQC_DF_FORCE_SCREEN_ABS="off",
    VIBEQC_DF_EXCHANGE="auto", VIBEQC_DF_SEED_EXCHANGE="auto",
    VIBEQC_DF_FINAL_EXCHANGE="auto", VIBEQC_DF_RESIDENT_EXCHANGE="auto",
    VIBEQC_DF_SHELL_POLICY="auto",
)
python = "/tmp/vibeqc-308-gpu4pyscf-env/bin/python"
# This controller imports only case data and never creates a GPU context.
sys.path[:0] = [str(root / "python"), str(root)]
points = [
    ("water-tetramer-def2-svp-spherical",1,3e-11,3e-11,1e-10,True),
    ("oh-def2-svp-spherical-uhf",1,3e-11,3e-11,1e-10,True),
]
basis_arguments = ["--orbital-basis-file",str(artifacts / "cc-pvdz.json"),
                   "--auxiliary-basis-file",str(artifacts / "cc-pvdz-jkfit.json")]

build = json.loads((artifacts / "build.json").read_text())
assert hashlib.sha256(Path(environment["VIBEQC_LIBRARY"]).read_bytes()).hexdigest() == build["library_sha256"]
manifest = {
    "scope": __doc__, "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "slurm_job_id": os.environ["SLURM_JOB_ID"],
    "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
    "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "build": build, "repeats_per_engine": 7,
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "comparator_sha256": hashlib.sha256((root / "benchmarks/compare_gpu4pyscf_batch.py").read_bytes()).hexdigest(),
    "qualifier_sha256": hashlib.sha256((artifacts / "qualify-stock.py").read_bytes()).hexdigest(),
    "basis_hashes": {n: hashlib.sha256((artifacts / n).read_bytes()).hexdigest() for n in ("cc-pvdz.json","cc-pvdz-jkfit.json")},
    "predeclared_statistics": {"repeats":7,"maximum_relative_mad":0.03,"minimum_reduction":0.02,"bootstrap_pairs":10000,"seed":206,"confidence":0.95},
    "controls": {k: v for k, v in environment.items() if k.startswith("VIBEQC_")},
    "points": points, "checks": [],
    "prior_failures": "Retained #421 DF96-b4/changed192 failures and #427 final direct9890 failures are not waived or overwritten by this new campaign.",
}


def save():
    """Persist each attempted stage before starting another independent point."""
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def clean_processes():
    """Reject active builds/profilers; preserve known orphan control-agent facts."""
    names = {"nvcc", "cicc", "ptxas", "nsys", "ncu", "compute-sanitizer", "cmake", "ninja", "make", "cc1plus", "clang", "clang++", "gcc", "g++", "cc1", "ccache"}
    rows = []
    for line in subprocess.check_output(["ps", "-eo", "pid=,ppid=,etimes=,comm=,args="], text=True).splitlines():
        pid, parent, age, name, arguments = line.split(None, 4)
        if name in names:
            rows.append({"pid": int(pid), "parent": int(parent), "age_seconds": int(age), "name": name, "arguments": arguments, "orphan_control_agent": name == "nsys" and "--start-agent" in arguments and parent == "1" and int(age) > 86400})
    return rows


manifest["preflight_processes"] = clean_processes()
save()
assert not any(not r["orphan_control_agent"] for r in manifest["preflight_processes"]), "Active build/profiler blocks clean timing"
qualifications = {}
for case, batch, energy_gate, force_gate, gradient_tolerance, forces in points:
    if (case, batch) not in qualifications:
        name = f"{case}-b{batch}-qualification"
        command = [python, str(artifacts / "qualify-stock.py"), "--case", case, "--batch", str(batch), "--output", str(out / f"{name}.json")]
        command += basis_arguments
        row = {"name": name, "scope": "separate stock provider/rank audit", "command": command, "status": "running"}
        manifest["checks"].append(row)
        save()
        with (out / f"{name}.txt").open("x") as stream:
            result = subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        row.update(exit_code=result.returncode, status="passed" if result.returncode == 0 else "failed")
        qualifications[case, batch] = result.returncode == 0
        save()
    name = f"{case}-b{batch}-" + ("forces" if forces else "energy")
    if not qualifications[case, batch]:
        manifest["checks"].append({"name": name, "status": "not_run_provider_qualification_failed", "numerically_qualified": False})
        save()
        continue
    path = out / f"{name}.json"
    command = [
        python, "benchmarks/compare_gpu4pyscf_batch.py", "--case", case, "--batch", str(batch),
        "--repeats", "7", "--density-fitting", "cuda", "--max-iterations", "100",
        "--energy-tolerance", "1e-12", "--density-tolerance", "1e-10",
        "--reference-gradient-tolerance", str(gradient_tolerance), "--screening-tolerance", "1e-14",
        "--maximum-energy-error", str(energy_gate), "--output", str(path),
        "--progress-output", str(out / f"{name}.progress.jsonl"),
    ]
    command += basis_arguments
    command += ["--maximum-force-error", str(force_gate)] if forces else ["--energy-only"]
    row = {"name": name, "scope": "clean external endpoint", "command": command, "status": "running"}
    manifest["checks"].append(row)
    save()
    print("starting", name, flush=True)
    with (out / f"{name}.txt").open("x") as stream:
        result = subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    row["exit_code"] = result.returncode
    if path.exists():
        data = json.loads(path.read_text())
        pairs = data["accuracy"]["paired_warm_repeats"]
        row["all_repeat_accuracy_passed"] = len(pairs) == 7 and all(
            p["maximum_energy_error_hartree"] <= energy_gate and
            (not forces or p["maximum_force_error_hartree_per_bohr"] <= force_gate)
            for p in pairs
        )
        row.update(timing=data["timing_summary"], accuracy=data["accuracy"], result_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    row["numerically_qualified"] = result.returncode == 0 and row.get("all_repeat_accuracy_passed", False)
    row["status"] = "passed" if row["numerically_qualified"] else "failed"
    save()
    print(name, row["status"], row.get("timing"), flush=True)
raise SystemExit(1 if any(r["status"] != "passed" for r in manifest["checks"]) else 0)

"""Separate untimed native diagnostics; never replace Slurm9904 samples.

Freeze one native post-cold density per model and vary only existing diagnostic
controls to separate final-state validation, derivative contraction and response
algebra. Every result and rejection is retained; no timing is collected.
"""

import json
import os
import traceback
from pathlib import Path

import numpy as np

from benchmarks._cases import benchmark_cases
from vibeqc import Calculator, load_basis

assert os.environ.get('SLURM_JOB_ID')
root = Path('.artifacts/issue206-auxiliary')
out = root / 'control-diagnosis-v1'
out.mkdir(exist_ok=False)
campaign = json.loads((root/'practical-warm-v1/manifest.json').read_text())
for name in list(os.environ):
    if name.startswith('VIBEQC_'):
        del os.environ[name]
os.environ.update(campaign['controls'])
controls = {
    'auto': {},
    'host_final': {'VIBEQC_DF_REFERENCE_FINAL_VALIDATION':'1'},
    'shell': {'VIBEQC_DF_WEIGHTED_EXECUTION':'shell'},
    'blas': {'VIBEQC_DF_RESPONSE_ALGEBRA':'blas'},
    'shell_blas': {'VIBEQC_DF_WEIGHTED_EXECUTION':'shell','VIBEQC_DF_RESPONSE_ALGEBRA':'blas'},
    'occupied': {'VIBEQC_DF_RESPONSE_SPACE':'occupied'},
    'auto_return': {},
}
keys = {k for v in controls.values() for k in v}
baseline = {k:os.environ.get(k) for k in keys}
oracle = json.loads((root/'cpu-diagnosis-v1.json').read_text())
report = {'scope':__doc__,'slurm_job_id':os.environ['SLURM_JOB_ID'],'controls':controls,'rows':[]}
orbital,auxiliary = (load_basis(root/n) for n in ('cc-pvdz.json','cc-pvdz-jkfit.json'))
for reference in oracle['rows']:
    case = benchmark_cases()[reference['case']]
    for k,v in baseline.items():
        if v is None: os.environ.pop(k,None)
        else: os.environ[k]=v
    calculator = Calculator(method=case.method,basis=orbital,auxiliary_basis=auxiliary,
        basis_representation='spherical',device='cuda',density_fitting='cuda',
        max_iterations=100,energy_tolerance=1e-12,density_tolerance=1e-10,screening_tolerance=1e-14)
    with calculator.prepare_batch([case.atoms],charges=[case.charge],multiplicities=[case.multiplicity],warm_start=True) as batch:
        batch.execute(strict=True)
        batch.set_warm_start_updates(False)
        batch.execute(strict=True)
        for name,selected in controls.items():
            for k,v in baseline.items():
                if v is None: os.environ.pop(k,None)
                else: os.environ[k]=v
            os.environ.update(selected)
            trace = out / (reference['case']+'-'+name+'.jsonl')
            os.environ['VIBEQC_DF_TRACE']=str(trace)
            row = {'case':reference['case'],'selection':name}
            try:
                item = batch.execute(strict=True).items[0]
                row.update(energy=item.energy,forces=np.asarray(item.forces).tolist(),iterations=item.iterations,
                    density_rms=item.density_rms,energy_change=item.energy_change,
                    energy_error_vs_cpu=abs(item.energy-reference['energy_hartree']),
                    force_error_vs_cpu=float(np.max(np.abs(np.asarray(item.forces)-reference['forces_hartree_per_bohr']))))
            except Exception:
                row['exception']=traceback.format_exc()
            report['rows'].append(row)
            (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
            print(row['case'],name,row.get('force_error_vs_cpu'),row.get('exception',''),flush=True)
    os.environ.pop('VIBEQC_DF_TRACE',None)

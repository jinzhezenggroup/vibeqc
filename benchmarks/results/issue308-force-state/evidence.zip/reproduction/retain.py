"""Retain the completed 768-AO full-force endpoint and actual native W."""
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np

from benchmarks.df_component_ledger import aggregate_host, read_host_trace

root = Path('.artifacts/issue308-force-state')
run = root / 'seeded-forces-768'
out = Path('benchmarks/results/issue308-force-state')
out.mkdir(parents=True, exist_ok=True)
result = json.loads((run / 'result.json').read_text())
assert result['status'] == 'completed' and result['independent_checks']['passed']
assert result['native_source_identity'] == '1fa09a8651ab1b15e85fedbfa1186ed59c1b15e60b414bbf6f4cfea2f03e166c'
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
for leaf in ('result.json', 'native.jsonl', 'cuda.jsonl', 'progress.jsonl', 'host.jsonl', 'stderr.txt', 'CMakeCache.txt', 'measured-source.patch'):
    files['seeded-forces-768/' + leaf] = (run / leaf).read_bytes()
values = np.fromfile(run / 'arrays.bin')
n = 768
assert values.size == 6*n*n+n+288 and np.isfinite(values).all()
state = values[:5*n*n].reshape(5,n,n)
eps = values[5*n*n:5*n*n+n]
weighted = values[5*n*n+n:6*n*n+n].reshape(n,n)
forces = values[6*n*n+n:].reshape(96,3)
files['state/first-24-rows-D-S-H-F-C.bin'] = state[:,:24].copy().tobytes()
files['state/orbital-energies.bin'] = eps.tobytes()
files['state/actual-native-W.bin'] = weighted.tobytes()
files['state/full-forces.bin'] = forces.tobytes()
host = aggregate_host(read_host_trace(run / 'host.jsonl'))
assert not host['eigensolves_by_reason']
for leaf in ('run-validation.sh', 'retain.py'):
    files['reproduction/' + leaf] = (root / leaf).read_bytes()
for leaf in ('benchmarks/df_scf_probe.cpp', 'benchmarks/df_scf_state_checks.py', 'benchmarks/issue308_stage_probe.py', 'tests/python/test_df_force_state_export_cuda.py'):
    files['reproduction/' + leaf] = Path(leaf).read_bytes()
for leaf in ('gpu', 'host', 'cpu-export', 'hooks'):
    files['validation/' + leaf + '.log'] = Path('/tmp/vibeqc-308-force-state-' + leaf + '.log').read_bytes()
files['input/input.json'] = Path('.artifacts/issue308-stage/input-768/input.json').read_bytes()
archive = out / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name,data in sorted(files.items()): stream.writestr(name,data)
with zipfile.ZipFile(archive) as stream:
    assert all(stream.read(name)==data for name,data in files.items())
gpu = [int(v.split(',')[1]) for sample in result['memory_samples'] for v in sample['gpu_process_memory']]
host_peak = [int(v.split()[1])*1024 for sample in result['memory_samples'] for v in sample['host'] if v.startswith('VmHWM:')]
summary = {key:result[key] for key in ('status', 'seconds', 'slurm_job', 'native_source_identity', 'native_rows', 'source', 'probe_sha256', 'driver', 'cuda_runtime_version', 'input', 'independent_checks', 'diagnostic_environment')}
summary.update(schema='vibeqc.issue308.force-state.v1',
    scope='Seeded native RHF full-force endpoint with diagnostic tracing, memory sampling and physical export. Complete independent force/W/state comparison; not cold-start, clean performance, global-resource acceptance or GPU4PySCF parity.',
    reconstruction='Measured dirty patch applies to 9ebece6d31a619f679977237f85df8e54bca49ed. New probe/validator files are retained separately; frozen library and probe remain local in .artifacts/issue308-frozen-force-state-initial/.',
    sampled_process_gpu_peak_mib=max(gpu),process_host_high_water_bytes=max(host_peak),
    progress={'phases':result['progress']['phases'],'pending':result['progress'].get('pending',[]),'iteration_observations':[r for r in result['progress'].get('observations',[]) if r['key'] in ('device_iterations','converged','seed_generation','compact_dispatch_status')]},host_components=host,
    full_array_identity={'sha256':sha((run/'arrays.bin').read_bytes()),'bytes':(run/'arrays.bin').stat().st_size},
    full_forces_hartree_per_bohr=forces.tolist(),
    archive={'path':'evidence.zip','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'restoration':'Every member restored and compared byte-for-byte.'},
    files=[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
policy=Path('benchmarks/evidence-policy.json')
contents=json.loads(policy.read_text())
contents['exceptions'][str(archive)]={'owner':'issue308-force-state','reason':'Complete native 768-AO actual W and all force components, independent checks, stage journals, source/build/input identities, memory samples and reconstruction of the first passing full-force endpoint.','sha256':summary['archive']['sha256']}
policy.write_text(json.dumps(contents,indent=2,sort_keys=True)+'\n')
print(summary['archive'])

#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1 VIBEQC_DF_VALUE_MAPPING=primitive
runner=/tmp/vibeqc-pr-review-env/bin/python
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
sha256sum "$VIBEQC_LIBRARY" .artifacts/df-scf-probe
nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
"$runner" -m pytest -q -rs tests/python/test_df_force_state_export_cuda.py tests/python/test_df_final_state_cuda.py
build/cuda/vibeqc_density_fitting_tests
# A seeded endpoint isolates the complete force consumer from the known cold
# SCF retry waste. Keep its identity explicit; this is not a cold-start result.
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-force-state/seeded-forces-768 --library "$VIBEQC_LIBRARY" --probe .artifacts/df-scf-probe --scf-mode seeded --property forces --scf-budget 17179869184 --checkpoint /tmp/vibeqc-308-large-restored-reference/vibeqc-308-96-atoms-pyscf-forces/scf.chk --reference-forces /tmp/vibeqc-308-large-restored-reference/vibeqc-308-96-atoms-pyscf-forces/forces.npy --progress --timeout 900

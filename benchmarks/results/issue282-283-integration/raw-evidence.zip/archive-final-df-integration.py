"""Archive the final integrated force matrix and independently gate every pair."""
import hashlib
import json
import sys
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

import numpy as np

task = Path(__file__).resolve().parent
repo = Path('/home/jzzeng/codes/vibeqc-df-batch-properties')
out = repo / 'benchmarks/results/issue282-283-integration'
out.mkdir(exist_ok=True)
load = lambda path: json.loads(path.read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
summary = {
    'schema': 'vibeqc.issue282-283.integration.v1',
    'runtime': load(task / 'df-final-integration-runtime/identity.json'),
    'slurm_job_id': 9359,
    'measurement': 'Five warm repeats per engine/case; frozen post-cold engine-local density; no concurrent compilation.',
    'matrix': [],
    'validation': {'cuda_native_suites': 4, 'gpu_python_cases': 66, 'host_python_cases': 76, 'optional_gpu_skips': 6, 'hooks': 'passed'},
    'limitations': [
        'Cross-engine iteration branches differ; endpoint ratios are not iteration-matched speed claims.',
        'The declared 1-GiB DF sub-budget and value-plan diagnostics do not measure global peak memory or opaque library retention.',
        'Component captures and energy-only matrix are linked prior evidence; this final matrix is an uninstrumented integrated force endpoint.',
        'Low-memory 192-AO evidence is fixed-density J/K plus the complete E2 gradient, not full-SCF force timing.',
        'Occupied-factor CUDA exchange belongs to the subsequent #284 implementation and does not execute in this checkpoint.',
    ],
}
paths = sorted((task / 'df-final-integrated-force-matrix').glob('*ao-b*.json'))
assert len(paths) == 4
for path in paths:
    data = load(path)
    pairs = list(zip(data['vibeqc']['warm_samples'], data['gpu4pyscf']['warm_samples'], strict=True))
    assert len(pairs) == 5 and data['gate']['passed']
    errors = {'energies_hartree': 0., 'forces_hartree_per_bohr': 0.}
    for a, b in pairs:
        assert all(c['converged'] for sample in (a, b) for c in sample['convergence'])
        for key in errors:
            x, y = np.asarray(a[key]), np.asarray(b[key])
            assert x.shape == y.shape and x.size and np.isfinite(x).all() and np.isfinite(y).all()
            errors[key] = max(errors[key], float(np.max(np.abs(x-y))))
    assert errors['energies_hartree'] <= 1e-9 and errors['forces_hartree_per_bohr'] <= 1e-8
    summary['matrix'].append({
        'file': path.name, 'all_pairs_pass': True, 'maximum_errors': errors,
        'vibeqc_warm_median_seconds': data['vibeqc']['warm_median_seconds'],
        'gpu4pyscf_warm_median_seconds': data['gpu4pyscf']['warm_median_seconds'],
        'value_plan_memory': data['environment'].get('density_fitting_metric_diagnostics'),
        'vibeqc_iteration_branches': [[c['iterations'] for c in s['convergence']] for s in data['vibeqc']['warm_samples']],
        'gpu4pyscf_iteration_branches': [[c['iterations'] for c in s['convergence']] for s in data['gpu4pyscf']['warm_samples']],
    })
files = list((task / 'df-final-integrated-force-matrix').iterdir())
files += [task / 'df-final-integrated-force-matrix.log']
files += [task / f'df-final-integration-{name}.log' for name in ('build', 'hooks', 'host-tests', 'gpu-tests')]
files += [task / 'df-final-integration-runtime' / name for name in ('identity.json', 'integration.patch', 'CMakeCache.txt')]
payloads = {str(path.relative_to(task)): path.read_bytes() for path in files}
payloads[Path(__file__).name] = Path(__file__).read_bytes()
archive = out / 'raw-evidence.zip'
with ZipFile(archive, 'w', compression=ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payloads.items()):
        info = ZipInfo(name, (2026, 9, 13, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        z.writestr(info, data, compresslevel=9)
manifest = {'schema': 'vibeqc.evidence-archive.v1', 'archive_sha256': sha(archive.read_bytes()),
            'files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(payloads.items())]}
(out / 'raw-evidence.manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
summary['archive'] = {'files': len(payloads), 'original_bytes': sum(map(len, payloads.values())), 'bytes': archive.stat().st_size, 'sha256': manifest['archive_sha256']}
(out / 'summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
sys.path.insert(0, str(repo))
from tools.unpack_evidence import unpack
restore = task / 'df-final-integration-archive-restored'
unpack(out, restore)
assert all((restore / name).read_bytes() == data for name, data in payloads.items())
print(json.dumps({'archive': summary['archive'], 'matrix': summary['matrix']}, indent=2))

/** Diagnostic-only bridge to the unchanged production response implementation.
 * CPU libcint A/M and a retained native density are inputs. The production
 * planner supplies its actual CUDA metric factors; all returned weights and
 * factors are detached for independent force contractions. No SCF is run.
 */
#include <algorithm>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <vector>

#include "scf/cuda/df_plan_internal.hpp"
#include "scf/cuda/df_response_weights.cuh"

namespace {
void check(cudaError_t error) {
  if (error != cudaSuccess) throw std::runtime_error(cudaGetErrorString(error));
}
struct DeviceBuffer {
  double* data{};
  explicit DeviceBuffer(std::size_t count) {
    check(cudaMalloc(reinterpret_cast<void**>(&data), count * sizeof(double)));
  }
  ~DeviceBuffer() { cudaFree(data); }
};
}

/** OH-specific diagnostic ABI, full AO-pair weights and column-major Q output.
 * Restrict the dimensions to this retained case to keep all allocations bounded.
 */
extern "C" int diagnose_response(std::size_t n, std::size_t a, const double* raw_a,
    const double* raw_m, const double* density, double* bar_a, double* bar_m,
    double* eigvec, double* eigval, double* inverse_root, char* error, std::size_t cap) {
  using namespace vibeqc::scf;
  try {
    if (n != 19 || a != 93) throw std::runtime_error("diagnostic requires retained OH 19/93");
    const auto nn = n * n, aa = a * a;
    CudaDensityFittingJkPlan* raw_plan = nullptr;
    std::vector<CudaDensityFittingMetricDiagnostic> diagnostics;
    std::string detail;
    const auto status = create_cuda_density_fitting_jk_plan(0, 1, n, a,
        {raw_m, raw_m + aa}, {raw_a, raw_a + nn * a}, 1e-10, a,
        &raw_plan, diagnostics, detail);
    if (status != VIBEQC_STATUS_SUCCESS) throw std::runtime_error(detail);
    std::unique_ptr<CudaDensityFittingJkPlan, decltype(&destroy_cuda_density_fitting_jk_plan)>
        plan(raw_plan, destroy_cuda_density_fitting_jk_plan);
    if (!plan->metric_full_rank.at(0)) throw std::runtime_error("diagnostic lost metric rank");
    std::vector<double> packed(3 * nn), aq(a * nn);
    for (std::size_t ij = 0; ij < nn; ++ij) {
      packed[ij] = density[ij] + density[nn + ij];
      packed[nn + ij] = density[ij];
      packed[2 * nn + ij] = density[nn + ij];
      for (std::size_t p = 0; p < a; ++p) aq[p * nn + ij] = raw_a[ij * a + p];
    }
    const std::vector<DensityFittingDensityResponse> terms{
        {{packed.data(), nn}, 1, 0}, {{packed.data() + nn, nn}, 0, .5},
        {{packed.data() + 2 * nn, nn}, 0, .5}};
    DeviceBuffer ds(packed.size()), av(aq.size());
    DeviceBuffer scratch(cuda_df_response_workspace_elements(n, a, terms.size(), a));
    check(cudaMemcpyAsync(ds.data, packed.data(), packed.size() * sizeof(double),
                          cudaMemcpyHostToDevice, plan->stream));
    check(cudaMemcpyAsync(av.data, aq.data(), aq.size() * sizeof(double),
                          cudaMemcpyHostToDevice, plan->stream));
    const CudaDfMetricView metric{plan->inverse_square_roots, plan->metric_eigenvectors,
                                 plan->metric_eigenvalues, plan->metric_relative_threshold};
    try {
      check(contract_cuda_df_response_weights(n, a, terms, ds.data, metric, a, scratch.data,
          plan->stream, plan->blas, false, false,
          [&](std::size_t p, double* output) {
            check(cudaMemcpyAsync(output, av.data + p * nn, nn * sizeof(double),
                                  cudaMemcpyDeviceToDevice, plan->stream));
          },
          [&](unsigned kind, vibeqc::runtime::StridedRange range, std::size_t count,
              const double* weights) {
            std::vector<double> host(count);
            check(cudaMemcpyAsync(host.data(), weights, count * sizeof(double),
                                  cudaMemcpyDeviceToHost, plan->stream));
            check(cudaStreamSynchronize(plan->stream));
            for (std::size_t k = 0; k < count; ++k)
              if (kind == 0) bar_a[range.index(k)] = host[k];
              else if (kind == 1) bar_m[k] = host[k];
              else throw std::runtime_error("unexpected response weight kind");
          }));
      check(cudaMemcpyAsync(eigvec, metric.eigenvectors, aa * sizeof(double),
                            cudaMemcpyDeviceToHost, plan->stream));
      check(cudaMemcpyAsync(eigval, metric.eigenvalues, a * sizeof(double),
                            cudaMemcpyDeviceToHost, plan->stream));
      check(cudaMemcpyAsync(inverse_root, metric.inverse_square_root, aa * sizeof(double),
                            cudaMemcpyDeviceToHost, plan->stream));
      check(cudaStreamSynchronize(plan->stream));
    } catch (...) {
      cudaStreamSynchronize(plan->stream);
      throw;
    }
    return 0;
  } catch (const CudaDfResponseBlasFailure& failure) {
    const auto message = "cuBLAS response failure: " + std::to_string(failure.status);
    if (cap) { std::strncpy(error, message.c_str(), cap - 1); error[cap - 1] = 0; }
  } catch (const std::exception& failure) {
    if (cap) { std::strncpy(error, failure.what(), cap - 1); error[cap - 1] = 0; }
  }
  return 1;
}

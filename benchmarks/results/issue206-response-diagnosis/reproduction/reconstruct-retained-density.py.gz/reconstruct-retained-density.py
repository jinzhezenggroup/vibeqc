"""Complete CPU-only reconstruction from captured final densities, without replay.

The first diagnostic retained both native densities but its RHF CPU-gradient
adapter rejected positional arguments. Preserve that failed script/result and
reuse its exact arrays here; no native solve or timing sample is repeated.
"""

import hashlib
import json
from pathlib import Path

import numpy as np
from pyscf import gto, scf

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis


def maximum(value):
    return float(np.max(np.abs(value)))


root = Path(".artifacts/issue206-auxiliary")
source = root / "final-density-v1"
out = root / "retained-density-reconstruction-v1.json"
assert not out.exists()
captured = json.loads((source / "report.json").read_text())
oracle = {r["case"]: r for r in json.loads((root / "cpu-diagnosis-v1.json").read_text())["rows"]}
report = {"scope": __doc__, "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "rows": []}
for row in captured["rows"]:
    name = row["case"]
    case = benchmark_cases()[name]
    density_file = source / (name + "-density.npy")
    spin_density = np.load(density_file, allow_pickle=False)
    is_uhf = case.method == "uhf"
    density = spin_density if is_uhf else spin_density[0]
    _, ob = load_comparison_basis(root / "cc-pvdz.json", case, role="orbital", compute_forces=True)
    _, ab = load_comparison_basis(root / "cc-pvdz-jkfit.json", case, role="auxiliary", compute_forces=True)
    mol = gto.M(atom=case.atoms, unit="Bohr", basis=ob, spin=case.multiplicity - 1, charge=case.charge, cart=False, verbose=0)
    mf = (scf.UHF(mol) if is_uhf else scf.RHF(mol)).density_fit(auxbasis=ab)
    mf.direct_scf_tol = 1e-14
    fock = mf.get_hcore() + mf.get_veff(mol, density)
    eps, coeff = mf.eig(fock, mf.get_ovlp())
    occ = np.zeros_like(eps)
    if is_uhf:
        for s, count in enumerate(mol.nelec):
            occ[s, :count] = 1
        canonical = np.array([(c * (o * e)) @ c.T for c, o, e in zip(coeff, occ, eps, strict=True)])
        consistent = density @ fock @ density
    else:
        occ[:mol.nelectron // 2] = 2
        canonical = (coeff * (occ * eps)) @ coeff.T
        consistent = density @ fock @ density / 2
    mf.make_rdm1 = lambda *args, d=density, **kwargs: d
    grad = mf.nuc_grad_method()
    grad.auxbasis_response = True
    # RHF passes orbitals positionally; UHF uses keyword arguments. In both
    # cases reconstruct exchange factors from the fixed density itself.
    grad._tag_rdm1 = lambda dm, *args, **kwargs: np.asarray(dm)
    entry = {"case": name, "density_sha256": hashlib.sha256(density_file.read_bytes()).hexdigest(), "reconstructed": {}}
    report["rows"].append(entry)
    for label, weighted in (("canonical", canonical), ("consistent", consistent)):
        grad.make_rdm1e = lambda *args, w=weighted, **kwargs: w
        forces = -grad.kernel(mo_energy=eps, mo_coeff=coeff, mo_occ=occ)
        entry["reconstructed"][label] = {
            "forces": forces.tolist(), "vs_native": maximum(forces - row["native_forces"]),
            "vs_oracle": maximum(forces - oracle[name]["forces_hartree_per_bohr"]),
        }
        out.write_text(json.dumps(report, indent=2) + "\n")
    print(name, {k: {a: b for a, b in v.items() if a != "forces"} for k, v in entry["reconstructed"].items()}, flush=True)

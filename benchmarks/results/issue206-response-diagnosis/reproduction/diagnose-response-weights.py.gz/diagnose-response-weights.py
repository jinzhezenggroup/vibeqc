"""Probe unchanged CUDA response arithmetic using independent OH A/M inputs.

The bridge runs the published production function with its actual CUDA metric
factorization, holding the retained native density fixed. CPU reorganizations
are diagnostics only: every metric direction is retained, and long-double
arithmetic separates raw-Gram rounding from the spectral reverse map.
"""

import ctypes
import hashlib
import json
import os
import traceback
from pathlib import Path

import numpy as np


def maximum(value):
    return float(np.max(np.abs(value)))


def fixed_weights(a, b, density):
    """Full-rank UHF adjoints, forming inverse-applied factors before products."""
    total = density.sum(axis=0)
    c = np.einsum("ij,ijp->p", total, b)
    u = np.array([d @ b.transpose(2, 0, 1) @ d for d in density]).transpose(0, 2, 3, 1)
    wa = total[:, :, None] * c - u.sum(axis=0)
    wm = -0.5 * np.outer(c, c) + 0.5 * np.einsum("sijp,ijq->pq", u, b, optimize=True)
    return wa, wm


def raw_gram(a, density):
    """Adjoint of M^-1 before applying the metric reverse map."""
    rho = np.einsum("ij,ijp->p", density.sum(axis=0), a)
    u = np.array([d @ a.transpose(2, 0, 1) @ d for d in density]).transpose(0, 2, 3, 1)
    return 0.5 * np.outer(rho, rho) - 0.5 * np.einsum("sijp,ijq->pq", u, a, optimize=True)


def spectral_map(e, q, eigenvalues):
    """For this verified full rank, divided differences equal -1/(li*lj)."""
    transformed = q.T @ ((e + e.T) / 2) @ q
    result = q @ (-transformed / np.outer(eigenvalues, eigenvalues)) @ q.T
    return (result + result.T) / 2


def main():
    assert os.environ.get("SLURM_JOB_ID"), "GPU diagnostics require finite Slurm"
    root = Path(".artifacts/issue206-auxiliary")
    out = root / "oh-response-weights-v1"
    out.mkdir(exist_ok=False)
    campaign = json.loads((root / "practical-warm-v1/manifest.json").read_text())
    for key in list(os.environ):
        if key.startswith("VIBEQC_"):
            del os.environ[key]
    os.environ.update(campaign["controls"])
    fixture_path = root / "oh-force-components-v1/fixed-weights-and-reference.npz"
    fixture = np.load(fixture_path, allow_pickle=False)
    a, metric, density = (np.ascontiguousarray(fixture[k]) for k in ("a", "metric", "density"))
    wa, wm = np.empty_like(a), np.empty_like(metric)
    qraw, x, eigenvalues = np.empty_like(metric), np.empty_like(metric), np.empty(metric.shape[0])
    report = {
        "scope": __doc__, "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "inputs": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (
            fixture_path, Path(__file__), root / "response-diagnostic-bridge.cpp",
            root / "response-diagnostic-bridge.so", Path(campaign["controls"]["VIBEQC_LIBRARY"])
        )},
        "status": "running", "rows": [],
    }

    def save():
        (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    save()
    try:
        lib = ctypes.CDLL(str((root / "response-diagnostic-bridge.so").resolve()))
        fn = lib.diagnose_response
        pointer = ctypes.POINTER(ctypes.c_double)
        fn.argtypes = [ctypes.c_size_t] * 2 + [pointer] * 8 + [ctypes.c_char_p, ctypes.c_size_t]
        fn.restype = ctypes.c_int
        error = ctypes.create_string_buffer(4096)
        status = fn(a.shape[0], a.shape[2], *(v.ctypes.data_as(pointer) for v in (a, metric, density, wa, wm, qraw, eigenvalues, x)), error, len(error))
        if status:
            raise RuntimeError(error.value.decode())
        q = qraw.T.copy()  # C++ emits cuSOLVER's column-major eigenvectors.
        assert np.min(eigenvalues) > 1e-10 * np.max(eigenvalues)
        report["metric"] = {
            "rank": len(eigenvalues), "condition": float(eigenvalues[-1] / eigenvalues[0]),
            "eigen_residual": maximum(metric @ q - q * eigenvalues),
            "orthogonality_max": maximum(q.T @ q - np.eye(len(eigenvalues))),
            "inverse_root_residual": maximum(x @ metric @ x - np.eye(len(eigenvalues))),
            "longdouble_mantissa": np.finfo(np.longdouble).nmant,
        }
        reference_a, reference_m = fixture["bar_a"], fixture["bar_m"]
        arrays = {"cuda_bar_a": wa, "cuda_bar_m": wm, "eigenvectors": q,
                  "eigenvalues": eigenvalues, "inverse_root": x}

        def add(label, weight_a, weight_m):
            delta_a = np.einsum("axijp,ijp->ax", fixture["da"], weight_a - reference_a)
            delta_m = np.einsum("axpq,pq->ax", fixture["dm"], weight_m - reference_m)
            row = {"label": label, "a_weight_error": maximum(weight_a - reference_a),
                   "m_weight_error": maximum(weight_m - reference_m),
                   "three_center_force_error": maximum(delta_a), "metric_force_error": maximum(delta_m),
                   "combined_force_error": maximum(delta_a + delta_m),
                   "three_center_delta": np.asarray(delta_a, dtype=float).tolist(),
                   "metric_delta": np.asarray(delta_m, dtype=float).tolist()}
            report["rows"].append(row)
            arrays[label + "_a"] = weight_a
            arrays[label + "_m"] = weight_m
            save()
            print({k: v for k, v in row.items() if not k.endswith("delta")}, flush=True)

        add("unchanged_cuda_response", wa, wm)
        eigen_b = ((a @ q) / eigenvalues) @ q.T
        stable_a, stable_m = fixed_weights(a, eigen_b, density)
        add("cpu_factor_first_same_cuda_eigensystem", stable_a, stable_m)
        e64 = raw_gram(a, density)
        add("cpu_raw_gram_fp64", stable_a, spectral_map(e64, q, eigenvalues))
        # Both extended variants use identical FP64 CUDA eigenvectors/values.
        # Only contraction arithmetic changes; the production plan is untouched.
        wide = np.longdouble
        qw, lw = q.astype(wide), eigenvalues.astype(wide)
        add("cpu_rounded_gram_extended_map", stable_a, spectral_map(e64.astype(wide), qw, lw))
        ew = raw_gram(a.astype(wide), density.astype(wide))
        add("cpu_raw_gram_and_map_extended", stable_a, spectral_map(ew, qw, lw))
        arrays.update(raw_gram_fp64=e64, raw_gram_extended=ew)
        np.savez_compressed(out / "response-arrays.npz", **arrays)
        report["status"] = "completed response-only diagnostic; original gates unchanged"
    except Exception:
        report["status"] = "failed diagnostic"
        report["exception"] = traceback.format_exc()
        raise
    finally:
        save()


if __name__ == "__main__":
    main()

"""Separate OH force components at identical independently constructed weights.

This is untimed diagnosis using an already captured native final density. Full
rank Cholesky solves of independent libcint integrals define the fixed weights;
standalone CUDA derivative APIs receive those exact weights. No SCF is replayed.
"""

import hashlib
import json
import os
import traceback
from pathlib import Path

import numpy as np
from pyscf import df, gto, scf
from scipy.linalg import cho_factor, cho_solve

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis, native_build_metadata
from tools.vibeqc_validation.df_gradient import execute_df_gradient, reference_df_matrices
from tools.vibeqc_validation.one_electron_gradient import execute_gradient, reference_matrices
from vibeqc import Atom, Calculator


def maximum(value):
    return float(np.max(np.abs(value)))


def public_inputs(case, basis):
    """Expand every canonical contraction in the native public shell order."""
    atoms = tuple(Atom.from_value(a) for a in case.atoms)
    return {
        "atomic_numbers": [a.atomic_number for a in atoms],
        "coordinates": [a.position for a in atoms],
        "charge": case.charge, "multiplicity": case.multiplicity,
        "basis_representation": "spherical",
        "shells": [
            {"atom_index": s.atom_index, "angular_momentum": s.angular_momentum,
             "primitives": [[p.exponent, p.coefficient] for p in s.primitives]}
            for s in basis.shells_for(atoms)
        ],
    }


def main():
    assert os.environ.get("SLURM_JOB_ID"), "GPU diagnostics require finite Slurm"
    root = Path(".artifacts/issue206-auxiliary")
    out = root / "oh-force-components-v1"
    out.mkdir(exist_ok=False)
    campaign = json.loads((root / "practical-warm-v1/manifest.json").read_text())
    for key in list(os.environ):
        if key.startswith("VIBEQC_"):
            del os.environ[key]
    os.environ.update(campaign["controls"])
    name = "oh-def2-svp-spherical-uhf"
    case = benchmark_cases()[name]
    density_path = root / "final-density-v1" / (name + "-density.npy")
    density = np.load(density_path, allow_pickle=False)
    captured = next(r for r in json.loads((root / "final-density-v1/report.json").read_text())["rows"] if r["case"] == name)
    reconstructed = next(r for r in json.loads((root / "retained-density-reconstruction-v1.json").read_text())["rows"] if r["case"] == name)
    oracle = next(r for r in json.loads((root / "cpu-diagnosis-v1.json").read_text())["rows"] if r["case"] == name)
    report = {
        "scope": __doc__, "case": name, "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "density_sha256": hashlib.sha256(density_path.read_bytes()).hexdigest(),
        "controls": campaign["controls"], "status": "running", "cuda": [],
    }

    def save():
        (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    save()
    try:
        orbital, ob = load_comparison_basis(root / "cc-pvdz.json", case, role="orbital", compute_forces=True)
        auxiliary, ab = load_comparison_basis(root / "cc-pvdz-jkfit.json", case, role="auxiliary", compute_forces=True)
        oi, xi = public_inputs(case, orbital), public_inputs(case, auxiliary)
        mol = gto.M(atom=case.atoms, unit="Bohr", basis=ob, spin=1, cart=False, verbose=0)
        mf = scf.UHF(mol).density_fit(auxbasis=ab)
        overlap, hcore = mf.get_ovlp(), mf.get_hcore()
        fock = hcore + mf.get_veff(mol, density)
        a, metric, da, dm = reference_df_matrices(oi, xi)
        values, derivatives = reference_matrices(oi)
        independent_a = df.incore.aux_e2(mol, mf.with_df.auxmol, aosym="s1")
        checks = {
            "overlap_public_vs_pyscf": maximum(values[0] - overlap),
            "hcore_public_vs_pyscf": maximum(values[1] + values[2] - hcore),
            "a_public_vs_pyscf": maximum(a - independent_a),
            "metric_public_vs_pyscf": maximum(metric - mf.with_df.auxmol.intor("int2c2e")),
        }
        report["convention_checks"] = checks
        save()
        assert max(checks.values()) < 1e-10, checks
        n, _, q = a.shape
        b = cho_solve(cho_factor(metric, lower=True), a.reshape(n*n, q).T).T.reshape(n, n, q)
        total = density.sum(axis=0)
        c = np.einsum("ij,ijp->p", total, b)
        # UHF E2 = 1/2 rho^T M^-1 rho - 1/2 sum_s Tr(Ds A_P Ds B_P).
        # These are full-tensor adjoints, including both orbital/AO orders.
        u = np.einsum("sij,jkp,skl->silp", density, b, density, optimize=True)
        bar_a = total[:, :, None] * c - u.sum(axis=0)
        bar_m = -0.5 * np.outer(c, c) + 0.5 * np.einsum("sijp,ijq->pq", u, b, optimize=True)
        j = np.einsum("ijp,p->ij", a, c)
        k = np.einsum("ikp,skl,jlp->sij", a, density, b, optimize=True)
        reconstructed_fock = hcore + j - k
        weighted = (density @ fock @ density).sum(axis=0)
        one_weights = np.array([-weighted, total, total])
        components = {
            "one_electron": np.einsum("axkij,kij->ax", derivatives, one_weights),
            "three_center": np.einsum("axijp,ijp->ax", da, bar_a),
            "metric": np.einsum("axpq,pq->ax", dm, bar_m),
            "nuclear": mf.nuc_grad_method().grad_nuc(),
        }
        cpu_force = -sum(components.values())
        checks.update(
            reconstructed_fock_vs_pyscf=maximum(reconstructed_fock - fock),
            cpu_component_force_vs_pyscf=maximum(cpu_force - reconstructed["reconstructed"]["consistent"]["forces"]),
            cpu_component_force_vs_oracle=maximum(cpu_force - oracle["forces_hartree_per_bohr"]),
            metric_solve_residual=maximum(np.einsum("pq,ijq->ijp", metric, b) - a),
        )
        report["cpu_components"] = {k: v.tolist() for k, v in components.items()}
        report["cpu_force"] = cpu_force.tolist()
        np.savez_compressed(out / "fixed-weights-and-reference.npz", density=density,
                            a=a, metric=metric, da=da, dm=dm, b=b, bar_a=bar_a,
                            bar_m=bar_m, one_weights=one_weights, derivatives=derivatives)
        save()
        assert checks["reconstructed_fock_vs_pyscf"] < 1e-10, checks
        assert checks["cpu_component_force_vs_pyscf"] < 3e-11, checks
        o = Calculator(device="cuda", basis=orbital, basis_representation="spherical")
        x = Calculator(device="cuda", basis=auxiliary, basis_representation="spherical")
        report["native_build"] = native_build_metadata(o)
        assert report["native_build"]["library_sha256"] == campaign["build"]["library_sha256"]
        for schedule in (0, 1):
            gradients = {}
            for label in ("one_electron", "three_center", "metric"):
                if label == "one_electron":
                    actual, resources = execute_gradient(o, case.atoms, one_weights, schedule=schedule, multiplicity=2)
                else:
                    wa = bar_a if label == "three_center" else np.zeros_like(bar_a)
                    wm = bar_m if label == "metric" else np.zeros_like(bar_m)
                    actual, resources = execute_df_gradient(o, x, case.atoms, wa, wm, schedule=schedule, multiplicity=2)
                gradients[label] = actual
                row = {"schedule": schedule, "component": label, "gradient": actual.tolist(),
                       "max_error_vs_cpu_fixed_weights": maximum(actual - components[label]),
                       "resources": resources}
                report["cuda"].append(row)
                save()
                print(schedule, label, row["max_error_vs_cpu_fixed_weights"], flush=True)
            force = -(sum(gradients.values()) + components["nuclear"])
            row = {"schedule": schedule, "component": "assembled_full_force", "force": force.tolist(),
                   "vs_cpu_fixed_weights": maximum(force - cpu_force),
                   "vs_native_endpoint": maximum(force - captured["native_forces"]),
                   "vs_oracle": maximum(force - oracle["forces_hartree_per_bohr"])}
            report["cuda"].append(row)
            save()
            print(row, flush=True)
        report["status"] = "completed fixed-weight diagnostic; original gates unchanged"
    except Exception:
        report["status"] = "failed diagnostic"
        report["exception"] = traceback.format_exc()
        raise
    finally:
        save()


if __name__ == "__main__":
    main()

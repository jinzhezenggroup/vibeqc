"""Untimed final-density diagnosis; never replace or pool clean campaign data.

Enable warm snapshot updates only for one replay of the frozen post-cold input.
The resulting density is the solve output, not its seed. Check the public AO
convention independently before using that density in CPU DF force assembly.
"""

import hashlib
import json
import os
import traceback
from pathlib import Path

import numpy as np
from pyscf import gto, scf

from benchmarks._cases import benchmark_cases
from benchmarks.compare_gpu4pyscf_batch import load_comparison_basis, native_build_metadata
from vibeqc import Calculator
from vibeqc.progressive import _retained_density


def maximum(value):
    return float(np.max(np.abs(value)))


def main():
    assert os.environ.get("SLURM_JOB_ID"), "GPU diagnostics require finite Slurm"
    root = Path(".artifacts/issue206-auxiliary")
    out = root / "final-density-v1"
    out.mkdir(exist_ok=False)
    campaign = json.loads((root / "practical-warm-v1/manifest.json").read_text())
    oracle = json.loads((root / "cpu-diagnosis-v1.json").read_text())
    for key in list(os.environ):
        if key.startswith("VIBEQC_"):
            del os.environ[key]
    os.environ.update(campaign["controls"])
    report = {
        "scope": __doc__, "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "controls": campaign["controls"], "rows": [], "status": "running",
    }

    def save():
        (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")

    save()
    try:
        for reference in sorted(oracle["rows"], key=lambda r: r["case"]):
            case = benchmark_cases()[reference["case"]]
            orbital, ob = load_comparison_basis(root / "cc-pvdz.json", case, role="orbital", compute_forces=True)
            auxiliary, ab = load_comparison_basis(root / "cc-pvdz-jkfit.json", case, role="auxiliary", compute_forces=True)
            calculator = Calculator(
                method=case.method, basis=orbital, auxiliary_basis=auxiliary,
                basis_representation="spherical", device="cuda", density_fitting="cuda",
                max_iterations=100, energy_tolerance=1e-12, density_tolerance=1e-10,
                screening_tolerance=1e-14,
            )
            identity = native_build_metadata(calculator)
            assert identity["library_sha256"] == campaign["build"]["library_sha256"]
            os.environ["VIBEQC_DF_TRACE"] = str(out / (reference["case"] + ".jsonl"))
            with calculator.prepare_batch([case.atoms], charges=[case.charge], multiplicities=[case.multiplicity], warm_start=True) as batch:
                batch.execute(strict=True)
                seed = _retained_density(batch)
                batch.set_warm_start_updates(False)
                batch.execute(strict=True)
                np.testing.assert_array_equal(seed, _retained_density(batch))
                batch.set_warm_start_updates(True)
                item = batch.execute(strict=True).items[0]
                spin_density = _retained_density(batch)
            os.environ.pop("VIBEQC_DF_TRACE", None)
            np.save(out / (reference["case"] + "-density.npy"), spin_density, allow_pickle=False)
            np.save(out / (reference["case"] + "-seed.npy"), seed, allow_pickle=False)
            is_uhf = case.method == "uhf"
            density = spin_density if is_uhf else spin_density[0]
            mol = gto.M(atom=case.atoms, unit="Bohr", basis=ob, spin=case.multiplicity - 1, charge=case.charge, cart=False, verbose=0)
            mf = (scf.UHF(mol) if is_uhf else scf.RHF(mol)).density_fit(auxbasis=ab)
            mf.direct_scf_tol = 1e-14
            overlap, hcore = mf.get_ovlp(), mf.get_hcore()
            fock = hcore + mf.get_veff(mol, density)
            energy = float(np.sum(density * (hcore + fock)) / 2 + mol.energy_nuc())
            eps, coeff = mf.eig(fock, overlap)
            occ = np.zeros_like(eps)
            if is_uhf:
                for s, count in enumerate(mol.nelec):
                    occ[s, :count] = 1
                rebuilt = np.array([(c * o) @ c.T for c, o in zip(coeff, occ, strict=True)])
                canonical = np.array([(c * (o * e)) @ c.T for c, o, e in zip(coeff, occ, eps, strict=True)])
                consistent = density @ fock @ density
                electron_error = maximum(np.einsum("sij,ji->s", density, overlap) - mol.nelec)
            else:
                occ[:mol.nelectron // 2] = 2
                rebuilt = (coeff * occ) @ coeff.T
                canonical = (coeff * (occ * eps)) @ coeff.T
                consistent = density @ fock @ density / 2
                electron_error = abs(float(np.einsum("ij,ji", density, overlap)) - mol.nelectron)
            checks = {
                "electron_trace_error": electron_error,
                "idempotency_max": maximum(density @ overlap @ density - (1 if is_uhf else 2) * density),
                "energy_error_from_native": abs(energy - item.energy),
                "commutator_max": maximum(fock @ density @ overlap - overlap @ density @ fock),
                "canonical_density_drift_max": maximum(rebuilt - density),
                "seed_to_output_density_max": maximum(spin_density - seed),
                "weighted_density_difference_max": maximum(canonical - consistent),
            }
            native_forces = np.asarray(item.forces)
            reference_forces = np.asarray(reference["forces_hartree_per_bohr"])
            row = {
                "case": reference["case"], "native_build": identity,
                "iterations": item.iterations, "density_rms": item.density_rms,
                "native_energy": item.energy, "cpu_physical_energy_at_native_density": energy,
                "native_forces": native_forces.tolist(), "state_checks": checks,
                "native_vs_oracle": maximum(native_forces - reference_forces),
                "reconstructed": {},
            }
            report["rows"].append(row)
            save()
            assert electron_error < 1e-9 and checks["energy_error_from_native"] < 1e-9, checks
            # PySCF's DF gradient otherwise tags this density with the newly
            # diagonalized orbitals. Disable tagging so its exchange consumer
            # derives occupied factors from the actual fixed native density.
            mf.make_rdm1 = lambda *args, d=density, **kwargs: d
            grad = mf.nuc_grad_method()
            grad.auxbasis_response = True
            grad._tag_rdm1 = lambda dm, **kwargs: np.asarray(dm)
            for name, weighted in (("canonical", canonical), ("consistent", consistent)):
                grad.make_rdm1e = lambda *args, w=weighted, **kwargs: w
                forces = -grad.kernel(mo_energy=eps, mo_coeff=coeff, mo_occ=occ)
                row["reconstructed"][name] = {
                    "forces": forces.tolist(), "vs_native": maximum(forces - native_forces),
                    "vs_oracle": maximum(forces - reference_forces),
                }
                save()
            print(row["case"], checks, {k: {a: b for a, b in v.items() if a != "forces"} for k, v in row["reconstructed"].items()}, flush=True)
        report["status"] = "completed diagnostic; original gates unchanged"
    except Exception:
        report["status"] = "failed diagnostic"
        report["exception"] = traceback.format_exc()
        raise
    finally:
        save()


if __name__ == "__main__":
    main()
